package com.rozara.azan;

import android.content.Context;
import android.graphics.Typeface;

/** فونت شبنم از assets/fonts (در زمان ساخت دانلود یا از مخزن کپی می‌شود)؛ در نبودش فونت سیستم. */
final class Fonts {
    private static Typeface reg, bold;

    private Fonts() {}

    static synchronized Typeface shabnam(Context c, boolean isBold) {
        if (isBold) {
            if (bold == null) bold = load(c, new String[]{"fonts/Shabnam-Bold.ttf", "fonts/Shabnam-Medium.ttf", "fonts/Shabnam.ttf"}, Typeface.BOLD);
            return bold;
        }
        if (reg == null) reg = load(c, new String[]{"fonts/Shabnam.ttf", "fonts/Shabnam-Medium.ttf"}, Typeface.NORMAL);
        return reg;
    }

    private static Typeface load(Context c, String[] names, int style) {
        for (String n : names) {
            try {
                return Typeface.createFromAsset(c.getAssets(), n);
            } catch (Throwable ignored) {
            }
        }
        return Typeface.create("sans-serif", style);
    }
}
