package com.rozara.azan;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;

/** کارت‌ها و متن‌های نوتیف با فونت شبنم (RemoteViews فونت سفارشی را پشتیبانی نمی‌کند، پس متن به تصویر تبدیل می‌شود). */
final class CardRender {
    private CardRender() {}

    /** کارت سبز با هلال طلایی؛ برای یادآوری و تبریک تولد */
    static Bitmap simple(Context ctx, String title, String sub, int h, int subLines) {
        int w = 1080;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float rad = 46f;

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setShader(new LinearGradient(w, 0, 0, h, new int[]{0xFF054A44, 0xFF0A7A6F, 0xFF16A08F},
                new float[]{0f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, w, h), rad, rad, bg);

        float r = 50f, cx = 60f + r, cy = h / 2f;
        Path outer = new Path();
        outer.addCircle(cx, cy, r, Path.Direction.CW);
        Path inner = new Path();
        inner.addCircle(cx + r * 0.48f, cy - r * 0.26f, r * 0.84f, Path.Direction.CW);
        outer.op(inner, Path.Op.DIFFERENCE);
        Paint gold = new Paint(Paint.ANTI_ALIAS_FLAG);
        gold.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFFF1D58A, 0xFFC99A2E, Shader.TileMode.CLAMP));
        c.drawPath(outer, gold);

        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2f);
        border.setColor(0x33FFFFFF);
        c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), rad, rad, border);

        float right = w - 52f, left = 60f + 2 * r + 40f, maxW = right - left;
        Typeface tb = Fonts.shabnam(ctx, true), tr = Fonts.shabnam(ctx, false);
        float y = Math.max(22f, (h - (subLines > 1 ? 190f : 130f)) / 2f);
        y += line(c, title, tb, 62f, Color.WHITE, right, y, maxW, 34f, 1) + 6f;
        line(c, sub, tr, 40f, 0xFFF1D99E, right, y, maxW, 26f, subLines);
        return bmp;
    }

    /** دو خط متن راست‌چین روی زمینهٔ شفاف (داخل نوتیف اذان که پس‌زمینه‌اش از XML می‌آید) */
    static Bitmap text(Context ctx, String title, String sub, int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Typeface tb = Fonts.shabnam(ctx, true), tr = Fonts.shabnam(ctx, false);
        float y = 6f;
        y += line(c, title, tb, 54f, Color.WHITE, w, y, w, 30f, 1) + 4f;
        line(c, sub, tr, 36f, 0xFFF1D99E, w, y, w, 22f, 1);
        return bmp;
    }

    private static float line(Canvas c, String text, Typeface tf, float size, int color, float right, float top,
                              float maxW, float minSize, int maxLines) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setColor(color);
        p.setTextSize(size);
        float budget = maxW * (maxLines > 1 ? maxLines * 0.9f : 1f);
        while (p.measureText(text) > budget && p.getTextSize() > minSize) p.setTextSize(p.getTextSize() - 2f);
        StaticLayout sl = StaticLayout.Builder.obtain(text, 0, text.length(), p, (int) maxW)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .build();
        c.save();
        c.translate(right - maxW, top);
        sl.draw(c);
        c.restore();
        return sl.getHeight();
    }
}
