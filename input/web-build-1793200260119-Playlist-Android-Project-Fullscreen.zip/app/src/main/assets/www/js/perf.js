/* User-selectable performance settings: animations on/off + visual quality. */
const PerfSettings = (() => {
  const KEY = 'playlist_app_perf_v1';
  const root = document.documentElement;
  let cfg = {};
  try { cfg = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { cfg = {}; }
  // First-time default: the last (lowest) quality level, for the smoothest experience.
  function autoQuality() { return 'low'; }
  function get() {
    const q = ['high', 'medium', 'low'].includes(cfg.quality) ? cfg.quality : autoQuality();
    return { quality: q, anim: cfg.anim !== false, beat: cfg.beat !== false };
  }
  function apply() {
    const g = get();
    root.setAttribute('data-quality', g.quality);
    root.setAttribute('data-anim', g.anim ? 'on' : 'off');
    root.setAttribute('data-beat', g.beat ? 'on' : 'off');
    if (g.quality === 'high') root.removeAttribute('data-lite'); else root.setAttribute('data-lite', '1');
  }
  function set(patch) {
    Object.assign(cfg, patch);
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {}
    apply();
    window.dispatchEvent(new Event('perfchange'));
  }
  apply();
  return { get, set, apply };
})();
