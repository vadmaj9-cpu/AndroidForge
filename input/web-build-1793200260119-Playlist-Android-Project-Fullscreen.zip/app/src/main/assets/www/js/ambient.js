/* Dynamic ambient background for the full-screen player.
   - Several big soft colour blobs drift slowly (pure CSS transforms: cheap on the GPU).
   - Colours = dominant colours of the playing cover  +  the app's theme colours.
   - When the song / cover changes the new palette is painted on a second layer and cross-faded (no sudden jumps).
   Ambient.sync() is called after every render. */
const Ambient = (() => {
  // Playlist theme colours (purple / pink / indigo / sky / lavender)
  const THEME = [[139, 92, 246], [255, 107, 214], [79, 70, 229], [56, 189, 248], [167, 139, 250]];
  const SAT_MIN = 0.5, SAT_MAX = 0.92, L_MIN = 0.4, L_MAX = 0.62;

  let root = null, layers = [], cur = 0, curKey = null, idleT = 0, shown = false, first = true;
  const cache = new Map();

  function build() {
    if (root) return;
    root = document.createElement('div');
    root.className = 'ambient'; root.setAttribute('aria-hidden', 'true');
    const blobs = '<i class="b b1"></i><i class="b b2"></i><i class="b b3"></i><i class="b b4"></i><i class="b b5"></i>';
    root.innerHTML = `<div class="amb-layer">${blobs}</div><div class="amb-layer">${blobs}</div><div class="amb-shade"></div>`;
    document.body.appendChild(root);
    layers = Array.from(root.querySelectorAll('.amb-layer'));
    layers.forEach(l => l.classList.add('idle'));
  }

  // ---------- colour helpers ----------
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0;
    if (mx !== mn) {
      const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6;
    }
    return [h * 360, s, l];
  }
  function hsl2rgb(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    if (s === 0) { const v = Math.round(l * 255); return [v, v, v]; }
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = (t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return [f(h + 1 / 3), f(h), f(h - 1 / 3)].map(v => Math.round(v * 255));
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const mix = (c, t, k) => c.map((v, i) => Math.round(v * (1 - k) + t[i] * k));
  const hueDist = (a, b) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; };

  // Up to three distinct, vivid colours from the cover
  function extract(img) {
    try {
      const S = 40, c = document.createElement('canvas'); c.width = c.height = S;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, S, S);
      const d = x.getImageData(0, 0, S, S).data;
      const B = 18, buckets = Array.from({ length: B }, () => ({ w: 0, r: 0, g: 0, b: 0 }));
      let tr = 0, tg = 0, tb = 0, tw = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) continue;
        const R = d[i], G = d[i + 1], Bl = d[i + 2], [h, s, l] = rgb2hsl(R, G, Bl);
        tr += R; tg += G; tb += Bl; tw++;
        const w = Math.pow(s, 1.6) * (1 - Math.abs(l - 0.5) * 1.3);
        if (w <= 0.004) continue;
        const bk = buckets[Math.floor(h / (360 / B)) % B];
        bk.w += w; bk.r += R * w; bk.g += G * w; bk.b += Bl * w;
      }
      const ranked = buckets.map((b, i) => ({ i, w: b.w, rgb: b.w ? [b.r / b.w, b.g / b.w, b.b / b.w] : null }))
        .filter(b => b.rgb).sort((a, b) => b.w - a.w);
      const picks = [];
      for (const b of ranked) {
        const [h] = rgb2hsl.apply(null, b.rgb);
        if (picks.every(p => hueDist(p.h, h) >= 22)) picks.push({ h, rgb: b.rgb, w: b.w });
        if (picks.length === 3) break;
      }
      const total = ranked.reduce((a, b) => a + b.w, 0);
      const out = picks.filter(p => p.w > total * 0.06).map(p => {
        const [h, s, l] = rgb2hsl.apply(null, p.rgb);
        return hsl2rgb(h, clamp(s * 1.12, SAT_MIN, SAT_MAX), clamp(l, L_MIN, L_MAX));
      });
      if (!out.length && tw) {
        // grey / black&white cover: use its average tone as a soft base, the theme adds the colour
        const [h, , l] = rgb2hsl(tr / tw, tg / tw, tb / tw);
        out.push(hsl2rgb(h, 0.2, clamp(l, 0.35, 0.6)));
      }
      return out;
    } catch (e) { return null; }
  }

  // cover colours + theme colours -> 5 blob colours
  function palette(cover) {
    if (!cover || !cover.length) return THEME.map(c => c.slice());
    const t = [THEME[1], THEME[3], THEME[2]];
    const a = cover[0], b = cover[1] || mix(cover[0], THEME[1], 0.55), c = cover[2] || mix(cover[0], THEME[3], 0.5);
    // a little of the app theme in every cover colour keeps the look consistent with Playlist
    return [mix(a, THEME[0], 0.12), mix(b, THEME[1], 0.12), mix(c, THEME[2], 0.12), THEME[0], t[0]];
  }

  function paint(layer, pal) { pal.forEach((c, i) => layer.style.setProperty('--c' + (i + 1), c.join(','))); }

  function setPalette(pal, key) {
    if (key === curKey) return;
    curKey = key;
    if (first) {
      first = false;
      const l = layers[cur]; paint(l, pal); l.classList.add('fast'); l.classList.remove('idle'); l.classList.add('on');
      setTimeout(() => l.classList.remove('fast'), 1000);
      return;
    }
    const next = layers[1 - cur], prev = layers[cur];
    paint(next, pal);
    next.classList.remove('idle'); next.classList.add('on'); prev.classList.remove('on');
    cur = 1 - cur;
    clearTimeout(idleT);
    // stop animating the layer that has faded out (saves CPU/GPU)
    idleT = setTimeout(() => prev.classList.add('idle'), 3000);
  }

  function sync() {
    build();
    const np = document.querySelector('.now-playing:not(.closing)');
    if (!np) {
      if (shown) { shown = false; root.classList.remove('show'); document.documentElement.classList.remove('has-ambient'); }
      return;
    }
    if (!shown) { shown = true; root.classList.add('show'); document.documentElement.classList.add('has-ambient'); }
    const img = np.querySelector('.np-cover');
    const key = img ? (img.getAttribute('data-cover-key') || '') : '';
    if (!key) { setPalette(palette(null), 'default'); return; }
    const src = img.getAttribute('src');
    if (!src) return; // cover still loading; the load event below calls sync again
    if (cache.has(src)) { setPalette(cache.get(src), src); return; }
    const run = () => {
      const pal = palette(extract(img));
      cache.set(src, pal);
      if (img.getAttribute('src') === src) setPalette(pal, src);
    };
    if (img.complete && img.naturalWidth) run(); else img.addEventListener('load', run, { once: true });
  }

  document.addEventListener('load', (e) => { const el = e.target; if (el && el.matches && el.matches('.np-cover')) sync(); }, true);
  return { sync, extract, palette };
})();
