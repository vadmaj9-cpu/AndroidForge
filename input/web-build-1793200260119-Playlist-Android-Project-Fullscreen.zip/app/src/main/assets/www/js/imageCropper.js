/**
 * Self-contained image cropper. Does not depend on the app's render() cycle —
 * builds its own DOM, operates independently, and cleans up after itself.
 *
 * openImageCropper(file, { shape: 'circle' | 'square', outputSize: 480 })
 *   -> Promise<Blob|null>  (null if the user cancels)
 */
function openImageCropper(file, options) {
  const opts = Object.assign({ shape: 'square', outputSize: 480 }, options || {});

  return new Promise((resolve) => {
    const objectUrl = URL.createObjectURL(file);
    const VIEWPORT = 260;

    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop cropper-backdrop';
    backdrop.innerHTML = `
      <div class="modal cropper-modal">
        <div class="modal-header">
          <h2>${t('cropper.title')}</h2>
          <button type="button" class="icon-btn" data-cropper-cancel aria-label="${t('cropper.cancel')}">${icon('x', 18)}</button>
        </div>
        <div class="cropper-viewport ${opts.shape === 'circle' ? 'round' : ''}" data-cropper-viewport>
          <img data-cropper-img src="${objectUrl}" draggable="false" alt="">
        </div>
        <input type="range" class="cropper-zoom" data-cropper-zoom min="100" max="300" value="100">
        <div class="cropper-actions">
          <button type="button" class="btn btn-outline" data-cropper-cancel>${t('cropper.cancel')}</button>
          <button type="button" class="btn btn-primary" data-cropper-confirm>${t('cropper.confirm')}</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);

    const viewport = backdrop.querySelector('[data-cropper-viewport]');
    const img = backdrop.querySelector('[data-cropper-img]');
    const zoomSlider = backdrop.querySelector('[data-cropper-zoom]');

    let baseScale = 1, currentScale = 1, offsetX = 0, offsetY = 0;
    let naturalW = 0, naturalH = 0;

    function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

    function applyTransform() {
      const w = naturalW * currentScale;
      const h = naturalH * currentScale;
      img.style.width = w + 'px';
      img.style.height = h + 'px';
      const minX = VIEWPORT - w, maxX = 0;
      const minY = VIEWPORT - h, maxY = 0;
      offsetX = clamp(offsetX, minX, maxX);
      offsetY = clamp(offsetY, minY, maxY);
      img.style.left = offsetX + 'px';
      img.style.top = offsetY + 'px';
    }

    img.onload = () => {
      naturalW = img.naturalWidth; naturalH = img.naturalHeight;
      baseScale = Math.max(VIEWPORT / naturalW, VIEWPORT / naturalH);
      currentScale = baseScale;
      offsetX = (VIEWPORT - naturalW * currentScale) / 2;
      offsetY = (VIEWPORT - naturalH * currentScale) / 2;
      applyTransform();
    };

    let dragging = false, startX = 0, startY = 0, startOffX = 0, startOffY = 0;
    viewport.addEventListener('pointerdown', (e) => {
      dragging = true; startX = e.clientX; startY = e.clientY;
      startOffX = offsetX; startOffY = offsetY;
      viewport.setPointerCapture(e.pointerId);
      viewport.style.cursor = 'grabbing';
    });
    viewport.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      offsetX = startOffX + (e.clientX - startX);
      offsetY = startOffY + (e.clientY - startY);
      applyTransform();
    });
    function endDrag() { dragging = false; viewport.style.cursor = 'grab'; }
    viewport.addEventListener('pointerup', endDrag);
    viewport.addEventListener('pointercancel', endDrag);

    zoomSlider.addEventListener('input', () => {
      currentScale = baseScale * (Number(zoomSlider.value) / 100);
      applyTransform();
    });

    function cleanup(result) {
      URL.revokeObjectURL(objectUrl);
      backdrop.remove();
      resolve(result);
    }

    backdrop.querySelectorAll('[data-cropper-cancel]').forEach((btn) => {
      btn.addEventListener('click', () => cleanup(null));
    });
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) cleanup(null); });

    backdrop.querySelector('[data-cropper-confirm]').addEventListener('click', () => {
      const outSize = opts.outputSize;
      const canvas = document.createElement('canvas');
      canvas.width = outSize; canvas.height = outSize;
      const ctx = canvas.getContext('2d');
      const sx = -offsetX / currentScale;
      const sy = -offsetY / currentScale;
      const sSize = VIEWPORT / currentScale;
      ctx.drawImage(img, sx, sy, sSize, sSize, 0, 0, outSize, outSize);
      canvas.toBlob((blob) => cleanup(blob), 'image/jpeg', 0.92);
    });
  });
}
