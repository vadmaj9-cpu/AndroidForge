package com.aurora.player

import android.Manifest
import android.app.UiModeManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject

/**
 * Object exposed to the web app as `window.AuroraNative`.
 * JS -> native: plain method calls. Native -> JS: window.__auroraEvent(type, data).
 */
class NativeBridge(private val act: MainActivity, private val web: WebView) {
    private val main = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private val pending = ArrayList<(MediaController) -> Unit>()
    private var visible = false

    private val ticker = object : Runnable {
        override fun run() {
            if (visible) {
                pushState("state")
                main.postDelayed(this, 250)
            }
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = pushState("state")
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = pushState("state")
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = pushState("state")
        override fun onPlaybackStateChanged(playbackState: Int) {
            pushState("state")
            if (playbackState == Player.STATE_ENDED) emit("ended", "{}")
        }

        override fun onPlayerError(error: PlaybackException) {
            emit("error", JSONObject().put("message", error.errorCodeName).toString())
            // a file that can't be played (deleted, unsupported): skip to the next one
            controller?.let { c ->
                if (c.hasNextMediaItem()) {
                    c.seekToNextMediaItem()
                    c.prepare()
                    c.play()
                }
            }
        }
    }

    // ---------- lifecycle ----------
    fun connect() {
        val token = SessionToken(act, ComponentName(act, PlaybackService::class.java))
        val f = MediaController.Builder(act, token).buildAsync()
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                pending.forEach { it(c) }
                pending.clear()
                pushState("sync")
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(act))
    }

    fun setVisible(v: Boolean) {
        visible = v
        main.removeCallbacks(ticker)
        if (v) {
            pushState("state")
            main.postDelayed(ticker, 250)
        }
    }

    fun release() {
        main.removeCallbacks(ticker)
        controller?.removeListener(listener)
        controller?.release()
        controller = null
    }

    fun onPermissionResult() {
        emit("perm", JSONObject().put("granted", hasPerm()).toString())
    }

    private fun withController(block: (MediaController) -> Unit) {
        main.post {
            val c = controller
            if (c != null) block(c) else pending.add(block)
        }
    }

    private fun emit(type: String, json: String) {
        main.post {
            web.evaluateJavascript("window.__auroraEvent&&window.__auroraEvent('$type',$json)", null)
        }
    }

    private fun pushState(type: String) {
        val c = controller ?: return
        val o = JSONObject()
        o.put("wantsPlay", c.playWhenReady)
        o.put("playing", c.isPlaying)
        o.put("state", c.playbackState)
        o.put("positionMs", c.currentPosition)
        o.put("durationMs", if (c.duration == C.TIME_UNSET) 0L else c.duration)
        o.put("index", c.currentMediaItemIndex)
        o.put("count", c.mediaItemCount)
        val item = c.currentMediaItem
        o.put("songId", item?.mediaId ?: "")
        o.put("playlistId", item?.mediaMetadata?.extras?.getString("playlistId") ?: "")
        emit(type, o.toString())
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(act, p) == PackageManager.PERMISSION_GRANTED
    private fun hasPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= 33) granted(Manifest.permission.READ_MEDIA_AUDIO)
        else granted(Manifest.permission.READ_EXTERNAL_STORAGE)

    // ---------- device info / permissions ----------
    @JavascriptInterface
    fun isTv(): Boolean {
        val ui = act.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            act.packageManager.hasSystemFeature("android.software.leanback")
    }

    @JavascriptInterface
    fun hasAudioPermission(): Boolean = hasPerm()

    @JavascriptInterface
    fun requestAudioPermission() {
        act.runOnUiThread { act.requestAudioPermissions() }
    }

    @JavascriptInterface
    fun requestSync() {
        main.post { pushState("sync") }
    }

    // ---------- song library ----------
    @JavascriptInterface
    fun listAudio(allFiles: Boolean): String {
        val out = JSONArray()
        val collection: Uri =
            if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME
        )
        val selection =
            if (allFiles) "${MediaStore.Audio.Media.DURATION} >= 10000"
            else "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        try {
            act.contentResolver.query(
                collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iArtist) ?: ""
                    val album = c.getString(iAlbum) ?: ""
                    val name = (c.getString(iName) ?: "").substringBeforeLast('.')
                    val o = JSONObject()
                    o.put("id", id.toString())
                    o.put("uri", ContentUris.withAppendedId(collection, id).toString())
                    o.put("title", c.getString(iTitle) ?: name)
                    o.put("artist", if (artist == MediaStore.UNKNOWN_STRING) "" else artist)
                    o.put("album", if (album == MediaStore.UNKNOWN_STRING) "" else album)
                    o.put("duration", c.getLong(iDur) / 1000)
                    o.put("name", name)
                    out.put(o)
                }
            }
        } catch (_: Exception) {
        }
        return out.toString()
    }

    /** Cover art as base64 JPEG ("" when the song has none). */
    @JavascriptInterface
    fun getArt(uri: String): String {
        val bmp = AudioArt.load(act, Uri.parse(uri), 512) ?: return ""
        return Base64.encodeToString(AudioArt.jpeg(bmp, 85), Base64.NO_WRAP)
    }

    // ---------- playback ----------
    @JavascriptInterface
    fun setQueue(json: String, play: Boolean) {
        val o = JSONObject(json)
        val arr = o.getJSONArray("items")
        val playlistId = o.optString("playlistId")
        val index = o.optInt("index", 0)
        val repeat = o.optString("repeat", "off")
        val items = ArrayList<MediaItem>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val extras = Bundle()
            extras.putString("playlistId", playlistId)
            val uri = Uri.parse(s.getString("uri"))
            val meta = MediaMetadata.Builder()
                .setTitle(s.optString("title"))
                .setArtist(s.optString("artist"))
                .setAlbumTitle(s.optString("album"))
                .setArtworkUri(uri)
                .setExtras(extras)
                .build()
            items.add(
                MediaItem.Builder()
                    .setMediaId(s.optString("id"))
                    .setUri(uri)
                    .setMediaMetadata(meta)
                    .build()
            )
        }
        withController { c ->
            c.setMediaItems(items, index.coerceIn(0, maxOf(0, items.size - 1)), 0L)
            c.repeatMode = repeatMode(repeat)
            c.prepare()
            if (play) c.play() else c.pause()
        }
    }

    private fun repeatMode(m: String) = when (m) {
        "one" -> Player.REPEAT_MODE_ONE
        "all" -> Player.REPEAT_MODE_ALL
        else -> Player.REPEAT_MODE_OFF
    }

    @JavascriptInterface fun play() { withController { it.play() } }
    @JavascriptInterface fun pause() { withController { it.pause() } }
    @JavascriptInterface fun next() { withController { it.seekToNextMediaItem() } }
    @JavascriptInterface fun prev() { withController { it.seekToPreviousMediaItem() } }
    @JavascriptInterface fun seekTo(ms: Double) { withController { it.seekTo(ms.toLong()) } }
    @JavascriptInterface fun setSpeed(rate: Double) { withController { it.playbackParameters = PlaybackParameters(rate.toFloat()) } }
    @JavascriptInterface fun setRepeat(mode: String) { withController { it.repeatMode = repeatMode(mode) } }
    @JavascriptInterface fun stop() { withController { it.stop(); it.clearMediaItems() } }
}
