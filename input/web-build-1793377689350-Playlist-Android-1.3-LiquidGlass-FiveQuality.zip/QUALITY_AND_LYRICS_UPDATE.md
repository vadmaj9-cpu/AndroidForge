# Playlist 1.3: Liquid Glass, five quality levels, lyrics always on, picker upgrades

- Package id set to `com.mamadjavad.playlist` (versionName 1.3, versionCode 4).
- Lyrics remain enabled on every quality level (Very low → Very high). Only heavy decorative effects are reduced on lower tiers.
- Very-high Liquid-Glass treatment refined (layered glass, controlled blur, cover-tinted highlights). Prefers-reduced-motion respected.
- Device song picker: cover thumbnails (lazy), artist/album/duration, preview play/pause that does not conflict with main playback.
- Lyrics panel cleaned: removed duplicate “lyrics” label and heavy dedicated background; tighter spacing.
- Launcher icons regenerated from project logo for all densities.
- Auto quality detection and i18n names for the five levels preserved and corrected where needed.

Note: Without the previous release keystore, an APK built here cannot be guaranteed as an over-the-air update of a previously signed build.
