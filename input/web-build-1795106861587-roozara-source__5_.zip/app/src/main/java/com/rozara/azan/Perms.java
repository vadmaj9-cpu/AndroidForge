package com.rozara.azan;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

/** وضعیت مجوزهای لازم برای اذان (برای نمایش در چک‌لیست داخل برنامه). */
final class Perms {
    private Perms() {}

    private static void add(JSONArray a, String id, String title, String desc, boolean ok, boolean critical, boolean manual) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("title", title);
            o.put("desc", desc);
            o.put("ok", ok);
            o.put("critical", critical);
            o.put("manual", manual);
            a.put(o);
        } catch (Throwable ignored) {
        }
    }

    static String status(Context c) {
        JSONArray a = new JSONArray();
        add(a, "notif", "اعلان‌ها", "نوتیف اذان و تاریخ", Notifs.canPost(c), true, false);
        if (Build.VERSION.SDK_INT >= 31) {
            boolean ok = ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();
            add(a, "exact", "آلارم دقیق", "تا اذان سر وقت پخش شود", ok, true, false);
        }
        if (Build.VERSION.SDK_INT >= 34) {
            boolean ok = ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();
            add(a, "fsi", "نمایش روی قفل‌صفحه", "صفحهٔ اذان وقتی گوشی قفل یا خاموش است", ok, true, false);
        }
        add(a, "overlay", "نمایش روی سایر برنامه‌ها", "صفحهٔ کامل اذان روی صفحهٔ اصلی گوشی", Settings.canDrawOverlays(c), true, false);
        add(a, "usage", "دسترسی به مصرف برنامه‌ها", "تشخیص اینکه داخل برنامهٔ دیگری (بازی، گالری…) هستی تا فقط نوتیف بیاید", Foreground.hasUsageAccess(c), true, false);
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        add(a, "battery", "بدون محدودیت باتری", "جلوگیری از کشته شدن برنامه توسط گوشی", pm.isIgnoringBatteryOptimizations(c.getPackageName()), true, false);
        return a.toString();
    }
}
