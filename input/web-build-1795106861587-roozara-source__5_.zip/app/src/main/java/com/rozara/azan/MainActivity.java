package com.rozara.azan;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    static volatile boolean visible = false;
    private static MainActivity inst;
    private static final int REQ_LOC = 77;
    private static final int REQ_NOTIF = 78;
    private static final String URL = "file:///android_asset/www/index.html";

    private WebView wv;

    /** اجرای کد جاوااسکریپت در صفحهٔ اصلی (از هر نخی) */
    static void evalJs(final String code) {
        final MainActivity a = inst;
        if (a == null) return;
        a.runOnUiThread(() -> { if (a.wv != null) a.wv.evaluateJavascript(code, null); });
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private WebView makeWebView() {
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.parseColor("#FDF6E3"));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        w.setLongClickable(false);
        w.setHapticFeedbackEnabled(false);
        w.setOnLongClickListener(v -> true); // جلوگیری از انتخاب و کپی متن
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage m) { return true; }
        });
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                // موتور صفحه (مثلاً به‌خاطر کمبود حافظه) کشته شد: به‌جای صفحهٔ سفید، دوباره بساز
                Diag.add(getApplicationContext(), "WebView کشته شد (" + (d != null && d.didCrash() ? "کرش" : "کمبود حافظه") + ")؛ بازسازی شد");
                runOnUiThread(MainActivity.this::recreateWebView);
                return true;
            }
        });
        w.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        return w;
    }

    private void recreateWebView() {
        try {
            if (wv != null) {
                ViewGroup p = (ViewGroup) wv.getParent();
                if (p != null) p.removeView(wv);
                wv.destroy();
            }
        } catch (Throwable ignored) {
        }
        wv = makeWebView();
        setContentView(wv);
        wv.loadUrl(URL);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = this;
        Ui.immersive(this);
        wv = makeWebView();
        setContentView(wv);
        wv.loadUrl(URL);

        new Thread(() -> {
            Scheduler.scheduleAll(getApplicationContext());
            DateNotifier.update(getApplicationContext());
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        Ui.immersive(this);
        if (wv != null) {
            wv.onResume();
            wv.resumeTimers();
            wv.evaluateJavascript("window.onNativeResume&&window.onNativeResume()", null);
        }
        new Thread(() -> {
            Scheduler.scheduleAll(getApplicationContext());
            DateNotifier.update(getApplicationContext());
        }).start();
        if (!KeepAliveService.running) KeepAliveService.start(this);
    }

    @Override
    protected void onPause() {
        visible = false;
        Bridge.previewRelease();
        if (wv != null) wv.onPause();
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (inst == this) inst = null;
        if (wv != null) { wv.destroy(); wv = null; }
        super.onDestroy();
    }

    // ---------- مکان‌یابی ----------
    void startLocation() {
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        LocationHelper.fetch(this, new LocationHelper.Callback() {
            @Override public void ok(double lat, double lon, String place) {
                js("window.onNativeLocation&&window.onNativeLocation(" + lat + "," + lon + "," + JSONObject.quote(place == null ? "" : place) + ")");
            }
            @Override public void error(String code) {
                js("window.onNativeLocationError&&window.onNativeLocationError(" + JSONObject.quote(code) + ")");
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = false;
        for (int r : res) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
        if (code == REQ_LOC) {
            if (ok) startLocation();
            else js("window.onNativeLocationError&&window.onNativeLocationError('denied')");
        } else if (code == REQ_NOTIF) {
            if (!ok) openNotificationSettings(); // اگر قبلاً «نه» زده شده، پنجره دیگر نمی‌آید؛ مستقیم تنظیمات
        }
    }

    private void js(final String code) {
        runOnUiThread(() -> { if (wv != null) wv.evaluateJavascript(code, null); });
    }

    // ---------- چک‌لیست مجوزها ----------
    void fixPermission(String id) {
        String pkg = getPackageName();
        Uri uri = Uri.parse("package:" + pkg);
        switch (id) {
            case "notif":
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                else openNotificationSettings();
                break;
            case "exact":
                if (Build.VERSION.SDK_INT >= 31) launch(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, uri));
                break;
            case "fsi":
                if (Build.VERSION.SDK_INT >= 34) launch(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, uri));
                break;
            case "overlay":
                Toast.makeText(this, "«روزآرا» را پیدا کن و «اجازه نمایش روی سایر برنامه‌ها» را روشن کن", Toast.LENGTH_LONG).show();
                launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri));
                break;
            case "usage":
                Toast.makeText(this, "«روزآرا» را پیدا کن و «اجازهٔ دسترسی به مصرف برنامه‌ها» را روشن کن", Toast.LENGTH_LONG).show();
                if (!launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, uri))) launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                break;
            case "battery":
                if (!launch(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, uri)))
                    launch(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                break;
            default:
                break;
        }
    }

    private void openNotificationSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        if (!launch(i)) launch(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
    }

    private boolean launch(Intent i) {
        try {
            startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
