package com.rozara.azan;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

/** پل بین جاوااسکریپت صفحه و بخش بومی اندروید. */
public class Bridge {
    private final Activity act;
    private final Context app;

    Bridge(Activity a) {
        act = a;
        app = a.getApplicationContext();
    }

    @JavascriptInterface
    public String getItem(String k) {
        return Prefs.get(app, k);
    }

    @JavascriptInterface
    public void setItem(String k, String v) {
        Prefs.set(app, k, v);
        if ("roozara_state".equals(k) || "roozara_onboarded".equals(k)) refresh();
    }

    private void refresh() {
        new Thread(() -> {
            Scheduler.scheduleAll(app);
            DateNotifier.update(app);
            KeepAliveService.start(app);
        }).start();
    }

    @JavascriptInterface
    public void requestLocation() {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).startLocation());
    }

    /** باز کردن چک‌لیست مجوزها داخل برنامه */
    @JavascriptInterface
    public void requestPermissions() {
        MainActivity.evalJs("window.openPerm&&window.openPerm()");
    }

    @JavascriptInterface
    public String permStatus() {
        return Perms.status(app);
    }

    @JavascriptInterface
    public void fixPermission(final String id) {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).fixPermission(id));
    }

    // ---------- پخش نمونهٔ مؤذن با پخش‌کنندهٔ بومی (سبک‌تر از <audio> داخل WebView) ----------
    private static MediaPlayer pv;
    private static String pvKey;
    private static boolean pvPaused;

    static synchronized void previewRelease() {
        try {
            if (pv != null) { try { pv.stop(); } catch (Throwable ignored) { } pv.release(); }
        } catch (Throwable ignored) {
        }
        pv = null; pvKey = null; pvPaused = false;
    }

    @JavascriptInterface
    public void previewStart(final String key, final int vol) {
        act.runOnUiThread(() -> {
            try {
                synchronized (Bridge.class) {
                    if (pv != null && key.equals(pvKey) && pvPaused) { pv.start(); pvPaused = false; return; }
                    previewRelease();
                    AssetFileDescriptor afd = app.getAssets().openFd(AdhanService.soundFile(key));
                    MediaPlayer m = new MediaPlayer();
                    m.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    m.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    afd.close();
                    float v = Math.max(0f, Math.min(1f, vol / 100f));
                    m.setVolume(v, v);
                    m.setOnPreparedListener(MediaPlayer::start);
                    m.setOnCompletionListener(mm -> { previewRelease(); MainActivity.evalJs("window.onNativePreviewEnded&&window.onNativePreviewEnded()"); });
                    m.setOnErrorListener((mm, w, e) -> { previewRelease(); MainActivity.evalJs("window.onNativePreviewEnded&&window.onNativePreviewEnded()"); return true; });
                    pv = m; pvKey = key; pvPaused = false;
                    m.prepareAsync();
                }
            } catch (Throwable t) {
                Diag.add(app, "پخش نمونه ناموفق: " + t.getClass().getSimpleName());
                previewRelease();
                MainActivity.evalJs("window.onNativePreviewEnded&&window.onNativePreviewEnded()");
            }
        });
    }

    @JavascriptInterface
    public void previewPause() {
        act.runOnUiThread(() -> {
            synchronized (Bridge.class) {
                try { if (pv != null && !pvPaused) { pv.pause(); pvPaused = true; } } catch (Throwable ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void previewStop() {
        act.runOnUiThread(Bridge::previewRelease);
    }

    @JavascriptInterface
    public void adhanStop() {
        AdhanService.stop(app);
        if (act instanceof AdhanActivity) act.runOnUiThread(act::finish);
    }

    /** مکث/ادامهٔ اذان؛ مقدار برگشتی: آیا اکنون در حال پخش است */
    @JavascriptInterface
    public boolean adhanToggle() {
        return AdhanService.toggleFromBridge();
    }

    @JavascriptInterface
    public void scheduleTestAdhan(int seconds) {
        int s = Math.max(3, seconds);
        Scheduler.scheduleTest(app, s);
        toast("اذان آزمایشی تا " + Cal.fa(s) + " ثانیه دیگر پخش می‌شود. صفحه را قفل کن و ببین!");
    }

    @JavascriptInterface
    public void toast(final String msg) {
        act.runOnUiThread(() -> Toast.makeText(act, msg, Toast.LENGTH_LONG).show());
    }

    @JavascriptInterface
    public void openAppSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    @JavascriptInterface
    public String getDiag() {
        return Diag.report(app);
    }

    @JavascriptInterface
    public void copyText(final String text) {
        act.runOnUiThread(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("roozara", text));
                Toast.makeText(act, "کپی شد", Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {
            }
        });
    }

    /** مشخصات دستگاه برای «حالت سبک»: lite=true یعنی انیمیشن‌ها و جلوه‌های سنگین خاموش شوند */
    @JavascriptInterface
    public String deviceInfo() {
        try {
            ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long ramMb = mi.totalMem / (1024L * 1024L);
            boolean lowRam = am.isLowRamDevice();
            int cores = Runtime.getRuntime().availableProcessors();
            int sdk = android.os.Build.VERSION.SDK_INT;
            String ov = Prefs.get(app, "roozara_perf");
            String probe = Prefs.get(app, "roozara_perf_probe");
            String base;
            if (lowRam || ramMb < 3300 || cores <= 4 || sdk <= 27) base = "low";
            else if (ramMb < 6000 || sdk <= 29 || cores <= 6) base = "medium";
            else base = "high";
            String tier;
            if ("high".equals(ov) || "full".equals(ov)) tier = "high";
            else if ("medium".equals(ov)) tier = "medium";
            else if ("low".equals(ov) || "lite".equals(ov)) tier = "low";
            else {
                tier = base;
                String pr = ("lite".equals(probe) ? "low" : probe);
                if (rank(pr) > rank(tier)) tier = pr;
            }
            JSONObject o = new JSONObject();
            o.put("tier", tier);
            o.put("ram_mb", ramMb);
            o.put("cores", cores);
            o.put("sdk", sdk);
            o.put("low_ram", lowRam);
            o.put("lite", "low".equals(tier));
            return o.toString();
        } catch (Throwable t) {
            return "{\"lite\":false}";
        }
    }

    private static int rank(String t) {
        if ("low".equals(t)) return 2;
        if ("medium".equals(t)) return 1;
        return 0;
    }

    /** سازگاری با نسخهٔ قبل */
    @JavascriptInterface
    public void setBars(boolean dark) { }

    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("native", true);
            o.put("sdk", android.os.Build.VERSION.SDK_INT);
            return o.toString();
        } catch (Throwable t) {
            return "{}";
        }
    }
}
