package com.rozara.azan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String type = intent.getStringExtra("type");
            String key = intent.getStringExtra("key");
            long at = intent.getLongExtra("at", 0);
            long now = System.currentTimeMillis();
            if (type == null) type = "daily";

            switch (type) {
                case "adhan":
                case "test": {
                    boolean test = "test".equals(type);
                    JSONObject st = Prefs.state(ctx);
                    JSONObject pr = st.optJSONObject("prayers");
                    boolean enabled = test || pr == null || pr.optBoolean(key, true);
                    if (enabled && (test || Math.abs(now - at) < 3 * 60000L)) {
                        Intent s = new Intent(ctx, AdhanService.class)
                                .setAction(AdhanService.ACTION_START).putExtra("key", key);
                        try {
                            ctx.startForegroundService(s);
                        } catch (Throwable fgsDenied) {
                            // اگر اندروید شروع سرویس از پس‌زمینه را نداد: نوتیف تمام‌صفحه؛ صفحهٔ اذان خودش پخش را شروع می‌کند
                            Notifs.adhanFallback(ctx, key);
                        }
                    }
                    break;
                }
                case "reminder": {
                    JSONObject st = Prefs.state(ctx);
                    JSONObject pr = st.optJSONObject("prayers");
                    int minutes = st.optInt("reminder", 10);
                    boolean enabled = pr == null || pr.optBoolean(key, true);
                    if (enabled && minutes > 0 && Math.abs(now - (at - minutes * 60000L)) < 5 * 60000L) {
                        Notifs.reminder(ctx, key, at, minutes);
                    }
                    break;
                }
                case "bday": {
                    JSONObject st = Prefs.state(ctx);
                    if (st.optBoolean("showBday", true) && st.optJSONObject("birthday") != null) Notifs.birthday(ctx);
                    break;
                }
                default:
                    break;
            }
            Scheduler.scheduleAll(ctx);
            DateNotifier.update(ctx);
        } catch (Throwable t) {
            Log.e("RoozaraAlarm", "onReceive failed", t);
        }
    }
}
