package com.rozara.azan;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.util.Log;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.time.LocalDate;

/**
 * نوتیف دائمی تاریخ: کارت زیبا با فونت ابریشم (شمسی/میلادی/قمری/مناسبت/اذان بعدی)
 * و عدد روزِ ماه شمسی به‌عنوان آیکون کوچک کنار ساعت در نوار وضعیت.
 */
final class DateNotifier {
    private static final String TAG = "RoozaraDate";
    private static Typeface cachedFont;

    private DateNotifier() {}

    static void update(Context ctx) {
        try {
            NotificationManager nm = Notifs.nm(ctx);
            JSONObject st = Prefs.state(ctx);
            boolean enabled = st.optBoolean("dateNotif", true);
            if (!Prefs.onboarded(ctx) || !enabled) {
                nm.cancel(Notifs.ID_DATE);
                return;
            }
            if (!Notifs.canPost(ctx)) return;
            Notifs.ensureChannels(ctx);

            long now = System.currentTimeMillis();
            LocalDate today = Cal.iranDate(now);
            Cal.Day day = Cal.dayFor(today);
            Typeface tf = font(ctx);

            String l1 = Cal.WEEKDAYS[day.weekday] + " " + Cal.fa(day.jd) + " " + Cal.MONTHS[day.jm - 1] + " " + Cal.fa(day.jy);
            String greg = Cal.fa(today.getDayOfMonth()) + " " + Cal.GREG[today.getMonthValue() - 1] + " " + Cal.fa(today.getYear());
            String hij = Cal.fa(day.hd) + " " + Cal.HIJRI[day.hm - 1] + " " + Cal.fa(day.hy);

            StringBuilder occ = new StringBuilder();
            if (day.officialOff) occ.append("تعطیل رسمی");
            else if (day.friday) occ.append("تعطیل آخر هفته");
            for (String e : day.events) {
                if (occ.length() > 0) occ.append(" — ");
                occ.append(e);
            }
            String next = nextAdhanText(st, now);

            Bitmap small = renderCard(tf, false, l1, greg, hij, occ.toString(), next);
            Bitmap big = renderCard(tf, true, l1, greg, hij, occ.toString(), next);
            Bitmap dayIcon = renderDayIcon(tf, Cal.fa(day.jd));

            RemoteViews rvSmall = new RemoteViews(ctx.getPackageName(), R.layout.notif_card);
            rvSmall.setImageViewBitmap(R.id.card, small);
            RemoteViews rvBig = new RemoteViews(ctx.getPackageName(), R.layout.notif_card);
            rvBig.setImageViewBitmap(R.id.card, big);

            PendingIntent del = PendingIntent.getBroadcast(ctx, 21, new Intent(ctx, NotifDismissReceiver.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder b = new Notification.Builder(ctx, Notifs.CH_DATE)
                    .setSmallIcon(Icon.createWithBitmap(dayIcon))
                    .setContentTitle(l1)
                    .setContentText(greg + " • " + hij)
                    .setStyle(new Notification.DecoratedCustomViewStyle())
                    .setCustomContentView(rvSmall)
                    .setCustomBigContentView(rvBig)
                    .setOngoing(true)
                    .setShowWhen(false)
                    .setOnlyAlertOnce(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setContentIntent(Notifs.openMain(ctx))
                    .setDeleteIntent(del);
            nm.notify(Notifs.ID_DATE, b.build());
        } catch (Throwable t) {
            Log.e(TAG, "update failed", t);
        }
    }

    /** فونت ابریشم اگر فایلش در assets/fonts باشد؛ وگرنه وزیرمتن؛ وگرنه فونت سیستم */
    static Typeface font(Context ctx) {
        if (cachedFont != null) return cachedFont;
        String[] names = {"fonts/abrisham.ttf", "fonts/abrisham.otf", "fonts/Vazirmatn-Bold.ttf", "fonts/Vazirmatn.ttf"};
        for (String n : names) {
            try {
                cachedFont = Typeface.createFromAsset(ctx.getAssets(), n);
                return cachedFont;
            } catch (Throwable ignored) {
            }
        }
        cachedFont = Typeface.create("sans-serif", Typeface.BOLD);
        return cachedFont;
    }

    private static String nextAdhanText(JSONObject st, long now) {
        try {
            double[] co = Prefs.coords(st);
            String method = st.optString("method", "tehran");
            JSONObject pr = st.optJSONObject("prayers");
            LocalDate today = Cal.iranDate(now);
            int cur = Cal.iranMinuteOfDay(now);
            for (int d = 0; d < 2; d++) {
                int[] t = PrayerCalc.times(co[0], co[1], method, today.plusDays(d));
                for (int p = 0; p < 5; p++) {
                    String key = PrayerCalc.KEYS[p];
                    if (pr != null && !pr.optBoolean(key, true)) continue;
                    int m = PrayerCalc.minuteOf(t, p);
                    if (m < 0) continue;
                    if (d == 1 || m > cur) {
                        return "اذان بعدی: " + PrayerCalc.name(key) + " — " + Cal.clock(m) + (d == 1 ? " (فردا)" : "");
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static Bitmap renderCard(Typeface tf, boolean expanded, String l1, String greg, String hij, String occ, String next) {
        int w = 1080;
        int h = expanded ? 400 : 200;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float rad = 46f;

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setShader(new LinearGradient(w, 0, 0, h,
                new int[]{0xFF054A44, 0xFF0A7A6F, 0xFF16A08F},
                new float[]{0f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, w, h), rad, rad, bg);

        // درخشش طلایی گوشهٔ پایین-چپ
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(60, h, h * 1.1f, 0x55D4A017, 0x00D4A017, Shader.TileMode.CLAMP));
        c.save();
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, w, h), rad, rad, Path.Direction.CW);
        c.clipPath(clip);
        c.drawRect(0, 0, w, h, glow);

        // حلقه‌های تزئینی گوشهٔ بالا-راست
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(3f);
        ring.setColor(0x26FFFFFF);
        c.drawCircle(w - 40, -30, h * 0.72f, ring);
        ring.setColor(0x14FFFFFF);
        c.drawCircle(w - 40, -30, h * 0.98f, ring);
        c.restore();

        // هلال طلایی سمت چپ
        float r = expanded ? 74f : 54f;
        float cx = 60f + r, cy = expanded ? 110f : h / 2f;
        Path outer = new Path();
        outer.addCircle(cx, cy, r, Path.Direction.CW);
        Path inner = new Path();
        inner.addCircle(cx + r * 0.48f, cy - r * 0.26f, r * 0.84f, Path.Direction.CW);
        outer.op(inner, Path.Op.DIFFERENCE);
        Paint gold = new Paint(Paint.ANTI_ALIAS_FLAG);
        gold.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFFF1D58A, 0xFFC99A2E, Shader.TileMode.CLAMP));
        c.drawPath(outer, gold);

        // کادر ظریف
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2f);
        border.setColor(0x33FFFFFF);
        c.drawRoundRect(new RectF(1, 1, w - 1, h - 1), rad, rad, border);

        float right = w - 52f;
        float left = (expanded ? 60f + 2 * r + 40f : 60f + 2 * r + 36f);
        float maxW = right - left;

        if (!expanded) {
            float y = 26f;
            y += line(c, l1, tf, 70f, Color.WHITE, right, y, maxW, 40f) + 4f;
            line(c, greg + "  •  " + hij, tf, 36f, 0xFFF1D99E, right, y, maxW, 22f);
        } else {
            float y = 34f;
            y += line(c, l1, tf, 78f, Color.WHITE, right, y, maxW, 44f) + 6f;
            y += line(c, greg + " میلادی", tf, 42f, 0xFFF1D99E, right, y, maxW, 24f) + 2f;
            y += line(c, hij + " قمری", tf, 42f, 0xFFF1D99E, right, y, maxW, 24f) + 14f;

            Paint div = new Paint(Paint.ANTI_ALIAS_FLAG);
            div.setColor(0x55F1D99E);
            div.setStrokeWidth(2f);
            c.drawLine(left, y, right, y, div);
            drawDiamond(c, (left + right) / 2f, y, 9f, 0xFFF1D99E);
            y += 18f;

            if (!occ.isEmpty()) {
                int col = occ.startsWith("تعطیل رسمی") ? 0xFFFFD6DB : 0xFFFFFFFF;
                y += line(c, occ, tf, 40f, col, right, y, maxW, 24f) + 4f;
            }
            if (!next.isEmpty()) {
                line(c, next, tf, 40f, 0xFFE9F7F4, right, y, maxW, 24f);
            }
        }
        return bmp;
    }

    private static void drawDiamond(Canvas c, float x, float y, float r, int color) {
        Path p = new Path();
        p.moveTo(x, y - r);
        p.lineTo(x + r, y);
        p.lineTo(x, y + r);
        p.lineTo(x - r, y);
        p.close();
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setColor(color);
        c.drawPath(p, pt);
    }

    /** یک خط راست‌به‌چپ را با کوچک‌کردن خودکار تا جا شود می‌کشد؛ ارتفاع را برمی‌گرداند. */
    private static float line(Canvas c, String text, Typeface tf, float size, int color, float right, float top, float maxW, float minSize) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setColor(color);
        p.setTextSize(size);
        while (p.measureText(text) > maxW && p.getTextSize() > minSize) p.setTextSize(p.getTextSize() - 2f);
        StaticLayout sl = StaticLayout.Builder.obtain(text, 0, text.length(), p, (int) maxW)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .build();
        c.save();
        c.translate(right - maxW, top);
        sl.draw(c);
        c.restore();
        return sl.getHeight();
    }

    /** آیکون وضعیت: عدد روز (سفید روی شفاف) */
    private static Bitmap renderDayIcon(Typeface tf, String dayText) {
        int s = 96;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setColor(Color.WHITE);
        p.setFakeBoldText(true);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(86f);
        while (p.measureText(dayText) > s - 4 && p.getTextSize() > 30f) p.setTextSize(p.getTextSize() - 2f);
        Paint.FontMetrics fm = p.getFontMetrics();
        float y = s / 2f - (fm.ascent + fm.descent) / 2f;
        c.drawText(dayText, s / 2f, y, p);
        return bmp;
    }
}
