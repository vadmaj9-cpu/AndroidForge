package com.rozara.azan;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

/** پل بین جاوااسکریپت صفحه و بخش بومی اندروید. */
public class Bridge {
    private final Activity act;
    private final Context app;

    Bridge(Activity a) {
        act = a;
        app = a.getApplicationContext();
    }

    @JavascriptInterface
    public String getItem(String k) {
        return Prefs.get(app, k);
    }

    @JavascriptInterface
    public void setItem(String k, String v) {
        Prefs.set(app, k, v);
        if ("roozara_state".equals(k) || "roozara_onboarded".equals(k)) refresh();
    }

    private void refresh() {
        new Thread(() -> {
            Scheduler.scheduleAll(app);
            DateNotifier.update(app);
        }).start();
    }

    @JavascriptInterface
    public void requestLocation() {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).startLocation());
    }

    @JavascriptInterface
    public void requestPermissions() {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).startPermissionFlow());
    }

    @JavascriptInterface
    public void adhanStop() {
        AdhanService.stop(app);
        if (act instanceof AdhanActivity) act.runOnUiThread(act::finish);
    }

    /** مکث/ادامهٔ اذان؛ مقدار برگشتی: آیا اکنون در حال پخش است */
    @JavascriptInterface
    public boolean adhanToggle() {
        return AdhanService.toggleFromBridge();
    }

    @JavascriptInterface
    public void scheduleTestAdhan(int seconds) {
        Scheduler.scheduleTest(app, Math.max(3, seconds));
        toast("اذان آزمایشی تا " + Cal.fa(Math.max(3, seconds)) + " ثانیه دیگر پخش می‌شود. صفحه را قفل کن و ببین!");
    }

    @JavascriptInterface
    public void toast(final String msg) {
        act.runOnUiThread(() -> Toast.makeText(act, msg, Toast.LENGTH_LONG).show());
    }

    @JavascriptInterface
    public void openAppSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    /** سازگاری با نسخهٔ قبل؛ حالت تمام‌صفحه است و رنگ نوارها اهمیتی ندارد */
    @JavascriptInterface
    public void setBars(boolean dark) { }

    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("native", true);
            o.put("sdk", android.os.Build.VERSION.SDK_INT);
            return o.toString();
        } catch (Throwable t) {
            return "{}";
        }
    }
}
