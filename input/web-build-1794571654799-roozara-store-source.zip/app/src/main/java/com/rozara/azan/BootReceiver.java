package com.rozara.azan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** بعد از ریبوت، آپدیت برنامه یا تغییر ساعت: آلارم‌ها و نوتیف تاریخ دوباره ساخته می‌شوند. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            Scheduler.scheduleAll(ctx);
            DateNotifier.update(ctx);
        } catch (Throwable ignored) {
        }
    }
}
