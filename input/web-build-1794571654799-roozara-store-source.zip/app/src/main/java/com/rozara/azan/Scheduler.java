package com.rozara.azan;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import org.json.JSONObject;

import java.time.LocalDate;

/**
 * زمان‌بندی همهٔ آلارم‌ها (اذان، یادآوری، تولد، تغییر تاریخ نیمه‌شب).
 * با AlarmManager دقیق؛ حتی وقتی برنامه بسته یا گوشی در Doze باشد اجرا می‌شود.
 */
final class Scheduler {
    static final String ACT = "com.rozara.azan.ALARM";
    private static final String TAG = "RoozaraSched";

    private static final int B_ADHAN = 1000;
    private static final int B_REMIND = 2000;
    private static final int B_BDAY = 3000;
    private static final int C_DAILY = 4000;
    static final int C_TEST = 5000;

    private Scheduler() {}

    static synchronized void scheduleAll(Context ctx) {
        try {
            cancelAll(ctx);
            if (!Prefs.onboarded(ctx)) return;

            JSONObject st = Prefs.state(ctx);
            double[] co = Prefs.coords(st);
            String method = st.optString("method", "tehran");
            JSONObject prayers = st.optJSONObject("prayers");
            int reminder = st.optInt("reminder", 10);
            long now = System.currentTimeMillis();
            LocalDate today = Cal.iranDate(now);

            JSONObject b = st.optJSONObject("birthday");
            boolean showB = st.optBoolean("showBday", true);

            for (int d = 0; d < 3; d++) {
                LocalDate date = today.plusDays(d);
                int[] t = PrayerCalc.times(co[0], co[1], method, date);
                for (int p = 0; p < 5; p++) {
                    String key = PrayerCalc.KEYS[p];
                    if (prayers != null && !prayers.optBoolean(key, true)) continue;
                    int m = PrayerCalc.minuteOf(t, p);
                    if (m < 0) continue;
                    long at = Cal.millisOf(date, m);
                    if (at > now + 1000) set(ctx, at, B_ADHAN + d * 100 + p, "adhan", key, at);
                    if (reminder > 0) {
                        long rt = at - reminder * 60000L;
                        if (rt > now + 1000) set(ctx, rt, B_REMIND + d * 100 + p, "reminder", key, at);
                    }
                }
                if (b != null && showB) {
                    int[] j = Cal.g2j(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
                    if (j[1] == b.optInt("month", -1) && j[2] == b.optInt("day", -1)) {
                        long at = Cal.millisOf(date, 8 * 60);
                        if (at > now + 1000) set(ctx, at, B_BDAY + d, "bday", "", at);
                    }
                }
            }
            // به‌روزرسانی تاریخ بعد از نیمه‌شب (به وقت ایران)
            long mid = Cal.millisOf(today.plusDays(1), 0) + 5000L;
            set(ctx, mid, C_DAILY, "daily", "", mid);
        } catch (Throwable t) {
            Log.e(TAG, "scheduleAll failed", t);
        }
    }

    /** اذان آزمایشی چند ثانیه بعد (برای تست با صفحهٔ قفل) */
    static void scheduleTest(Context ctx, int seconds) {
        JSONObject st = Prefs.state(ctx);
        double[] co = Prefs.coords(st);
        long now = System.currentTimeMillis();
        int[] t = PrayerCalc.times(co[0], co[1], st.optString("method", "tehran"), Cal.iranDate(now));
        int cur = Cal.iranMinuteOfDay(now);
        String key = "fajr";
        for (int p = 0; p < 5; p++) {
            int m = PrayerCalc.minuteOf(t, p);
            if (m > cur) { key = PrayerCalc.KEYS[p]; break; }
        }
        long at = now + seconds * 1000L;
        set(ctx, at, C_TEST, "test", key, at);
    }

    private static PendingIntent pi(Context ctx, int code, String type, String key, long at) {
        Intent i = new Intent(ctx, AlarmReceiver.class).setAction(ACT)
                .putExtra("type", type).putExtra("key", key).putExtra("at", at);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void set(Context ctx, long triggerAt, int code, String type, String key, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(ctx, code, type, key, at);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, p);
        } else {
            PendingIntent show = PendingIntent.getActivity(ctx, 9, new Intent(ctx, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(triggerAt, show), p);
        }
    }

    private static void cancel(Context ctx, AlarmManager am, int code) {
        PendingIntent p = pi(ctx, code, "x", "", 0);
        am.cancel(p);
        p.cancel();
    }

    private static void cancelAll(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        for (int d = 0; d < 3; d++) {
            for (int p = 0; p < 5; p++) {
                cancel(ctx, am, B_ADHAN + d * 100 + p);
                cancel(ctx, am, B_REMIND + d * 100 + p);
            }
            cancel(ctx, am, B_BDAY + d);
        }
        cancel(ctx, am, C_DAILY);
    }
}
