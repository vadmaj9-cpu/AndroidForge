package com.rozara.azan;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

/** پل بین جاوااسکریپت صفحه و بخش بومی اندروید. */
public class Bridge {
    private final Activity act;
    private final Context app;

    Bridge(Activity a) {
        act = a;
        app = a.getApplicationContext();
    }

    @JavascriptInterface
    public String getItem(String k) {
        return Prefs.get(app, k);
    }

    @JavascriptInterface
    public void setItem(String k, String v) {
        Prefs.set(app, k, v);
        if ("roozara_state".equals(k) || "roozara_onboarded".equals(k)) refresh();
    }

    private void refresh() {
        new Thread(() -> {
            Scheduler.scheduleAll(app);
            DateNotifier.update(app);
            KeepAliveService.start(app);
        }).start();
    }

    @JavascriptInterface
    public void requestLocation() {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).startLocation());
    }

    @JavascriptInterface
    public void requestPermissions() {
        if (act instanceof MainActivity) act.runOnUiThread(() -> ((MainActivity) act).startPermissionFlow());
    }

    @JavascriptInterface
    public void adhanStop() {
        AdhanService.stop(app);
        if (act instanceof AdhanActivity) act.runOnUiThread(act::finish);
    }

    /** مکث/ادامهٔ اذان؛ مقدار برگشتی: آیا اکنون در حال پخش است */
    @JavascriptInterface
    public boolean adhanToggle() {
        return AdhanService.toggleFromBridge();
    }

    @JavascriptInterface
    public void scheduleTestAdhan(int seconds) {
        int s = Math.max(3, seconds);
        Scheduler.scheduleTest(app, s);
        toast("اذان آزمایشی تا " + Cal.fa(s) + " ثانیه دیگر پخش می‌شود. صفحه را قفل کن و ببین!");
    }

    @JavascriptInterface
    public void toast(final String msg) {
        act.runOnUiThread(() -> Toast.makeText(act, msg, Toast.LENGTH_LONG).show());
    }

    @JavascriptInterface
    public void openAppSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    /** صفحهٔ «شروع خودکار / باتری» مخصوص سازندهٔ گوشی */
    @JavascriptInterface
    public void openOemSettings() {
        final String hint = Oem.hint();
        act.runOnUiThread(() -> {
            Toast.makeText(act, hint, Toast.LENGTH_LONG).show();
            Oem.openSettings(act);
        });
    }

    @JavascriptInterface
    public String getDiag() {
        return Diag.report(app);
    }

    @JavascriptInterface
    public void copyText(final String text) {
        act.runOnUiThread(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("roozara", text));
                Toast.makeText(act, "کپی شد", Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {
            }
        });
    }

    /** مشخصات دستگاه برای «حالت سبک»: lite=true یعنی انیمیشن‌ها و جلوه‌های سنگین خاموش شوند */
    @JavascriptInterface
    public String deviceInfo() {
        try {
            ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long ramMb = mi.totalMem / (1024L * 1024L);
            boolean lowRam = am.isLowRamDevice();
            int cores = Runtime.getRuntime().availableProcessors();
            int sdk = android.os.Build.VERSION.SDK_INT;
            String ov = Prefs.get(app, "roozara_perf");
            boolean probe = "lite".equals(Prefs.get(app, "roozara_perf_probe"));
            boolean auto = lowRam || ramMb < 4500 || cores <= 4 || sdk <= 28 || probe;
            boolean lite = "lite".equals(ov) || (!"full".equals(ov) && auto);
            JSONObject o = new JSONObject();
            o.put("ram_mb", ramMb);
            o.put("cores", cores);
            o.put("sdk", sdk);
            o.put("low_ram", lowRam);
            o.put("auto", auto);
            o.put("lite", lite);
            return o.toString();
        } catch (Throwable t) {
            return "{\"lite\":false}";
        }
    }

    /** سازگاری با نسخهٔ قبل */
    @JavascriptInterface
    public void setBars(boolean dark) { }

    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("native", true);
            o.put("sdk", android.os.Build.VERSION.SDK_INT);
            return o.toString();
        } catch (Throwable t) {
            return "{}";
        }
    }
}
