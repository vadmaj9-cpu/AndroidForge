package com.rozara.azan;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

/**
 * سرویس نگهدارنده: نوتیف تاریخ به‌صورت سرویس پیش‌زمینه اجرا می‌شود تا سیستم گوشی برنامه را نکُشد
 * و آلارم‌های اذان (و ساعت) دقیق بمانند. با خاموش کردن «نمایش تاریخ در نوار وضعیت» متوقف می‌شود.
 */
public class KeepAliveService extends Service {
    static volatile boolean running = false;

    static void start(Context c) {
        try {
            JSONObject st = Prefs.state(c);
            if (!Prefs.onboarded(c) || !st.optBoolean("dateNotif", true)) {
                c.stopService(new Intent(c, KeepAliveService.class));
                return;
            }
            c.startForegroundService(new Intent(c, KeepAliveService.class));
        } catch (Throwable t) {
            Diag.add(c, "شروع سرویس نگهدارنده ممکن نشد: " + t.getClass().getSimpleName());
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notifs.ensureChannels(this);
        Notification n = DateNotifier.build(this);
        boolean ok = n != null;
        if (n == null) {
            n = new Notification.Builder(this, Notifs.CH_DATE)
                    .setSmallIcon(R.drawable.ic_stat_adhan).setContentTitle("روزآرا").build();
        }
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifs.ID_DATE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(Notifs.ID_DATE, n);
            }
            running = true;
        } catch (Throwable t) {
            Diag.add(this, "startForeground نگهدارنده خطا داد: " + t.getClass().getSimpleName());
        }
        if (!ok) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        new Thread(() -> {
            try { Scheduler.scheduleAll(getApplicationContext()); } catch (Throwable ignored) { }
        }).start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
