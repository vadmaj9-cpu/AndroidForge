package com.rozara.azan;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.Locale;

/** گزارش عیب‌یابی: رویدادهای مهم اذان/آلارم + وضعیت مجوزها (برای دیدن در تنظیمات). */
final class Diag {
    private static final int MAX = 60;

    private Diag() {}

    static synchronized void add(Context c, String msg) {
        try {
            long s = ((System.currentTimeMillis() + Cal.IRAN_OFFSET_MIN * 60000L) / 1000L) % 86400L;
            String t = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
            SharedPreferences sp = Prefs.sp(c);
            String old = sp.getString("diag", "");
            String all = old.isEmpty() ? (t + " " + msg) : (old + "\n" + t + " " + msg);
            String[] lines = all.split("\n");
            if (lines.length > MAX) {
                StringBuilder b = new StringBuilder();
                for (int i = lines.length - MAX; i < lines.length; i++) {
                    if (b.length() > 0) b.append('\n');
                    b.append(lines[i]);
                }
                all = b.toString();
            }
            sp.edit().putString("diag", all).apply();
        } catch (Throwable ignored) {
        }
    }

    static String report(Context c) {
        StringBuilder b = new StringBuilder();
        try {
            JSONObject st = Prefs.state(c);
            b.append("گوشی: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                    .append(" | اندروید ").append(Build.VERSION.SDK_INT).append('\n');
            b.append("اعلان‌ها: ").append(yn(Notifs.canPost(c)));
            if (Build.VERSION.SDK_INT >= 31) {
                b.append(" | آلارم دقیق: ").append(yn(((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms()));
            }
            if (Build.VERSION.SDK_INT >= 34) {
                b.append(" | صفحه روی قفل: ").append(yn(((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent()));
            }
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            b.append("\nبدون محدودیت باتری: ").append(yn(pm.isIgnoringBatteryOptimizations(c.getPackageName())));
            b.append(" | نمایش روی برنامه‌ها: ").append(yn(Settings.canDrawOverlays(c)));
            b.append(" | دسترسی مصرف برنامه‌ها: ").append(yn(Foreground.hasUsageAccess(c)));
            b.append("\nراه‌اندازی اولیه: ").append(yn(Prefs.onboarded(c)))
                    .append(" | شهر: ").append(st.optString("city", "؟"))
                    .append(" | یادآوری: ").append(st.optInt("reminder", 10)).append(" دقیقه");
            b.append("\nسرویس نگهدارنده: ").append(yn(KeepAliveService.running));
        } catch (Throwable t) {
            b.append("خطا در گزارش: ").append(t);
        }
        b.append("\n— رویدادها (قدیمی ← جدید) —\n").append(Prefs.sp(c).getString("diag", "(هنوز چیزی ثبت نشده)"));
        return b.toString();
    }

    private static String yn(boolean v) { return v ? "✓" : "✗"; }
}
