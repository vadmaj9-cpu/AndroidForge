package com.rozara.azan;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/** ذخیرهٔ پایدار تنظیمات (مشترک بین برنامه و آلارم‌ها). */
final class Prefs {
    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("roozara", Context.MODE_PRIVATE);
    }

    static String get(Context c, String k) {
        String v = sp(c).getString(k, "");
        return v == null ? "" : v;
    }

    static void set(Context c, String k, String v) {
        sp(c).edit().putString(k, v == null ? "" : v).commit();
    }

    static JSONObject state(Context c) {
        try {
            String s = get(c, "roozara_state");
            return s.isEmpty() ? new JSONObject() : new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static boolean onboarded(Context c) {
        return !get(c, "roozara_onboarded").isEmpty();
    }

    /** مختصات فعال: [lat, lon] (پیش‌فرض تهران) */
    static double[] coords(JSONObject st) {
        JSONObject c = st.optJSONObject("coords");
        if (c != null && c.has("lat") && c.has("lon")) {
            return new double[]{c.optDouble("lat", 35.6892), c.optDouble("lon", 51.3890)};
        }
        return new double[]{35.6892, 51.3890};
    }
}
