package com.rozara.azan;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** مکان‌یابی بومی (GPS/شبکه) + نام شهر با Geocoder در صورت وجود. */
final class LocationHelper {
    interface Callback {
        void ok(double lat, double lon, String place);
        void error(String code);
    }

    private LocationHelper() {}

    @SuppressWarnings("MissingPermission")
    static void fetch(final Context ctx, final Callback cb) {
        final LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) { cb.error("fail"); return; }

        Location best = null;
        try {
            for (String p : lm.getAllProviders()) {
                Location l = null;
                try { l = lm.getLastKnownLocation(p); } catch (Throwable ignored) { }
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
        } catch (Throwable ignored) { }

        final long now = System.currentTimeMillis();
        if (best != null && now - best.getTime() < 5 * 60 * 1000L) {
            deliver(ctx, best, cb);
            return;
        }

        final List<String> provs = new ArrayList<>();
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) provs.add(LocationManager.GPS_PROVIDER);
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) provs.add(LocationManager.NETWORK_PROVIDER);
        } catch (Throwable ignored) { }

        if (provs.isEmpty()) {
            if (best != null) deliver(ctx, best, cb); else cb.error("gps_off");
            return;
        }

        final Location fallback = best;
        final boolean[] done = {false};
        final Handler h = new Handler(Looper.getMainLooper());
        final LocationListener[] holder = new LocationListener[1];

        holder[0] = new LocationListener() {
            @Override public void onLocationChanged(Location loc) {
                if (done[0]) return;
                done[0] = true;
                try { lm.removeUpdates(this); } catch (Throwable ignored) { }
                deliver(ctx, loc, cb);
            }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
            @Override @SuppressWarnings("deprecation")
            public void onStatusChanged(String p, int s, Bundle e) { }
        };

        try {
            for (String p : provs) lm.requestLocationUpdates(p, 0L, 0f, holder[0], Looper.getMainLooper());
        } catch (Throwable t) {
            if (fallback != null) deliver(ctx, fallback, cb); else cb.error("fail");
            return;
        }

        h.postDelayed(() -> {
            if (done[0]) return;
            done[0] = true;
            try { lm.removeUpdates(holder[0]); } catch (Throwable ignored) { }
            if (fallback != null) deliver(ctx, fallback, cb); else cb.error("timeout");
        }, 25000L);
    }

    private static void deliver(final Context ctx, final Location loc, final Callback cb) {
        final double lat = loc.getLatitude(), lon = loc.getLongitude();
        new Thread(() -> {
            String place = null;
            try {
                if (Geocoder.isPresent()) {
                    List<Address> l = new Geocoder(ctx, new Locale("fa", "IR")).getFromLocation(lat, lon, 1);
                    if (l != null && !l.isEmpty()) {
                        Address a = l.get(0);
                        if (a.getLocality() != null) place = a.getLocality();
                        else if (a.getSubAdminArea() != null) place = a.getSubAdminArea();
                        else if (a.getAdminArea() != null) place = a.getAdminArea();
                    }
                }
            } catch (Throwable ignored) { }
            final String p = place;
            new Handler(Looper.getMainLooper()).post(() -> cb.ok(lat, lon, p));
        }).start();
    }
}
