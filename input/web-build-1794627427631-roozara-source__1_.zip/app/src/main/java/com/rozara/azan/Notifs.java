package com.rozara.azan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

import org.json.JSONObject;

/** کانال‌ها و نوتیفیکیشن‌های یادآوری/تولد. */
final class Notifs {
    static final String CH_ADHAN = "adhan_v2";
    static final String CH_REMIND = "remind_v2";
    static final String CH_BDAY = "bday_v2";
    static final String CH_DATE = "date_v2";

    static final int ID_DATE = 100;
    static final int ID_ADHAN = 200;
    static final int ID_REMIND = 300;
    static final int ID_BDAY = 400;

    private Notifs() {}

    static NotificationManager nm(Context c) {
        return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    static void ensureChannels(Context c) {
        NotificationManager nm = nm(c);
        NotificationChannel adhan = new NotificationChannel(CH_ADHAN, "اذان", NotificationManager.IMPORTANCE_HIGH);
        adhan.setDescription("پخش اذان در وقت نماز");
        adhan.setSound(null, null);
        adhan.enableVibration(false);
        adhan.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(adhan);

        NotificationChannel rem = new NotificationChannel(CH_REMIND, "یادآوری قبل از اذان", NotificationManager.IMPORTANCE_HIGH);
        rem.setDescription("چند دقیقه مانده به اذان");
        rem.enableVibration(true);
        rem.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(rem);

        NotificationChannel bd = new NotificationChannel(CH_BDAY, "تولد", NotificationManager.IMPORTANCE_HIGH);
        bd.setDescription("تبریک تولد");
        nm.createNotificationChannel(bd);

        NotificationChannel date = new NotificationChannel(CH_DATE, "تاریخ امروز", NotificationManager.IMPORTANCE_LOW);
        date.setDescription("نمایش تاریخ امروز در نوار وضعیت");
        date.setShowBadge(false);
        date.setSound(null, null);
        nm.createNotificationChannel(date);
    }

    static PendingIntent openMain(Context c) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 11, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static boolean canPost(Context c) {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            return c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    /** «۱۰ دقیقه مانده به اذان صبح» */
    static void reminder(Context c, String key, long adhanAtMs, int minutes) {
        if (!canPost(c)) return;
        ensureChannels(c);
        JSONObject st = Prefs.state(c);
        String city = st.optString("city", "");
        int minuteOfDay = Cal.iranMinuteOfDay(adhanAtMs);
        Notification n = new Notification.Builder(c, CH_REMIND)
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setContentTitle(Cal.fa(minutes) + " دقیقه مانده به اذان " + PrayerCalc.name(key))
                .setContentText("ساعت " + Cal.clock(minuteOfDay) + (city.isEmpty() ? "" : " • " + city))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(openMain(c))
                .build();
        nm(c).notify(ID_REMIND, n);
    }

    static void birthday(Context c) {
        if (!canPost(c)) return;
        ensureChannels(c);
        JSONObject st = Prefs.state(c);
        JSONObject b = st.optJSONObject("birthday");
        String text = "امروز روز توئه؛ سالی پر از شادی و آرامش برات آرزو می‌کنیم 🌙";
        if (b != null && b.optInt("year", 0) > 0) {
            int jy = Cal.dayFor(Cal.iranDate(System.currentTimeMillis())).jy;
            int age = jy - b.optInt("year");
            if (age > 0 && age < 130) text = "امروز " + Cal.fa(age) + " ساله شدی! سالی پر از شادی و آرامش برات آرزو می‌کنیم 🌙";
        }
        Notification n = new Notification.Builder(c, CH_BDAY)
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setContentTitle("🎂 تولدت مبارک!")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setCategory(Notification.CATEGORY_EVENT)
                .setAutoCancel(true)
                .setContentIntent(openMain(c))
                .build();
        nm(c).notify(ID_BDAY, n);
    }

    /** مسیر جایگزین: نوتیف تمام‌صفحهٔ اذان (صفحهٔ اذان پس از باز شدن، سرویس پخش را شروع می‌کند) */
    static void adhanFallback(Context c, String key) {
        ensureChannels(c);
        Intent i = new Intent(c, AdhanActivity.class).putExtra("key", key).putExtra("start", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 41, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH_ADHAN)
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setContentTitle("اذان " + PrayerCalc.name(key))
                .setContentText("برای پخش اذان لمس کن")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build();
        nm(c).notify(ID_ADHAN, n);
    }

    static Icon icon(Context c, int res) {
        return Icon.createWithResource(c, res);
    }
}
