package com.rozara.azan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** اگر کاربر نوتیف تاریخ را کنار زد (اندروید ۱۴+)، دوباره نمایش داده می‌شود مگر اینکه در تنظیمات خاموش شده باشد. */
public class NotifDismissReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            DateNotifier.update(ctx);
        } catch (Throwable ignored) {
        }
    }
}
