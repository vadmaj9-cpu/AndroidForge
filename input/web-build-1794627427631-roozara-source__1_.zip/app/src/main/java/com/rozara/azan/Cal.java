package com.rozara.azan;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** تقویم شمسی/قمری/میلادی و مناسبت‌ها — پورت مستقیم از منطق جاوااسکریپت برنامه. */
final class Cal {
    static final int IRAN_OFFSET_MIN = 210; // UTC+3:30

    static final String[] MONTHS = {"فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"};
    static final String[] WEEKDAYS = {"شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"};
    static final String[] GREG = {"ژانویه","فوریه","مارس","آوریل","مه","ژوئن","ژوئیه","اوت","سپتامبر","اکتبر","نوامبر","دسامبر"};
    static final String[] HIJRI = {"محرم","صفر","ربیع‌الاول","ربیع‌الثانی","جمادی‌الاول","جمادی‌الثانی","رجب","شعبان","رمضان","شوال","ذی‌القعده","ذی‌الحجه"};

    private static final Map<String, String> SOLAR = new HashMap<>();
    private static final Map<String, String> LUNAR = new HashMap<>();
    private static final String[] SOLAR_OFF = {"1/1","1/2","1/3","1/4","1/12","1/13","3/14","3/15","11/22","12/29"};

    static {
        SOLAR.put("1/1", "نوروز"); SOLAR.put("1/2", "عید نوروز"); SOLAR.put("1/3", "عید نوروز"); SOLAR.put("1/4", "عید نوروز");
        SOLAR.put("1/12", "روز جمهوری اسلامی"); SOLAR.put("1/13", "سیزده‌به‌در"); SOLAR.put("3/14", "رحلت امام خمینی");
        SOLAR.put("3/15", "قیام ۱۵ خرداد"); SOLAR.put("11/22", "پیروزی انقلاب اسلامی"); SOLAR.put("12/29", "ملی شدن صنعت نفت");
        LUNAR.put("1/9", "تاسوعای حسینی"); LUNAR.put("1/10", "عاشورای حسینی"); LUNAR.put("2/20", "اربعین حسینی");
        LUNAR.put("2/28", "رحلت پیامبر اکرم و شهادت امام حسن"); LUNAR.put("2/30", "شهادت امام رضا");
        LUNAR.put("3/17", "میلاد پیامبر اکرم و امام صادق"); LUNAR.put("6/3", "شهادت حضرت فاطمه");
        LUNAR.put("7/13", "ولادت امام علی"); LUNAR.put("7/27", "مبعث پیامبر اکرم"); LUNAR.put("8/15", "ولادت امام زمان");
        LUNAR.put("9/21", "شهادت امام علی"); LUNAR.put("10/1", "عید سعید فطر"); LUNAR.put("10/2", "تعطیل عید فطر");
        LUNAR.put("10/25", "شهادت امام صادق"); LUNAR.put("12/10", "عید سعید قربان"); LUNAR.put("12/18", "عید سعید غدیر خم");
    }

    private Cal() {}

    /** تاریخ میلادیِ «اکنون» به وقت ایران */
    static LocalDate iranDate(long nowMs) {
        return Instant.ofEpochMilli(nowMs + IRAN_OFFSET_MIN * 60000L).atZone(ZoneOffset.UTC).toLocalDate();
    }

    static int iranMinuteOfDay(long nowMs) {
        long m = ((nowMs + IRAN_OFFSET_MIN * 60000L) / 60000L) % 1440L;
        return (int) ((m + 1440L) % 1440L);
    }

    /** زمان واقعی (میلی‌ثانیه) برای دقیقهٔ مشخصی از یک روز به وقت ایران */
    static long millisOf(LocalDate d, int minuteOfDay) {
        return d.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() + minuteOfDay * 60000L - IRAN_OFFSET_MIN * 60000L;
    }

    static int[] g2j(int gy, int gm, int gd) {
        int[] gdm = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
        int jy;
        if (gy > 1600) { jy = 979; gy -= 1600; } else { jy = 0; gy -= 621; }
        int gy2 = gm > 2 ? gy + 1 : gy;
        long days = 365L * gy + Math.floorDiv(gy2 + 3, 4) - Math.floorDiv(gy2 + 99, 100) + Math.floorDiv(gy2 + 399, 400)
                - 80 + gd + gdm[gm - 1];
        jy += 33 * (int) (days / 12053); days %= 12053;
        jy += 4 * (int) (days / 1461); days %= 1461;
        if (days > 365) { jy += (int) ((days - 1) / 365); days = (days - 1) % 365; }
        int jm = days < 186 ? 1 + (int) (days / 31) : 7 + (int) ((days - 186) / 30);
        int jd = 1 + (int) (days < 186 ? days % 31 : (days - 186) % 30);
        return new int[]{jy, jm, jd};
    }

    static boolean isLeap(int y) {
        int r = y % 33;
        return r == 1 || r == 5 || r == 9 || r == 13 || r == 17 || r == 22 || r == 26 || r == 30;
    }

    static int monthLen(int y, int m) {
        return m <= 6 ? 31 : (m <= 11 ? 30 : (isLeap(y) ? 30 : 29));
    }

    /** [سال، ماه، روز] قمری (ام‌القری) */
    static int[] hijri(LocalDate g) {
        try {
            return HijriUtil.get(g);
        } catch (Throwable t) {
            return tabular(g);
        }
    }

    static int[] tabular(LocalDate g) {
        long jd = g.toEpochDay() + 2440588L;
        long l = jd - 1948440L + 10632L;
        long n = (l - 1) / 10631L;
        l = l - 10631L * n + 354L;
        long j = ((10985L - l) / 5316L) * ((50L * l) / 17719L) + (l / 5670L) * ((43L * l) / 15238L);
        l = l - ((30L - j) / 15L) * ((17719L * j) / 50L) - (j / 16L) * ((15238L * j) / 43L) + 29L;
        int m = (int) ((24L * l) / 709L);
        int d = (int) (l - (709L * m) / 24L);
        int y = (int) (30L * n + j - 30L);
        return new int[]{y, m, d};
    }

    static final class Day {
        int jy, jm, jd, weekday; // weekday: شنبه=0 ... جمعه=6
        LocalDate g;
        int hy, hm, hd;
        final List<String> events = new ArrayList<>();
        boolean officialOff;
        boolean friday;
    }

    static Day dayFor(LocalDate g) {
        Day d = new Day();
        d.g = g;
        int[] j = g2j(g.getYear(), g.getMonthValue(), g.getDayOfMonth());
        d.jy = j[0]; d.jm = j[1]; d.jd = j[2];
        d.weekday = (g.getDayOfWeek().getValue() + 1) % 7;
        d.friday = d.weekday == 6;
        int[] h = hijri(g);
        d.hy = h[0]; d.hm = h[1]; d.hd = h[2];
        String sk = d.jm + "/" + d.jd;
        if (SOLAR.containsKey(sk)) d.events.add(SOLAR.get(sk));
        for (String s : SOLAR_OFF) if (s.equals(sk)) d.officialOff = true;
        String lk = d.hm + "/" + d.hd;
        if (LUNAR.containsKey(lk)) { d.events.add(LUNAR.get(lk)); d.officialOff = true; }
        return d;
    }

    static String fa(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            b.append(c >= '0' && c <= '9' ? (char) ('۰' + (c - '0')) : c);
        }
        return b.toString();
    }

    static String fa(int v) { return fa(String.valueOf(v)); }

    static String clock(int minuteOfDay) {
        return fa(String.format(java.util.Locale.US, "%02d:%02d", minuteOfDay / 60, minuteOfDay % 60));
    }
}
