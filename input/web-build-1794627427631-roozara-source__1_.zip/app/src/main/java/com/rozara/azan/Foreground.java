package com.rozara.azan;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** تشخیص اینکه الان کجا هستیم (نیازمند «دسترسی به مصرف برنامه‌ها»). */
final class Foreground {
    static final int UNKNOWN = 0; // دسترسی نداریم
    static final int HOME = 1;    // صفحهٔ اصلی گوشی / برنامه‌های اخیر / خود روزآرا / هیچ برنامه‌ای
    static final int OTHER = 2;   // داخل برنامهٔ دیگر

    private Foreground() {}

    static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int m = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            return m == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    static int state(Context c) {
        try {
            if (!hasUsageAccess(c)) return UNKNOWN;
            UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(now - 3L * 3600_000L, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String top = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                int type = e.getEventType();
                if (type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    top = e.getPackageName();
                } else if (type == UsageEvents.Event.MOVE_TO_BACKGROUND && e.getPackageName() != null && e.getPackageName().equals(top)) {
                    top = null;
                }
            }
            if (top == null) return HOME;
            if (top.equals(c.getPackageName())) return HOME;
            return isLauncher(c, top) ? HOME : OTHER;
        } catch (Throwable ignored) {
            return UNKNOWN;
        }
    }

    static boolean isLauncher(Context c, String pkg) {
        if (pkg == null) return false;
        if (pkg.equals("com.android.systemui")) return true;
        try {
            Set<String> homes = new HashSet<>();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> l = c.getPackageManager().queryIntentActivities(i, PackageManager.MATCH_ALL);
            for (ResolveInfo r : l) if (r.activityInfo != null) homes.add(r.activityInfo.packageName);
            return homes.contains(pkg);
        } catch (Throwable t) {
            return false;
        }
    }
}
