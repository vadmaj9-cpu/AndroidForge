package com.rozara.azan;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** هر ~۳۰ دقیقه آلارم‌ها را دوباره می‌چیند (اگر سیستم گوشی آن‌ها را پاک کرده باشد). */
public class RearmJobService extends JobService {
    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(() -> {
            try {
                Scheduler.scheduleAll(getApplicationContext());
                DateNotifier.update(getApplicationContext());
                Diag.add(getApplicationContext(), "کار دوره‌ای: آلارم‌ها دوباره چیده شد");
            } catch (Throwable ignored) {
            }
            jobFinished(params, false);
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
