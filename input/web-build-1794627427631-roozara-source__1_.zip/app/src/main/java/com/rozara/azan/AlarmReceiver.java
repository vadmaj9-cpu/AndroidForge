package com.rozara.azan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            // پردازنده را چند ثانیه بیدار نگه می‌داریم تا سرویس اذان بالا بیاید
            try {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "roozara:alarm").acquire(20000L);
            } catch (Throwable ignored) { }

            String type = intent.getStringExtra("type");
            String key = intent.getStringExtra("key");
            long at = intent.getLongExtra("at", 0);
            long now = System.currentTimeMillis();
            if (type == null) type = "daily";
            if (key == null) key = "";
            Diag.add(ctx, "آلارم رسید: " + type + " " + key + " (تأخیر " + ((now - at) / 1000) + " ثانیه)");

            switch (type) {
                case "adhan":
                case "test": {
                    boolean test = "test".equals(type);
                    JSONObject st = Prefs.state(ctx);
                    JSONObject pr = st.optJSONObject("prayers");
                    boolean enabled = test || pr == null || pr.optBoolean(key, true);
                    if (!enabled) {
                        Diag.add(ctx, "این نماز در تنظیمات خاموش است؛ اذان پخش نشد");
                    } else if (!test && Math.abs(now - at) >= 3 * 60000L) {
                        Diag.add(ctx, "آلارم خیلی دیر رسید؛ اذان پخش نشد");
                    } else {
                        Intent s = new Intent(ctx, AdhanService.class)
                                .setAction(AdhanService.ACTION_START).putExtra("key", key);
                        try {
                            ctx.startForegroundService(s);
                        } catch (Throwable fgsDenied) {
                            Diag.add(ctx, "شروع سرویس اذان رد شد (" + fgsDenied.getClass().getSimpleName() + ")؛ نوتیف تمام‌صفحه");
                            Notifs.adhanFallback(ctx, key);
                        }
                    }
                    break;
                }
                case "reminder": {
                    JSONObject st = Prefs.state(ctx);
                    JSONObject pr = st.optJSONObject("prayers");
                    int minutes = st.optInt("reminder", 10);
                    boolean enabled = pr == null || pr.optBoolean(key, true);
                    if (!enabled || minutes <= 0) {
                        Diag.add(ctx, "یادآوری خاموش است");
                    } else if (Math.abs(now - (at - minutes * 60000L)) >= 5 * 60000L) {
                        Diag.add(ctx, "یادآوری خیلی دیر رسید؛ رد شد");
                    } else if (!Notifs.canPost(ctx)) {
                        Diag.add(ctx, "اجازهٔ اعلان نداریم؛ یادآوری نمایش داده نشد");
                    } else {
                        Notifs.reminder(ctx, key, at, minutes);
                        Diag.add(ctx, "یادآوری نمایش داده شد");
                    }
                    break;
                }
                case "bday": {
                    JSONObject st = Prefs.state(ctx);
                    if (st.optBoolean("showBday", true) && st.optJSONObject("birthday") != null) Notifs.birthday(ctx);
                    break;
                }
                default:
                    break;
            }
            Scheduler.scheduleAll(ctx);
            DateNotifier.update(ctx);
            KeepAliveService.start(ctx);
        } catch (Throwable t) {
            Log.e("RoozaraAlarm", "onReceive failed", t);
            Diag.add(ctx, "خطا در دریافت آلارم: " + t.getClass().getSimpleName());
        }
    }
}
