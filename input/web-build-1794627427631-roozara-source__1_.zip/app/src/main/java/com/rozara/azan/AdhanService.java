package com.rozara.azan;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.RemoteViews;

import org.json.JSONObject;

/**
 * پخش اذان با مؤذن انتخاب‌شده.
 *  - قفل/خاموش، داخل خود برنامه، یا روی صفحهٔ اصلی گوشی → صفحهٔ کامل اذان
 *  - داخل برنامهٔ دیگر → نوتیف ثابت ساده (قطع صدا / حذف) که با لمس، صفحهٔ اذان را باز می‌کند
 */
public class AdhanService extends Service {
    static final String ACTION_START = "com.rozara.azan.ADHAN_START";
    static final String ACTION_TOGGLE = "com.rozara.azan.ADHAN_TOGGLE";
    static final String ACTION_STOP = "com.rozara.azan.ADHAN_STOP";
    static final String ACTION_MUTE = "com.rozara.azan.ADHAN_MUTE";
    static final String ACTION_ENDED = "com.rozara.azan.ADHAN_ENDED";

    private static final int MODE_PAGE = 0;
    private static final int MODE_COMPACT = 1;

    static volatile boolean active = false;
    static volatile boolean playing = false;
    static volatile String currentKey = null;
    private static AdhanService inst;

    private MediaPlayer mp;
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = this::stopSelf;
    private boolean started = false;
    private boolean detached = false;

    static String soundFile(String sound) {
        if ("menshavi".equals(sound)) return "www/audio/muezzin2.mp3";
        if ("hosary".equals(sound)) return "www/audio/muezzin3.mp3";
        if ("muhammadayyub".equals(sound)) return "www/audio/muezzin4.mp3";
        return "www/audio/muezzin1.mp3";
    }

    /** از پل جاوااسکریپت: مکث/ادامه. مقدار برگشتی: آیا اکنون در حال پخش است. */
    static boolean toggleFromBridge() {
        final AdhanService s = inst;
        if (s == null) return false;
        final boolean was = playing;
        new Handler(Looper.getMainLooper()).post(s::doToggle);
        return !was;
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, AdhanService.class));
        Notifs.nm(c).cancel(Notifs.ID_ADHAN);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        active = true;
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            Notifs.nm(this).cancel(Notifs.ID_ADHAN);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_MUTE.equals(action)) {
            if (started) muteOnly(); else stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_TOGGLE.equals(action)) {
            doToggle();
            return START_NOT_STICKY;
        }
        String key = intent == null ? null : intent.getStringExtra("key");
        if (key == null || key.isEmpty()) key = "fajr";
        if (started) return START_NOT_STICKY;
        started = true;
        currentKey = key;
        begin(key);
        return START_NOT_STICKY;
    }

    /** کجا هستیم؟ صفحهٔ کامل یا نوتیف فشرده */
    private int decideMode(boolean[] idleOut, String[] why) {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            boolean idle = !pm.isInteractive() || km.isKeyguardLocked();
            idleOut[0] = idle;
            if (idle) { why[0] = "قفل یا خاموش"; return MODE_PAGE; }
            if (MainActivity.visible) { why[0] = "داخل خود برنامه"; return MODE_PAGE; }
            int fg = Foreground.state(this);
            boolean overlay = Settings.canDrawOverlays(this);
            if (fg == Foreground.OTHER) { why[0] = "داخل برنامهٔ دیگر"; return MODE_COMPACT; }
            if (overlay) {
                why[0] = fg == Foreground.HOME ? "صفحهٔ اصلی گوشی" : "نامشخص (دسترسی مصرف برنامه‌ها نیست)";
                return MODE_PAGE;
            }
            why[0] = "مجوز «نمایش روی سایر برنامه‌ها» نیست";
            return MODE_COMPACT;
        } catch (Throwable t) {
            why[0] = "خطا در تشخیص: " + t.getClass().getSimpleName();
        }
        return MODE_COMPACT;
    }

    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                    "roozara:screen").acquire(15000L);
        } catch (Throwable ignored) {
        }
    }

    private void begin(String key) {
        Notifs.ensureChannels(this);
        boolean[] idle = {false};
        String[] why = {""};
        int mode = decideMode(idle, why);
        Diag.add(this, "اذان " + PrayerCalc.name(key) + " شروع شد | وضعیت: " + why[0] + " | " + (mode == MODE_PAGE ? "صفحهٔ کامل" : "نوتیف"));
        if (idle[0]) wakeScreen();

        Notification n = mode == MODE_PAGE ? buildPageNotification(key) : buildCompact(key, false);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(Notifs.ID_ADHAN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(Notifs.ID_ADHAN, n);
            }
        } catch (Throwable t) {
            Log.e("RoozaraAdhan", "startForeground failed", t);
            Diag.add(this, "startForeground خطا داد: " + t.getClass().getSimpleName());
        }

        if (mode == MODE_PAGE) {
            // قفل/خاموش: fullScreenIntent نوتیف صفحه را باز می‌کند؛ اگر اجازهٔ «نمایش روی سایر برنامه‌ها» هست مستقیم هم باز می‌کنیم
            if (!idle[0] || Settings.canDrawOverlays(this)) launchPage(key);
        }

        JSONObject st = Prefs.state(this);
        String sound = st.optString("sound", "abdulbasit");
        float vol = Math.max(0f, Math.min(1f, st.optInt("volume", 80) / 100f));
        try {
            requestFocus();
            AssetFileDescriptor afd = getAssets().openFd(soundFile(sound));
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setVolume(vol, vol);
            mp.setOnCompletionListener(m -> stopSelf());
            mp.setOnErrorListener((m, w, e) -> { stopSelf(); return true; });
            mp.setOnPreparedListener(m -> { m.start(); playing = true; Diag.add(AdhanService.this, "پخش صدا شروع شد"); });
            mp.prepareAsync();
        } catch (Throwable t) {
            Log.e("RoozaraAdhan", "play failed", t);
            Diag.add(this, "پخش صدا ناموفق: " + t.getClass().getSimpleName() + " " + t.getMessage());
            stopSelf();
            return;
        }
        h.postDelayed(autoStop, 8 * 60 * 1000L);
    }

    /** باز کردن صفحهٔ اذان؛ از پس‌زمینه با یک پنجرهٔ ۱ پیکسلی شفاف (مجوز نمایش روی سایر برنامه‌ها) */
    private void launchPage(String key) {
        Intent i = activityIntent(this, key).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (MainActivity.visible) {
            try { startActivity(i); } catch (Throwable ignored) { }
            return;
        }
        try {
            final WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            final View v = new View(this);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            wm.addView(v, lp);
            startActivity(i);
            h.postDelayed(() -> { try { wm.removeView(v); } catch (Throwable ignored) { } }, 4000L);
        } catch (Throwable t) {
            try { startActivity(i); } catch (Throwable ignored) { }
        }
    }

    private void doToggle() {
        try {
            if (mp == null) return;
            if (mp.isPlaying()) { mp.pause(); playing = false; }
            else { mp.start(); playing = true; }
        } catch (Throwable ignored) {
        }
    }

    /** «قطع صدا»: فقط صدا قطع می‌شود و نوتیف (قابل‌حذف) می‌ماند */
    private void muteOnly() {
        releasePlayer();
        playing = false;
        String key = currentKey == null ? "fajr" : currentKey;
        Notification n = buildCompact(key, true);
        detached = true;
        stopForeground(STOP_FOREGROUND_DETACH);
        Notifs.nm(this).notify(Notifs.ID_ADHAN, n);
        stopSelf();
    }

    static Intent activityIntent(Context c, String key) {
        return new Intent(c, AdhanActivity.class).putExtra("key", key)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    private String cityOrDefault() {
        String city = Prefs.state(this).optString("city", "");
        return city.isEmpty() ? "شهر شما" : city;
    }

    private String prayerClock(String key) {
        try {
            JSONObject st = Prefs.state(this);
            double[] co = Prefs.coords(st);
            int[] t = PrayerCalc.times(co[0], co[1], st.optString("method", "tehran"), Cal.iranDate(System.currentTimeMillis()));
            for (int p = 0; p < 5; p++) if (PrayerCalc.KEYS[p].equals(key)) return Cal.clock(PrayerCalc.minuteOf(t, p));
        } catch (Throwable ignored) {
        }
        return "";
    }

    private PendingIntent openPage(String key) {
        return PendingIntent.getActivity(this, 31, activityIntent(this, key),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent svc(int code, String action) {
        return PendingIntent.getService(this, code, new Intent(this, AdhanService.class).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** نوتیف حالت «صفحهٔ کامل» (با fullScreenIntent برای قفل‌صفحه) */
    private Notification buildPageNotification(String key) {
        String clock = prayerClock(key);
        PendingIntent open = openPage(key);
        return new Notification.Builder(this, Notifs.CH_ADHAN)
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setContentTitle("اذان به افق " + cityOrDefault())
                .setContentText("نماز " + PrayerCalc.name(key) + (clock.isEmpty() ? "" : " • " + clock))
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "توقف", svc(32, ACTION_STOP)).build())
                .build();
    }

    /** نوتیف ثابت و ساده: «اذان به افق ...» + دکمهٔ قطع صدا + دکمهٔ حذف */
    private Notification buildCompact(String key, boolean muted) {
        String clock = prayerClock(key);
        String city = cityOrDefault();
        RemoteViews rv = new RemoteViews(getPackageName(), R.layout.notif_adhan);
        rv.setTextViewText(R.id.adhan_t1, "اذان به افق " + city);
        rv.setTextViewText(R.id.adhan_t2, muted ? "صدا قطع شد" : "نماز " + PrayerCalc.name(key) + (clock.isEmpty() ? "" : " • " + clock));
        rv.setViewVisibility(R.id.adhan_mute, muted ? View.GONE : View.VISIBLE);
        rv.setOnClickPendingIntent(R.id.adhan_mute, svc(33, ACTION_MUTE));
        rv.setOnClickPendingIntent(R.id.adhan_close, svc(32, ACTION_STOP));
        return new Notification.Builder(this, Notifs.CH_ADHAN)
                .setSmallIcon(R.drawable.ic_stat_adhan)
                .setContentTitle("اذان به افق " + city)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .setCustomContentView(rv)
                .setCustomBigContentView(rv)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(!muted)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(openPage(key))
                .build();
    }

    private void requestFocus() {
        try {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(f -> { })
                    .build();
            am.requestAudioFocus(focusReq);
        } catch (Throwable ignored) {
        }
    }

    private void releasePlayer() {
        try {
            if (mp != null) { try { mp.stop(); } catch (Throwable ignored) { } mp.release(); mp = null; }
        } catch (Throwable ignored) {
        }
        try {
            if (focusReq != null) am.abandonAudioFocusRequest(focusReq);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        releasePlayer();
        playing = false;
        active = false;
        currentKey = null;
        inst = null;
        if (!detached) stopForeground(STOP_FOREGROUND_REMOVE);
        sendBroadcast(new Intent(ACTION_ENDED).setPackage(getPackageName()));
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
