package com.rozara.azan;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** گوشی‌های سخت‌گیر (شیائومی، سامسونگ، ...) برنامه‌های بسته را می‌کشند؛ این کلاس صفحهٔ تنظیم مربوطه را باز می‌کند. */
final class Oem {
    private Oem() {}

    private static String m() { return Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.ROOT); }

    static boolean isXiaomi() { String s = m(); return s.contains("xiaomi") || s.contains("redmi") || s.contains("poco"); }
    static boolean isHuawei() { String s = m(); return s.contains("huawei") || s.contains("honor"); }
    static boolean isOppoFamily() { String s = m(); return s.contains("oppo") || s.contains("realme") || s.contains("oneplus"); }
    static boolean isVivo() { String s = m(); return s.contains("vivo") || s.contains("iqoo"); }
    static boolean isSamsung() { return m().contains("samsung"); }

    static boolean isAggressive() { return isXiaomi() || isHuawei() || isOppoFamily() || isVivo() || isSamsung(); }

    static String hint() {
        if (isXiaomi()) return "در این صفحه برای روزآرا «شروع خودکار» را روشن کن، صرفه‌جویی باتری را «بدون محدودیت» بگذار، و «نمایش روی صفحه قفل» و «نمایش پنجره در پس‌زمینه» را روشن کن";
        if (isSamsung()) return "برای روزآرا «محدودیت باتری» را بردار (Unrestricted) و آن را از «برنامه‌های خواب‌رفته» خارج کن";
        if (isHuawei()) return "برای روزآرا «راه‌اندازی خودکار» و «اجرا در پس‌زمینه» را روشن کن";
        if (isOppoFamily()) return "برای روزآرا «شروع خودکار» و «اجرا در پس‌زمینه» را روشن کن";
        if (isVivo()) return "برای روزآرا «شروع خودکار» و «مصرف باتری در پس‌زمینه» را روشن کن";
        return "برای روزآرا محدودیت باتری و پس‌زمینه را بردار";
    }

    /** صفحهٔ مناسب را باز می‌کند؛ در صورت نبودن، تنظیمات برنامه. */
    static boolean openSettings(Context c) {
        List<Intent> tries = new ArrayList<>();
        if (isXiaomi()) {
            Intent i = new Intent("miui.intent.action.APP_PERM_EDITOR");
            i.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity");
            i.putExtra("extra_pkgname", c.getPackageName());
            tries.add(i);
            tries.add(new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")));
        } else if (isHuawei()) {
            tries.add(new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")));
            tries.add(new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")));
        } else if (isOppoFamily()) {
            tries.add(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")));
            tries.add(new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")));
            tries.add(new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")));
        } else if (isVivo()) {
            tries.add(new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")));
            tries.add(new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")));
        } else if (isSamsung()) {
            tries.add(new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")));
        }
        tries.add(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName())));
        for (Intent i : tries) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
                return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }
}
