package com.rozara.azan;

import android.icu.util.Calendar;
import android.icu.util.IslamicCalendar;
import android.icu.util.TimeZone;
import android.icu.util.ULocale;

import java.time.LocalDate;
import java.time.ZoneOffset;

/** تبدیل میلادی به قمری با ICU اندروید (ام‌القری — همان چیزی که مرورگر استفاده می‌کند). */
final class HijriUtil {
    private HijriUtil() {}

    static int[] get(LocalDate g) {
        IslamicCalendar c = new IslamicCalendar(TimeZone.GMT_ZONE, ULocale.ENGLISH);
        c.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
        long ms = g.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() + 12L * 3600000L;
        c.setTimeInMillis(ms);
        return new int[]{c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)};
    }
}
