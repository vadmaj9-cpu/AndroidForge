package com.rozara.azan;

import java.time.LocalDate;

/** محاسبهٔ اوقات شرعی — پورت دقیق از جاوااسکریپت (معادلات خورشیدی NOAA). */
final class PrayerCalc {
    static final String[] KEYS = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
    // اندیس‌های خروجی times(): 0 fajr, 1 sunrise, 2 dhuhr, 3 asr, 4 maghrib, 5 isha
    static final int[] KEY_INDEX = {0, 2, 3, 4, 5};

    private PrayerCalc() {}

    private static double rad(double d) { return d * Math.PI / 180.0; }
    private static double deg(double r) { return r * 180.0 / Math.PI; }
    private static double norm360(double x) { return ((x % 360.0) + 360.0) % 360.0; }

    private static double[] method(String m) {
        if ("jafari".equals(m)) return new double[]{16, 4, 14};
        if ("mwl".equals(m)) return new double[]{18, 0.833, 17};
        return new double[]{17.7, 4.5, 14};
    }

    /** خروجی: دقیقه از نیمه‌شب به وقت ایران (یا -1 اگر محاسبه ممکن نبود). */
    static int[] times(double lat, double lon, String methodName, LocalDate d) {
        double[] M = method(methodName);
        double jd = d.toEpochDay() + 2440587.5;
        double T = (jd - 2451545.0) / 36525.0;
        double L0 = norm360(280.46646 + T * (36000.76983 + T * 0.0003032));
        double Ma = norm360(357.52911 + T * (35999.05029 - 0.0001537 * T));
        double e = 0.016708634 - T * (0.000042037 + 0.0000001267 * T);
        double C = Math.sin(rad(Ma)) * (1.914602 - T * (0.004817 + 0.000014 * T))
                + Math.sin(rad(2 * Ma)) * (0.019993 - 0.000101 * T)
                + Math.sin(rad(3 * Ma)) * 0.000289;
        double omega = 125.04 - 1934.136 * T;
        double lambda = L0 + C - 0.00569 - 0.00478 * Math.sin(rad(omega));
        double seconds = 21.448 - T * (46.815 + T * (0.00059 - T * 0.001813));
        double meanObliq = 23 + (26 + seconds / 60) / 60;
        double obliq = meanObliq + 0.00256 * Math.cos(rad(omega));
        double decl = Math.asin(Math.sin(rad(obliq)) * Math.sin(rad(lambda)));
        double y = Math.pow(Math.tan(rad(obliq) / 2), 2);
        double eqTime = 4 * deg(
                y * Math.sin(2 * rad(L0)) - 2 * e * Math.sin(rad(Ma))
                        + 4 * e * y * Math.sin(rad(Ma)) * Math.cos(2 * rad(L0))
                        - 0.5 * y * y * Math.sin(4 * rad(L0))
                        - 1.25 * e * e * Math.sin(2 * rad(Ma)));

        double latitude = rad(lat);
        double solarNoon = 720 + Cal.IRAN_OFFSET_MIN - 4 * lon - eqTime;

        Double fajr = before(solarNoon, latitude, decl, -M[0]);
        Double sunrise = before(solarNoon, latitude, decl, -0.833);
        Double sunset = after(solarNoon, latitude, decl, -0.833);
        Double maghrib = after(solarNoon, latitude, decl, -M[1]);
        Double isha = after(solarNoon, latitude, decl, -M[2]);
        double shadowAltitude = deg(Math.atan(1 / (1 + Math.tan(Math.abs(latitude - decl)))));
        Double asr = after(solarNoon, latitude, decl, shadowAltitude);

        return new int[]{
                toMin(fajr), toMin(sunrise), toMin(solarNoon + 1), toMin(asr),
                toMin(maghrib != null ? maghrib : sunset), toMin(isha)
        };
    }

    private static Double hourAngle(double latitude, double decl, double altitude) {
        double c = (Math.sin(rad(altitude)) - Math.sin(latitude) * Math.sin(decl)) / (Math.cos(latitude) * Math.cos(decl));
        if (c < -1 || c > 1) return null;
        return deg(Math.acos(Math.max(-1, Math.min(1, c)))) * 4;
    }

    private static Double after(double noon, double lat, double decl, double alt) {
        Double h = hourAngle(lat, decl, alt);
        return h == null ? null : noon + h;
    }

    private static Double before(double noon, double lat, double decl, double alt) {
        Double h = hourAngle(lat, decl, alt);
        return h == null ? null : noon - h;
    }

    private static int toMin(Double v) {
        if (v == null) return -1;
        double x = ((v % 1440) + 1440) % 1440;
        return (int) Math.round(x);
    }

    private static int toMin(double v) { return toMin(Double.valueOf(v)); }

    /** دقیقهٔ یک نماز مشخص (fajr/dhuhr/asr/maghrib/isha) از آرایهٔ times() */
    static int minuteOf(int[] t, int prayerIdx) { return t[KEY_INDEX[prayerIdx]]; }

    static String name(String key) {
        switch (key) {
            case "fajr": return "صبح";
            case "dhuhr": return "ظهر";
            case "asr": return "عصر";
            case "maghrib": return "مغرب";
            case "isha": return "عشا";
            default: return key;
        }
    }
}
