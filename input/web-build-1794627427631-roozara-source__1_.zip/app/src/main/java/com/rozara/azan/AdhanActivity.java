package com.rozara.azan;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** صفحهٔ اذان روی قفل‌صفحه: همان صفحهٔ اذان نمونهٔ برنامه (index.html?adhan=...) */
public class AdhanActivity extends Activity {
    private WebView wv;
    private String key = "fajr";
    private final BroadcastReceiver ended = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { finish(); }
    };

    @SuppressLint({"SetJavaScriptEnabled", "UnspecifiedRegisterReceiverFlag"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#062D2B")));
        Ui.immersive(this);

        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#062D2B"));
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(wv);

        IntentFilter f = new IntentFilter(AdhanService.ACTION_ENDED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ended, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(ended, f);

        load(getIntent());
        boolean startFlag = getIntent() != null && getIntent().getBooleanExtra("start", false);
        if (startFlag && !AdhanService.active) {
            try {
                startForegroundService(new Intent(this, AdhanService.class)
                        .setAction(AdhanService.ACTION_START).putExtra("key", key));
            } catch (Throwable ignored) { }
        } else if (!AdhanService.active) {
            // سرویس دیگر فعال نیست (مثلاً اذان تمام شده): صفحه را ببند
            wv.postDelayed(() -> { if (!AdhanService.active) finish(); }, 2500);
        }
    }

    private void load(Intent i) {
        String k = i == null ? null : i.getStringExtra("key");
        if (k != null && !k.isEmpty()) key = k;
        wv.loadUrl("file:///android_asset/www/index.html?adhan=" + key);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String k = intent.getStringExtra("key");
        if (k != null && !k.equals(key)) load(intent);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(ended); } catch (Throwable ignored) { }
        if (wv != null) { wv.destroy(); wv = null; }
        super.onDestroy();
    }
}
