package com.rozara.azan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** بعد از ریبوت، آپدیت برنامه یا تغییر ساعت: آلارم‌ها و نوتیف تاریخ دوباره ساخته می‌شوند. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            Diag.add(ctx, "رویداد سیستم: " + (intent == null ? "؟" : intent.getAction()));
            Scheduler.scheduleAll(ctx);
            DateNotifier.update(ctx);
            KeepAliveService.start(ctx);
        } catch (Throwable ignored) {
        }
    }
}
