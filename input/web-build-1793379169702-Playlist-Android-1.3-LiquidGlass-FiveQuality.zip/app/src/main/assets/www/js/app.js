const state = {
  view: 'loading', currentUser: null, playlists: [], activeSection: 'playlist',
  expandedPlaylistId: null, modal: null, editingPlaylistId: null, showFirstTimeNotice: false,
  draftSongs: [], draftCoverKey: null, draftCoverPreviewUrl: null, draftName: '',
  formErrors: {}, registerAvatarPreview: null, registerAvatarBlob: null, langMenuOpen: false,
  playerVisible: true, playerMini: false, sectionAnimClass: '',
  nowPlayingOpen: false, settingsEditField: null, settingsFormErrors: {},
};

const player = { playlistId: null, songIndex: -1, isPlaying: false, currentTime: 0, duration: 0, seeking: false, wantsPlaying: false, repeatOne: false };
const audioEl = (typeof Native !== 'undefined' && Native.available) ? Native.audio : document.getElementById('audio-el');

function currentPlaylist() { return state.playlists.find(p => p.id === player.playlistId) || null; }
function currentSong() { const pl = currentPlaylist(); if (!pl) return null; return pl.songs[player.songIndex] || null; }

const appRoot = document.getElementById('app');

function render() {
  // Stop page-specific canvas work as soon as its screen is left. Without this,
  // the landing animation could keep consuming CPU after its canvas was removed.
  if (state.view !== 'landing' && typeof window.__landingCleanup === 'function') {
    window.__landingCleanup();
    window.__landingCleanup = null;
  }
  if (state.view !== 'registerIntro' && typeof window.__regIntroCleanup === 'function') {
    window.__regIntroCleanup();
  }
  document.body.classList.toggle('locked-scroll', state.view === 'dashboard');
  document.body.classList.toggle('auth-screen', state.view === 'register' || state.view === 'login');
  switch (state.view) {
    case 'landing': appRoot.innerHTML = renderLanding(); afterRenderLanding(); break;
    case 'registerIntro': appRoot.innerHTML = renderRegisterIntro(); afterRenderRegisterIntro(); break;
    case 'register': appRoot.innerHTML = renderAuthShell('register'); afterRenderRegister(); break;
    case 'login': appRoot.innerHTML = renderAuthShell('login'); afterRenderLogin(); break;
    case 'dashboard': {
      const html = renderDashboard();
      if (lastRenderedView === 'dashboard') Morph.patch(appRoot, html, afterRenderDashboard);
      else { appRoot.innerHTML = html; afterRenderDashboard(); }
      break;
    }
    default: appRoot.innerHTML = ''; break;
  }
  lastRenderedView = state.view;
}
let lastRenderedView = null;

function renderLanding() {
  return `<div class="landing"><div class="landing-canvas"><canvas id="landing-canvas"></canvas></div><div class="landing-overlay"></div><div class="landing-content"><div class="landing-logo">${BRAND_LOGO_SVG}</div><h1 class="landing-title">Playlist</h1><p class="landing-sub">${t('landing.sub')}</p></div><div class="landing-actions"><button class="btn btn-primary" id="btn-goto-register" type="button">${t('landing.register')}</button><button class="btn btn-outline" id="btn-goto-login" type="button">${t('landing.login')}</button></div></div>`;
}

function afterRenderLanding() {
  document.getElementById('btn-goto-register').addEventListener('click', () => { state.view = 'registerIntro'; render(); });
  document.getElementById('btn-goto-login').addEventListener('click', () => { state.view = 'login'; render(); });
  initLandingCanvas();
}

function initLandingCanvas() {
  if (typeof window.__landingCleanup === 'function') {
    window.__landingCleanup();
    window.__landingCleanup = null;
  }
  const canvas = document.getElementById('landing-canvas'); if (!canvas) return;
  if (['very-low', 'low'].includes(document.documentElement.dataset.quality)) return;
  const ctx = canvas.getContext('2d'); let w, h, dpr;
  function resize() {
    dpr = 1; // low DPR keeps the canvas cheap on mid-range phones
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize(); window.addEventListener('resize', resize);
  const notes = Array.from({ length: 14 }, () => ({
    x: Math.random() * w, y: Math.random() * h, r: 6 + Math.random() * 10,
    speed: 0.06 + Math.random() * 0.1, drift: (Math.random() - 0.5) * 0.15,
    phase: Math.random() * Math.PI * 2, opacity: 0.08 + Math.random() * 0.14,
  }));
  let raf = 0, stopped = false;
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function drawNote(x, y, r, opacity) {
    ctx.save(); ctx.globalAlpha = opacity; ctx.fillStyle = '#c9a9ff';
    ctx.beginPath(); ctx.ellipse(x, y, r * 0.62, r * 0.46, -0.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillRect(x + r * 0.5, y - r * 2.1, r * 0.14, r * 2.2);
    ctx.beginPath(); ctx.moveTo(x + r * 0.5, y - r * 2.1);
    ctx.quadraticCurveTo(x + r * 1.5, y - r * 1.8, x + r * 1.3, y - r * 1.1);
    ctx.quadraticCurveTo(x + r * 1.1, y - r * 1.5, x + r * 0.64, y - r * 1.55); ctx.fill(); ctx.restore();
  }
  let tt = 0, lastT = 0;
  function loop(now) {
    if (stopped || document.hidden) { raf = 0; return; }
    raf = requestAnimationFrame(loop);
    if (now - lastT < 33) return; // ~30fps
    lastT = now;
    tt += prefersReduced ? 0 : 0.02; ctx.clearRect(0, 0, w, h);
    for (const n of notes) {
      const y = n.y + Math.sin(tt + n.phase) * 14; const x = n.x + Math.cos(tt * 0.6 + n.phase) * 10;
      drawNote(x, y, n.r, n.opacity); if (!prefersReduced) n.y -= n.speed * 2; if (n.y < -30) n.y = h + 30;
    }
  }
  function onVisibilityChange() {
    if (document.hidden) {
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    } else if (!stopped && !raf) {
      raf = requestAnimationFrame(loop);
    }
  }
  document.addEventListener('visibilitychange', onVisibilityChange);
  raf = requestAnimationFrame(loop);
  window.__landingCleanup = () => {
    stopped = true;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    window.removeEventListener('resize', resize);
    document.removeEventListener('visibilitychange', onVisibilityChange);
  };
}

function renderRegisterIntro() {
  return `<div class="reg-intro" id="reg-intro">
    <canvas class="reg-intro-canvas" id="reg-intro-canvas"></canvas>
    <p class="reg-intro-hint">${t('registerIntro.tapHint')}</p>
    <div class="reg-intro-note-wrap" id="reg-intro-note-wrap">
      <svg class="reg-intro-note" width="72" height="100" viewBox="0 0 86 120" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="regNoteGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#cdb0ff"/>
            <stop offset="100%" stop-color="#8b5cf6"/>
          </linearGradient>
        </defs>
        <ellipse cx="22" cy="98" rx="20" ry="15" transform="rotate(-18 22 98)" fill="url(#regNoteGrad)"></ellipse>
        <rect x="38" y="14" width="7" height="86" rx="3.5" fill="url(#regNoteGrad)"></rect>
        <path d="M45 14c20 -4 30 10 26 28c-3 12 -14 18 -22 16c10 -6 14 -16 12 -26c-2 -10 -10 -16 -16 -18z" fill="url(#regNoteGrad)"></path>
      </svg>
    </div>
  </div>`;
}

function playRegisterDing() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext; if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [880, 1318.5].forEach((freq, i) => {
      const osc = ctx.createOscillator(); const gain = ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = freq;
      const peak = i === 0 ? 0.22 : 0.1;
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(peak, now + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.95);
    });
    setTimeout(() => ctx.close(), 1200);
  } catch (e) {}
}

function afterRenderRegisterIntro() {
  if (window.__landingCleanup) { window.__landingCleanup(); window.__landingCleanup = null; }
  if (typeof window.__regIntroCleanup === 'function') window.__regIntroCleanup();
  const container = document.getElementById('reg-intro');
  const noteWrap = document.getElementById('reg-intro-note-wrap');
  const canvas = document.getElementById('reg-intro-canvas');
  const ctx = canvas.getContext('2d');
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const animateCanvas = !prefersReduced && !['very-low', 'low'].includes(document.documentElement.dataset.quality);
  let w, h, dpr;
  function resize() {
    dpr = 1;
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  if (animateCanvas) { resize(); window.addEventListener('resize', resize); }
  const originX = () => w / 2;
  const originY = () => h / 2 + 46;
  let particles = [];
  let raf = 0, stopped = false; let lastSpawn = 0;
  function spawnParticle(ts) {
    if (ts - lastSpawn < 420) return; lastSpawn = ts;
    particles.push({
      x: originX() + (Math.random() - 0.5) * 70,
      y: originY() + (Math.random() - 0.5) * 20,
      r: 2 + Math.random() * 3.5,
      vy: 0.35 + Math.random() * 0.4,
      vx: (Math.random() - 0.5) * 0.3,
      life: 0, maxLife: 2200 + Math.random() * 1400,
    });
  }
  function loop(ts) {
    if (stopped || document.hidden || !animateCanvas) { raf = 0; return; }
    ctx.clearRect(0, 0, w, h);
    spawnParticle(ts || 0);
    particles = particles.filter(p => p.life < p.maxLife);
    for (const p of particles) {
      p.life += 16; p.x += p.vx; p.y -= p.vy;
      const t2 = p.life / p.maxLife;
      const alpha = t2 < 0.15 ? t2 / 0.15 : Math.max(0, 1 - (t2 - 0.15) / 0.85);
      ctx.save();
      ctx.globalAlpha = alpha * 0.75;
      ctx.fillStyle = '#b98bff';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = alpha * 0.22; ctx.fillStyle = '#a878ff';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 2.4, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    raf = requestAnimationFrame(loop);
  }
  function onIntroVisibilityChange() {
    if (document.hidden) {
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    } else if (!stopped && animateCanvas && !raf) {
      raf = requestAnimationFrame(loop);
    }
  }
  if (animateCanvas) {
    document.addEventListener('visibilitychange', onIntroVisibilityChange);
    raf = requestAnimationFrame(loop);
  }
  window.__regIntroCleanup = () => {
    stopped = true;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    if (animateCanvas) {
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', onIntroVisibilityChange);
    }
    window.__regIntroCleanup = null;
  };

  let triggered = false;
  noteWrap.addEventListener('click', () => {
    if (triggered) return; triggered = true;
    noteWrap.style.cursor = 'default';
    playRegisterDing();
    noteWrap.classList.add('hit');
    setTimeout(() => { noteWrap.classList.remove('hit'); noteWrap.classList.add('back'); }, 120);
    setTimeout(() => { noteWrap.classList.remove('back'); noteWrap.classList.add('zoom'); }, 340);
    setTimeout(() => { container.classList.add('fade-out'); }, 890);
    setTimeout(() => {
      if (window.__regIntroCleanup) window.__regIntroCleanup();
      state.view = 'register'; state.playRegisterEnterAnim = true; render();
    }, 1190);
  });
}


function renderAuthShell(mode) {
  const isRegister = mode === 'register';
  const enterAnim = isRegister && state.playRegisterEnterAnim;
  if (enterAnim) state.playRegisterEnterAnim = false;
  return `<div class="auth-wrap"><div class="auth-card ${enterAnim ? 'intro-enter' : ''}"><div class="auth-logo">${BRAND_LOGO_SVG}</div><h1 class="auth-title">${isRegister ? t('auth.registerTitle') : t('auth.loginTitle')}</h1><p class="auth-sub">${isRegister ? t('auth.registerSub') : t('auth.loginSub')}</p>${isRegister ? renderRegisterForm() : renderLoginForm()}<div class="auth-switch">${isRegister ? `${t('auth.haveAccount')} <button type="button" id="switch-to-login">${t('auth.loginLink')}</button>` : `${t('auth.noAccount')} <button type="button" id="switch-to-register">${t('auth.registerLink')}</button>`}</div></div></div>`;
}

function renderRegisterForm() {
  return `<form id="register-form" novalidate><div class="avatar-picker"><div class="avatar-circle" id="avatar-picker-circle">${state.registerAvatarPreview ? `<img src="${state.registerAvatarPreview}" alt="">` : icon('user', 34)}</div><input type="file" id="avatar-input" accept="image/*" class="file-picker-input"><span class="hint">${t('register.avatarHint')}</span></div><div class="field"><label for="reg-username">${t('register.usernameLabel')}</label><div class="input-with-icon"><input class="input" id="reg-username" type="text" dir="ltr" placeholder="${t('register.usernamePlaceholder')}" autocomplete="username" autocapitalize="none" spellcheck="false"><span class="field-icon">${icon('user', 18)}</span></div></div><div class="field"><label for="reg-password">${t('register.passwordLabel')}</label><div class="input-with-icon"><input class="input" id="reg-password" type="password" placeholder="${t('register.passwordPlaceholder')}" autocomplete="new-password"><span class="field-icon">${icon('lock', 18)}</span></div></div><div class="field"><label for="reg-password2">${t('register.password2Label')}</label><div class="input-with-icon"><input class="input" id="reg-password2" type="password" placeholder="${t('register.password2Placeholder')}" autocomplete="new-password"><span class="field-icon">${icon('lock', 18)}</span></div></div><button type="submit" class="btn btn-primary btn-block">${t('register.submit')}</button></form>`;
}

function renderLoginForm() {
  return `<form id="login-form" novalidate><div class="field"><label for="login-username">${t('login.usernameLabel')}</label><div class="input-with-icon"><input class="input" id="login-username" type="text" placeholder="${t('login.usernamePlaceholder')}" autocomplete="username"><span class="field-icon">${icon('user', 18)}</span></div></div><div class="field"><label for="login-password">${t('login.passwordLabel')}</label><div class="input-with-icon"><input class="input" id="login-password" type="password" placeholder="${t('login.passwordPlaceholder')}" autocomplete="current-password"><span class="field-icon">${icon('lock', 18)}</span></div></div><button type="submit" class="btn btn-primary btn-block">${t('login.submit')}</button></form>`;
}

function afterRenderRegister() {
  document.getElementById('switch-to-login').addEventListener('click', () => { state.view = 'login'; render(); });
  const usernameInput = document.getElementById('reg-username');
  usernameInput.addEventListener('input', () => {
    const filtered = usernameInput.value.replace(/[^a-zA-Z0-9_.]/g, '');
    if (filtered !== usernameInput.value) usernameInput.value = filtered;
  });
  const circle = document.getElementById('avatar-picker-circle');
  const fileInput = document.getElementById('avatar-input');
  const openAvatarPicker = () => fileInput.click();
  circle.addEventListener('click', openAvatarPicker);
  circle.setAttribute('role', 'button');
  circle.setAttribute('tabindex', '0');
  circle.setAttribute('aria-label', t('register.avatarHint'));
  circle.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openAvatarPicker(); } });
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    if (!file.type || !file.type.startsWith('image/')) { showNotification('error', t('err.selectImage')); fileInput.value = ''; return; }
    try {
      const cropped = await openImageCropper(file, { shape: 'circle', outputSize: 400 });
      fileInput.value = '';
      if (!cropped || !cropped.size) return;
      if (state.registerAvatarPreview && state.registerAvatarPreview.startsWith('blob:')) URL.revokeObjectURL(state.registerAvatarPreview);
      state.registerAvatarBlob = cropped;
      state.registerAvatarPreview = URL.createObjectURL(cropped);
      // Update only the avatar preview. Re-rendering the whole form here erased
      // the username/password the user may already have typed.
      const preview = document.createElement('img');
      preview.alt = '';
      preview.decoding = 'async';
      preview.src = state.registerAvatarPreview;
      circle.replaceChildren(preview);
    } catch (err) {
      fileInput.value = '';
      showNotification('error', t('err.selectImage'));
    }
  });
  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('reg-username').value.trim();
    const password = document.getElementById('reg-password').value;
    const password2 = document.getElementById('reg-password2').value;
    if (!username) { showNotification('error', t('err.enterUsername')); return; }
    if (username.length < 3) { showNotification('error', t('err.usernameMinLen')); return; }
    if (!/^[a-zA-Z0-9_.]+$/.test(username)) { showNotification('error', t('err.usernameEnglishOnly')); return; }
    if (!password || password.length < 4) { showNotification('error', t('err.passwordMinLen')); return; }
    if (password !== password2) { showNotification('error', t('err.passwordMismatch')); return; }
    try {
      const submitBtn = e.target.querySelector('button[type=submit]'); submitBtn.disabled = true;
      const user = await DataService.registerUser({ username, password, profileImageBlob: state.registerAvatarBlob });
      state.currentUser = user; state.playlists = DataService.getPlaylists(user.id); state.activeSection = 'playlist';
      state.registerAvatarBlob = null;
      if (state.registerAvatarPreview && state.registerAvatarPreview.startsWith('blob:')) URL.revokeObjectURL(state.registerAvatarPreview);
      state.registerAvatarPreview = null;
      showNotification('success', t('success.registered')); maybeShowFirstTimeNotice();
      state.view = 'dashboard'; render();
    } catch (err) {
      const submitBtn = document.querySelector('#register-form button[type=submit]');
      if (submitBtn) submitBtn.disabled = false;
      if (err.message === 'DUPLICATE_USERNAME') showNotification('error', t('err.usernameTaken'));
      else showNotification('error', t('err.registerGeneric'));
    }
  });
}

function afterRenderLogin() {
  document.getElementById('switch-to-register').addEventListener('click', () => { state.view = 'register'; render(); });
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    if (!username || !password) { showNotification('error', t('err.loginInvalid')); return; }
    try {
      const user = await DataService.loginUser({ username, password });
      state.currentUser = user; state.playlists = DataService.getPlaylists(user.id); state.activeSection = 'playlist';
      maybeShowFirstTimeNotice(); state.view = 'dashboard'; render();
    } catch (err) { showNotification('error', t('err.loginInvalid')); }
  });
}

function maybeShowFirstTimeNotice() {
  const seen = DataService.getSeenNotices(state.currentUser.id);
  state.showFirstTimeNotice = !seen.includes(NOTICE_IDS.WELCOME_V1);
}

function renderDashboard() {
  const hasPlayerBar = player.songIndex >= 0 && currentSong() && state.playerVisible;
  const animClass = state.sectionAnimClass; state.sectionAnimClass = '';
  return `<div class="dashboard ${hasPlayerBar ? 'has-player' : ''}"><div class="topbar"><div class="brand"><span class="icon-badge">${BRAND_LOGO_SVG}</span> Playlist</div><button type="button" class="icon-badge-bell" id="btn-notifications" aria-label="${t('nav.notificationsAria')}">${icon('bell', 19)}</button></div><div class="section-wrap ${animClass}" id="section-content" data-section="${state.activeSection}">${renderActiveSection()}</div></div>${renderBottomNav()}${renderPlayerBar()}${renderNowPlaying()}${state.modal === 'create' ? renderPlaylistFormModal(false) : ''}${state.modal === 'edit' ? renderPlaylistFormModal(true) : ''}${state.showFirstTimeNotice ? renderFirstTimeNotice() : ''}`;
}

function getNavItems() {
  return [
    { id: 'explore', label: t('nav.explore'), icon: 'compass', soon: true },
    { id: 'playlist', label: t('nav.playlistCenter'), icon: 'plus', center: true },
    { id: 'settings', label: t('nav.settings'), icon: 'settings' },
  ];
}

function renderBottomNav() {
  return `<nav class="bottom-nav">${getNavItems().map(item => {
    if (item.center) return `<button type="button" class="nav-item-center ${state.activeSection === item.id ? 'active' : ''}" data-nav="${item.id}"><span class="fab">${icon('music', 21)}</span><span>${t('nav.playlistCenter')}</span></button>`;
    const active = state.activeSection === item.id;
    return `<button type="button" class="nav-item ${active ? 'active' : ''}" data-nav="${item.id}">${item.soon ? `<span class="soon-badge">${t('nav.soonBadge')}</span>` : ''}${icon(item.icon, 21)}<span>${item.label}</span></button>`;
  }).join('')}</nav>`;
}

function renderActiveSection() {
  switch (state.activeSection) {
    case 'settings': return renderSettingsSection();
    case 'notifications': return renderNotificationsSection();
    case 'explore': return renderSoonSection(t('nav.explore'), 'compass', t('soon.exploreDesc'));
    case 'playlist': default: return renderPlaylistSection();
  }
}


function renderNotificationsSection() {
  const notifs = DataService.getNotifications(state.currentUser.id);
  if (notifs.length === 0) {
    return `<div class="section-header"><button type="button" class="icon-btn" id="btn-back-from-notifications" aria-label="${t('notifications.backAria')}">${icon('x', 20)}</button><h1>${t('notifications.title')}</h1><span style="width:36px"></span></div><div class="empty-state"><div class="empty-icon">${icon('bell', 36)}</div><h2>${t('notifications.emptyTitle')}</h2><p>${t('notifications.emptyDesc')}</p></div>`;
  }
  return `<div class="section-header"><button type="button" class="icon-btn" id="btn-back-from-notifications" aria-label="${t('notifications.backAria')}">${icon('x', 20)}</button><h1>${t('notifications.title')}</h1><span style="width:36px"></span></div><div class="notif-list">${notifs.map(n => `<div class="notif-list-item ${n.read ? '' : 'unread'}"><span class="notif-list-icon">${icon(n.type === 'system' ? 'bell' : 'music', 16)}</span><div class="notif-list-text"><div class="t">${t(n.titleKey)}</div><div class="b">${t(n.bodyKey)}</div></div></div>`).join('')}</div>`;
}




function renderSoonSection(title, iconName, desc) {
  return `<div class="soon-page"><div class="icon-badge-lg">${icon(iconName, 32)}</div><h2>${title}</h2><p>${desc}</p><span class="soon-tag">${t('soon.tag')}</span></div>`;
}

function renderSettingsSection() {
  const lang = getLang();
  const user = state.currentUser;
  const editField = state.settingsEditField;
  return `<div class="section-header"><h1>${t('settings.title')}</h1></div><div class="profile-row"><img id="settings-avatar" src="" alt=""><div><div class="name">${escapeHtml(user.username)}</div><div class="sub">${t('settings.localAccount')}</div></div></div><div class="settings-list">
  <button type="button" class="settings-row lang-toggle" id="btn-toggle-lang" aria-expanded="${state.langMenuOpen}"><span class="settings-row-left">${icon('globe', 19)} ${t('settings.language')}</span><span class="settings-row-right"><span class="lang-current">${lang === 'fa' ? t('settings.langPersian') : t('settings.langEnglish')}</span><span class="chevron ${state.langMenuOpen ? 'open' : ''}">${icon('chevronDown', 16)}</span></span></button>
  <div class="lang-dropdown ${state.langMenuOpen ? 'open' : ''}" id="lang-dropdown"><button type="button" class="lang-option ${lang === 'fa' ? 'active' : ''}" data-lang="fa"><span>${t('settings.langPersian')}</span>${lang === 'fa' ? icon('check', 16) : ''}</button><button type="button" class="lang-option ${lang === 'en' ? 'active' : ''}" data-lang="en"><span>${t('settings.langEnglish')}</span>${lang === 'en' ? icon('check', 16) : ''}</button></div>

  <div class="settings-row" id="perf-anim-row"><span class="settings-row-left">${icon('zap', 19)} ${t('settings.animations')}</span><button type="button" class="perf-switch" id="btn-toggle-anim" role="switch" aria-checked="${PerfSettings.get().anim}" aria-label="${t('settings.animations')}"></button></div>
  <p class="perf-desc" style="margin-top:-6px;padding:0 4px">${t('settings.animationsDesc')}</p>
  <div class="settings-row" id="perf-beat-row"><span class="settings-row-left">${icon('music', 19)} ${t('settings.beatAnim')}</span><button type="button" class="perf-switch" id="btn-toggle-beat" role="switch" aria-checked="${PerfSettings.get().beat}" aria-label="${t('settings.beatAnim')}"></button></div>
  <p class="perf-desc" style="margin-top:-6px;padding:0 4px">${t('settings.beatAnimDesc')}</p>
  <div class="settings-row perf-quality"><span class="settings-row-left">${icon('sliders', 19)} ${t('settings.quality')}</span><div class="perf-seg" id="perf-quality-seg">${[{id:'very-low',key:'VeryLow'},{id:'low',key:'Low'},{id:'medium',key:'Medium'},{id:'high',key:'High'},{id:'very-high',key:'VeryHigh'}].map(q => `<button type="button" data-quality="${q.id}" class="${PerfSettings.get().quality === q.id ? 'active' : ''}">${t('settings.quality' + q.key)}</button>`).join('')}</div><p class="perf-desc">${t('settings.qualityDesc' + ({'very-low':'VeryLow','low':'Low','medium':'Medium','high':'High','very-high':'VeryHigh'}[PerfSettings.get().quality] || 'Low'))}</p></div>


  <div class="settings-row perf-quality"><span class="settings-row-left">${icon('compass', 19)} ${t('settings.layout')}</span><div class="perf-seg" id="layout-seg">${['auto', 'mobile', 'desktop', 'tv'].map(m => `<button type="button" data-layout-pref="${m}" class="${Layout.pref() === m ? 'active' : ''}">${t('settings.layout' + m[0].toUpperCase() + m.slice(1))}</button>`).join('')}</div><p class="perf-desc">${t('settings.layoutDesc')}</p></div>

  <button type="button" class="settings-row lang-toggle" id="btn-toggle-username" aria-expanded="${editField === 'username'}"><span class="settings-row-left">${icon('user', 19)} ${t('settings.changeUsername')}</span><span class="settings-row-right"><span class="chevron ${editField === 'username' ? 'open' : ''}">${icon('chevronDown', 16)}</span></span></button>
  <div class="lang-dropdown settings-form-drop ${editField === 'username' ? 'open' : ''}" id="username-edit-drop"><form id="change-username-form"><div class="field"><label for="new-username">${t('settings.newUsernameLabel')}</label><input class="input" id="new-username" type="text" dir="ltr" autocapitalize="none" spellcheck="false" value="${escapeHtml(user.username)}"></div><button type="submit" class="btn btn-primary btn-block">${t('settings.saveChanges')}</button></form></div>

  <button type="button" class="settings-row lang-toggle" id="btn-toggle-password" aria-expanded="${editField === 'password'}"><span class="settings-row-left">${icon('key', 19)} ${t('settings.changePassword')}</span><span class="settings-row-right"><span class="chevron ${editField === 'password' ? 'open' : ''}">${icon('chevronDown', 16)}</span></span></button>
  <div class="lang-dropdown settings-form-drop ${editField === 'password' ? 'open' : ''}" id="password-edit-drop"><form id="change-password-form"><div class="field"><label for="current-password">${t('settings.currentPasswordLabel')}</label><input class="input" id="current-password" type="password" autocomplete="current-password"></div><div class="field"><label for="new-password">${t('settings.newPasswordLabel')}</label><input class="input" id="new-password" type="password" autocomplete="new-password"></div><div class="field"><label for="new-password2">${t('settings.newPassword2Label')}</label><input class="input" id="new-password2" type="password" autocomplete="new-password"></div><button type="submit" class="btn btn-primary btn-block">${t('settings.saveChanges')}</button></form></div>

  <button type="button" class="settings-row" id="btn-logout" style="cursor:pointer;border:1px solid var(--color-error-soft);width:100%;text-align:inherit;color:var(--color-error);background:var(--color-error-soft)">${icon('logout', 19)} ${t('settings.logout')}</button></div><p class="helper-text">${t('settings.helperText')}</p>`;
}

function renderPlaylistSection() {
  if (state.playlists.length === 0) return `<div class="empty-state"><div class="empty-icon">${icon('listMusic', 40)}</div><h2>${t('playlist.emptyTitle')}</h2><p>${t('playlist.emptyDesc')}</p><button type="button" class="btn btn-primary" id="btn-create-first-playlist">${icon('plus', 18)} ${t('playlist.createFirst')}</button></div>`;
  const nSongs = state.playlists.reduce((a, pl) => a + (pl.songs ? pl.songs.length : 0), 0);
  const mins = Math.round(state.playlists.reduce((a, pl) => a + (pl.songs || []).reduce((b, so) => b + (so.duration || 0), 0), 0) / 60);
  const hero = `<div class="home-hero"><div class="home-hello"><h2>${t('home.greeting').replace('{name}', escapeHtml(state.currentUser.username))}</h2><p>${t('home.subtitle')}</p></div><div class="stat-row"><div class="stat-chip"><b>${state.playlists.length}</b><span>${t('home.statPlaylists')}</span></div><div class="stat-chip"><b>${nSongs}</b><span>${t('home.statSongs')}</span></div><div class="stat-chip"><b>${mins}</b><span>${t('home.statTime')}</span></div></div></div>`;
  return hero + `<div class="section-header"><h1>${t('playlist.myPlaylists')}</h1><button type="button" class="icon-btn" id="btn-open-create" aria-label="${t('playlist.createAria')}">${icon('plus', 20)}</button></div><div class="playlist-grid">${state.playlists.map(pl => renderPlaylistCard(pl)).join('')}</div>`;
}

function renderPlaylistCard(pl) {
  const expanded = state.expandedPlaylistId === pl.id;
  const isThisPlaying = player.playlistId === pl.id && player.songIndex >= 0;
  return `<div class="playlist-card" data-playlist-id="${pl.id}"><div class="playlist-card-main"><img class="playlist-cover" data-cover-key="${pl.coverImageKey || ''}" alt=""><div class="playlist-info"><h3 class="marquee" dir="${detectTextDir(pl.name)}"><span class="marquee-inner">${escapeHtml(pl.name)}</span></h3><p>${t('playlist.songsCount', { count: pl.songs.length })}</p></div><div class="playlist-actions"><button type="button" class="play-fab" data-action="play-playlist" data-id="${pl.id}" aria-label="${t('playlist.playAria')}">${icon(isThisPlaying && player.isPlaying ? 'pause' : 'play', 19)}</button><button type="button" class="icon-btn" data-action="edit-playlist" data-id="${pl.id}" aria-label="${t('playlist.editAria')}">${icon('edit', 17)}</button><button type="button" class="icon-btn ${pl.loopPlaylist ? 'active-toggle' : ''}" data-action="toggle-loop" data-id="${pl.id}" aria-label="${t('playlist.loopAria')}">${icon('repeat', 17)}</button><button type="button" class="icon-btn expand-btn ${expanded ? 'open' : ''}" data-action="toggle-expand" data-id="${pl.id}" aria-label="${t('playlist.showSongsAria')}">${icon('chevronDown', 19)}</button></div></div><div class="playlist-songs ${expanded ? 'open' : ''}" style="${expanded ? 'max-height:' + (pl.songs.length * 60 + 20) + 'px' : ''}"><div class="playlist-songs-inner">${pl.songs.length === 0 ? `<p class="helper-text">${t('playlist.noSongsYet')}</p>` : pl.songs.map((song, idx) => renderSongRow(pl, song, idx)).join('')}</div></div></div>`;
}

function renderSongRow(pl, song, idx) {
  const isPlayingThis = player.playlistId === pl.id && player.songIndex === idx;
  return `<div class="song-row ${isPlayingThis ? 'playing' : ''}" data-action="play-song" data-playlist-id="${pl.id}" data-index="${idx}"><span class="song-index">${isPlayingThis && player.isPlaying ? icon('pause', 13) : (idx + 1)}</span><img class="song-cover" data-cover-key="${song.coverKey || pl.coverImageKey || ''}" alt=""><div class="song-meta"><div class="t marquee" dir="${detectTextDir(song.title || song.name)}"><span class="marquee-inner">${escapeHtml(song.title || song.name)}</span></div><div class="a marquee" dir="${detectTextDir(song.artist || t('common.unknownArtist'))}"><span class="marquee-inner">${escapeHtml(song.artist || t('common.unknownArtist'))}</span></div></div><span class="song-dur">${formatDuration(song.duration)}</span></div>`;
}

function openCreateModal() { state.modal = 'create'; state.editingPlaylistId = null; state.draftName = ''; state.draftSongs = []; state.draftCoverKey = null; state.draftCoverPreviewUrl = null; render(); }

function openEditModal(playlistId) {
  const pl = state.playlists.find(p => p.id === playlistId); if (!pl) return;
  state.modal = 'edit'; state.editingPlaylistId = playlistId; state.draftName = pl.name;
  state.draftSongs = pl.songs.map(s => ({ ...s })); state.draftCoverKey = pl.coverImageKey; state.draftCoverPreviewUrl = null; render();
}

function closeModal() { state.modal = null; state.editingPlaylistId = null; render(); }

function renderPlaylistFormModal(isEdit) {
  return `<div class="modal-backdrop" id="modal-backdrop"><div class="modal" role="dialog" aria-modal="true"><div class="modal-header"><h2>${isEdit ? t('modal.editTitle') : t('modal.createTitle')}</h2><button type="button" class="icon-btn" id="btn-close-modal" aria-label="${t('modal.close')}">${icon('x', 18)}</button></div><form id="playlist-form" novalidate><div class="cover-picker"><div class="cover-square" id="cover-square"><img id="draft-cover-preview" src="${state.draftCoverPreviewUrl || ''}" alt="" style="${state.draftCoverPreviewUrl ? '' : 'display:none'}"><span id="cover-square-placeholder" style="${state.draftCoverPreviewUrl ? 'display:none' : ''}">${icon('image', 30)}</span></div><input type="file" id="cover-input" accept="image/*" class="file-picker-input"><span class="hint">${t('modal.coverHint')}</span></div><div class="field"><label for="playlist-name">${t('modal.playlistNameLabel')}</label><input class="input ${state.formErrors.name ? 'input-error' : ''}" id="playlist-name" type="text" placeholder="${t('modal.playlistNamePlaceholder')}" value="${escapeHtml(state.draftName)}"></div><div class="field"><label>${t('modal.songsLabel')}</label><button type="button" class="song-add-btn" id="btn-add-songs">${icon('upload', 18)} ${t('modal.addSongsBtn')}</button><input type="file" id="songs-input" accept="audio/*" multiple class="file-picker-input"><div class="editable-song-list" id="editable-song-list">${state.draftSongs.map((s, i) => renderEditableSongRow(s, i)).join('')}</div></div><button type="submit" class="btn btn-primary btn-block">${isEdit ? t('modal.saveChanges') : t('modal.createPlaylist')}</button>${isEdit ? `<button type="button" class="btn btn-danger btn-block" id="btn-delete-playlist" style="margin-top:10px">${icon('trash', 16)} ${t('modal.deletePlaylist')}</button>` : ''}</form></div></div>`;
}

function renderEditableSongRow(song, idx) {
  return `<div class="editable-song-row" draggable="true" data-idx="${idx}"><span class="grip">${icon('grip', 17)}</span><img class="song-cover" data-cover-key="${song.coverKey || ''}" alt="" style="${song.coverKey ? '' : 'display:none'}"><div class="song-meta"><div class="t marquee" dir="${detectTextDir(song.title || song.name)}"><span class="marquee-inner">${escapeHtml(song.title || song.name)}</span></div><div class="a">${formatDuration(song.duration)}</div></div><button type="button" class="icon-btn lyr-btn ${song.lyrics ? 'has' : ''}" data-action="song-lyrics" data-idx="${idx}" aria-label="${t('lyrics.add')}" title="${t('lyrics.add')}">${icon('listMusic', 16)}</button><button type="button" class="icon-btn" data-action="remove-draft-song" data-idx="${idx}" aria-label="${t('modal.removeSongAria')}">${icon('x', 16)}</button></div>`;
}

function renderFirstTimeNotice() {
  return `<div class="modal-backdrop" id="notice-backdrop"><div class="modal notice-modal"><div class="icon-badge-lg">${icon('music', 28)}</div><h2>${t('notice.welcomeTitle')}</h2><p>${t('notice.welcomeBody')}</p><ul class="notice-list"><li><span class="dot"></span> ${t('nav.explore')}</li><li><span class="dot"></span> ${t('notice.syncFeature')}</li><li><span class="dot"></span> ${t('notice.moreFeatures')}</li></ul><button type="button" class="btn btn-primary btn-block" id="btn-close-notice">${t('notice.gotIt')}</button></div></div>`;
}

function renderPlayerBar() {
  const song = currentSong();
  if (!song || !state.playerVisible) return `<div class="player-bar hidden-player"></div>`;
  const mini = state.playerMini;
  const pct = player.duration ? (player.currentTime / player.duration) * 100 : 0;
  return `<div class="player-bar ${mini ? 'mini' : ''}">
    <div class="player-cover-wrap">
      <span class="beat-ring" aria-hidden="true"></span><img class="player-cover" data-cover-key="${song.coverKey || (currentPlaylist() && currentPlaylist().coverImageKey) || ''}" alt="">
    </div>
      <div class="player-bar-controls">
        <button type="button" class="icon-btn player-mini-btn" id="btn-player-close" aria-label="${t('player.closeAria')}">${icon('x', 12)}</button>
        <button type="button" class="icon-btn player-mini-btn" id="btn-player-toggle-mini" aria-label="${mini ? t('player.expandAria') : t('player.minimizeAria')}">${icon(mini ? 'chevronUp' : 'minus', 12)}</button>
      </div>
    <div class="player-meta" id="btn-open-now-playing"><div class="t marquee" dir="${detectTextDir(song.title || song.name)}"><span class="marquee-inner">${escapeHtml(song.title || song.name)}</span></div><div class="a marquee" dir="${detectTextDir(song.artist || t('common.unknownArtist'))}"><span class="marquee-inner">${escapeHtml(song.artist || t('common.unknownArtist'))}</span></div>${miniLyricHtml(song)}</div>
    ${mini ? '' : `<div class="player-progress"><span class="player-time">${formatDuration(player.currentTime)}</span><div class="seek-track" id="seek-track"><div class="seek-fill" style="width:${pct}%"></div><div class="seek-thumb" style="left:${pct}%"></div></div><span class="player-time end">${formatDuration(player.duration || song.duration)}</span></div>`}
    <div class="player-controls">
      ${mini ? '' : `<button type="button" class="icon-btn" id="btn-prev" aria-label="${t('player.prevAria')}">${icon('prev', 17)}</button>`}
      <button type="button" class="icon-btn play-pause" id="btn-play-pause" aria-label="${t('player.playPauseAria')}">${icon(player.isPlaying ? 'pause' : 'play', 18)}</button>
      ${mini ? '' : `<button type="button" class="icon-btn" id="btn-next" aria-label="${t('player.nextAria')}">${icon('next', 17)}</button>`}
      <button type="button" class="icon-btn rep-btn ${player.repeatOne ? 'active-toggle' : ''}" id="btn-repeat" aria-pressed="${player.repeatOne}" aria-label="${t('player.repeatOneAria')}">${icon('repeat', 17)}${player.repeatOne ? '<span class="rep-one">1</span>' : ''}</button>
    </div>
  </div>`;
}

let lastMediaArtworkUrl = null;

function renderNowPlaying() {
  if (!state.nowPlayingOpen) return '';
  const song = currentSong(); if (!song) return '';
  const pl = currentPlaylist();
  const pct = player.duration ? (player.currentTime / player.duration) * 100 : 0;
  return `<div class="now-playing ${player.isPlaying ? '' : 'is-paused'}" id="now-playing">
    <div class="np-grab" aria-hidden="true"></div>
    <div class="np-header">
      <button type="button" class="icon-btn" id="btn-np-close" aria-label="${t('modal.close')}">${icon('chevronDown', 24)}</button>
      <span class="np-header-title"><small>${t('np.nowPlaying')}<span class="np-eq" aria-hidden="true"><i></i><i></i><i></i><i></i></span></small><b dir="${detectTextDir(pl ? pl.name : '')}">${escapeHtml(pl ? pl.name : '')}</b></span>
      <span class="np-spacer-sm"></span>
    </div>
    <div class="np-cover-wrap"><span class="np-glow" aria-hidden="true"></span><span class="beat-ring" aria-hidden="true"></span><img class="np-cover" data-cover-key="${song.coverKey || (pl && pl.coverImageKey) || ''}" alt=""></div>
    <div class="np-meta">
      <div class="np-title marquee" dir="${detectTextDir(song.title || song.name)}"><span class="marquee-inner">${escapeHtml(song.title || song.name)}</span></div>
      <div class="np-artist marquee" dir="${detectTextDir(song.artist || t('common.unknownArtist'))}"><span class="marquee-inner">${escapeHtml(song.artist || t('common.unknownArtist'))}</span></div>
    </div>
    ${npLyricsHtml(song)}
    <div class="np-progress">
      <div class="seek-track" id="np-seek-track"><div class="seek-fill" style="width:${pct}%"></div><div class="seek-thumb" style="left:${pct}%"></div></div>
      <div class="np-times"><span class="np-time-current">${formatDuration(player.currentTime)}</span><span class="np-time-end">${formatDuration(player.duration || song.duration)}</span></div>
    </div>
    <div class="np-controls">
      <button type="button" class="icon-btn rep-btn np-repeat ${player.repeatOne ? 'active-toggle' : ''}" id="btn-np-repeat" aria-pressed="${player.repeatOne}" aria-label="${t('player.repeatOneAria')}">${icon('repeat', 20)}${player.repeatOne ? '<span class="rep-one">1</span>' : ''}</button>
      <button type="button" class="icon-btn" id="btn-np-prev" aria-label="${t('player.prevAria')}">${icon('prev', 24)}</button>
      <button type="button" class="np-play-pause" id="btn-np-play-pause" aria-label="${t('player.playPauseAria')}">${icon(player.isPlaying ? 'pause' : 'play', 26)}</button>
      <button type="button" class="icon-btn" id="btn-np-next" aria-label="${t('player.nextAria')}">${icon('next', 24)}</button>
      <span class="np-spacer"></span>
    </div>
  </div>`;
}

function updateMediaSession() {
  if (!('mediaSession' in navigator)) return;
  const song = currentSong();
  if (!song) { navigator.mediaSession.playbackState = 'none'; return; }
  navigator.mediaSession.metadata = new MediaMetadata({
    title: song.title || song.name || t('media.unknownSong'),
    artist: song.artist || t('common.unknownArtist'),
    album: song.album || '',
  });
  navigator.mediaSession.setActionHandler('play', () => { player.wantsPlaying = true; audioEl.play().catch(() => {}); player.isPlaying = true; updatePlayerBarDom(); });
  navigator.mediaSession.setActionHandler('pause', () => { player.wantsPlaying = false; audioEl.pause(); player.isPlaying = false; updatePlayerBarDom(); });
  navigator.mediaSession.setActionHandler('stop', () => {
    player.wantsPlaying = false; audioEl.pause(); player.isPlaying = false;
    navigator.mediaSession.playbackState = 'paused'; updatePlayerBarDom();
  });
  navigator.mediaSession.setActionHandler('previoustrack', () => { playPrevious(); });
  navigator.mediaSession.setActionHandler('nexttrack', () => { playNext(); });
  try {
    navigator.mediaSession.setActionHandler('seekbackward', (details) => {
      audioEl.currentTime = Math.max(0, audioEl.currentTime - (details.seekOffset || 10));
    });
    navigator.mediaSession.setActionHandler('seekforward', (details) => {
      audioEl.currentTime = Math.min(audioEl.duration || audioEl.currentTime, audioEl.currentTime + (details.seekOffset || 10));
    });
  } catch (e) {}
  navigator.mediaSession.playbackState = player.isPlaying ? 'playing' : 'paused';
  loadMediaSessionArtwork(song);
}

async function loadMediaSessionArtwork(song) {
  if (!('mediaSession' in navigator)) return;
  const pl = currentPlaylist();
  const coverKey = song.coverKey || (pl && pl.coverImageKey);
  if (!coverKey) return;
  try {
    const blob = await FileStore.get(coverKey);
    if (!blob) return;
    if (lastMediaArtworkUrl) URL.revokeObjectURL(lastMediaArtworkUrl);
    lastMediaArtworkUrl = URL.createObjectURL(blob);
    if (navigator.mediaSession.metadata) {
      navigator.mediaSession.metadata.artwork = [
        { src: lastMediaArtworkUrl, sizes: '512x512', type: blob.type || 'image/jpeg' },
      ];
    }
  } catch (e) {}
}

function afterRenderDashboard() {
  hydrateImages(appRoot);
  const btnNotifications = document.getElementById('btn-notifications');
  if (btnNotifications) btnNotifications.addEventListener('click', () => {
    state.previousSection = state.activeSection; state.activeSection = 'notifications'; render();
  });
  document.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-nav');
      const order = ['explore', 'playlist', 'settings'];
      const oldIdx = order.indexOf(state.activeSection);
      const newIdx = order.indexOf(target);
      state.sectionAnimClass = (oldIdx !== -1 && newIdx !== -1 && oldIdx !== newIdx)
        ? (newIdx > oldIdx ? 'section-anim-from-right' : 'section-anim-from-left') : '';
      state.activeSection = target; state.expandedPlaylistId = null;
      if (['explore'].includes(state.activeSection)) {
        const labelMap = { explore: t('nav.explore') };
        render(); showNotification('info', t('nav.sectionInactive', { name: labelMap[state.activeSection] })); playNavIconAnim(target); return;
      }
      render();
      playNavIconAnim(target);
    });
  });
  const logoutBtn = document.getElementById('btn-logout');
  if (logoutBtn) logoutBtn.addEventListener('click', () => {
    DataService.logout(); player.playlistId = null; player.songIndex = -1; player.isPlaying = false;
    audioEl.pause();
    if (audioEl.src && audioEl.src.startsWith('blob:')) URL.revokeObjectURL(audioEl.src);
    audioEl.removeAttribute('src');
    state.currentUser = null; state.playlists = []; state.view = 'landing'; render();
    showNotification('success', t('success.loggedOut'));
  });
  const btnToggleUsername = document.getElementById('btn-toggle-username');
  if (btnToggleUsername) btnToggleUsername.addEventListener('click', () => { state.settingsEditField = state.settingsEditField === 'username' ? null : 'username'; render(); });
  const btnTogglePassword = document.getElementById('btn-toggle-password');
  if (btnTogglePassword) btnTogglePassword.addEventListener('click', () => { state.settingsEditField = state.settingsEditField === 'password' ? null : 'password'; render(); });
  const changeUsernameForm = document.getElementById('change-username-form');
  if (changeUsernameForm) changeUsernameForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const newUsername = document.getElementById('new-username').value.trim();
    if (!newUsername || newUsername.length < 3) { showNotification('error', t('err.usernameMinLen')); return; }
    if (!/^[a-zA-Z0-9_.]+$/.test(newUsername)) { showNotification('error', t('err.usernameEnglishOnly')); return; }
    try {
      const updated = await DataService.updateUsername(state.currentUser.id, newUsername);
      state.currentUser = updated; state.settingsEditField = null;
      showNotification('success', t('settings.usernameUpdated')); render();
    } catch (err) {
      if (err.message === 'DUPLICATE_USERNAME') showNotification('error', t('err.usernameTaken'));
      else showNotification('error', t('err.registerGeneric'));
    }
  });
  const changePasswordForm = document.getElementById('change-password-form');
  if (changePasswordForm) changePasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const oldPw = document.getElementById('current-password').value;
    const newPw = document.getElementById('new-password').value;
    const newPw2 = document.getElementById('new-password2').value;
    if (!oldPw) { showNotification('error', t('settings.currentPasswordRequired')); return; }
    if (!newPw || newPw.length < 4) { showNotification('error', t('err.passwordMinLen')); return; }
    if (newPw !== newPw2) { showNotification('error', t('err.passwordMismatch')); return; }
    try {
      await DataService.updatePassword(state.currentUser.id, oldPw, newPw);
      state.settingsEditField = null;
      showNotification('success', t('settings.passwordUpdated')); render();
    } catch (err) {
      if (err.message === 'WRONG_PASSWORD') showNotification('error', t('settings.wrongCurrentPassword'));
      else showNotification('error', t('err.registerGeneric'));
    }
  });
  const btnToggleBeat = document.getElementById('btn-toggle-beat');
  if (btnToggleBeat) btnToggleBeat.addEventListener('click', () => { PerfSettings.set({ beat: !PerfSettings.get().beat }); render(); });
  const btnToggleAnim = document.getElementById('btn-toggle-anim');
  if (btnToggleAnim) btnToggleAnim.addEventListener('click', () => { PerfSettings.set({ anim: !PerfSettings.get().anim }); render(); });
  document.querySelectorAll('#perf-quality-seg button').forEach(btn => {
    btn.addEventListener('click', () => { PerfSettings.set({ quality: btn.getAttribute('data-quality') }); render(); });
  });
  document.querySelectorAll('#layout-seg button').forEach(btn => {
    btn.addEventListener('click', () => { Layout.set(btn.getAttribute('data-layout-pref')); render(); });
  });
  const btnToggleLang = document.getElementById('btn-toggle-lang');
  if (btnToggleLang) btnToggleLang.addEventListener('click', () => { state.langMenuOpen = !state.langMenuOpen; render(); });
  document.querySelectorAll('.lang-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const newLang = btn.getAttribute('data-lang');
      if (newLang !== getLang()) { setLang(newLang); render(); }
    });
  });
  const btnBackFromNotifications = document.getElementById('btn-back-from-notifications');
  if (btnBackFromNotifications) btnBackFromNotifications.addEventListener('click', () => {
    state.activeSection = state.previousSection || 'playlist'; render();
  });
  const createFirstBtn = document.getElementById('btn-create-first-playlist');
  if (createFirstBtn) createFirstBtn.addEventListener('click', openCreateModal);
  const openCreateBtn = document.getElementById('btn-open-create');
  if (openCreateBtn) openCreateBtn.addEventListener('click', openCreateModal);
  document.querySelectorAll('[data-action="toggle-expand"]').forEach(btn => {
    btn.addEventListener('click', () => { const id = btn.getAttribute('data-id'); state.expandedPlaylistId = state.expandedPlaylistId === id ? null : id; render(); });
  });
  document.querySelectorAll('[data-action="edit-playlist"]').forEach(btn => {
    btn.addEventListener('click', () => openEditModal(btn.getAttribute('data-id')));
  });
  document.querySelectorAll('[data-action="toggle-loop"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id'); const pl = state.playlists.find(p => p.id === id); if (!pl) return;
      pl.loopPlaylist = !pl.loopPlaylist;
      if (player.playlistId === pl.id) Native.setRepeat(pl, player.repeatOne);
      DataService.savePlaylists(state.currentUser.id, state.playlists);
      render();
    });
  });
  document.querySelectorAll('[data-action="play-playlist"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id'); const pl = state.playlists.find(p => p.id === id);
      if (!pl || pl.songs.length === 0) { showNotification('warning', t('err.playlistNoSongsToPlay')); return; }
      if (player.playlistId === id && player.songIndex >= 0) togglePlayPause(); else playSongAt(id, 0);
    });
  });
  document.querySelectorAll('[data-action="play-song"]').forEach(row => {
    row.addEventListener('click', () => {
      const plId = row.getAttribute('data-playlist-id'); const idx = parseInt(row.getAttribute('data-index'), 10);
      if (player.playlistId === plId && player.songIndex === idx) togglePlayPause(); else playSongAt(plId, idx);
      state.nowPlayingOpen = true; render();
    });
  });
  const btnPlayPause = document.getElementById('btn-play-pause');
  if (btnPlayPause) btnPlayPause.addEventListener('click', togglePlayPause);
  const btnNpClose = document.getElementById('btn-np-close');
  if (btnNpClose) btnNpClose.addEventListener('click', () => {
    const npEl = document.getElementById('now-playing');
    if (npEl) { npEl.classList.add('closing'); setTimeout(() => { state.nowPlayingOpen = false; render(); }, 280); }
    else { state.nowPlayingOpen = false; render(); }
  });
  const btnNpPlayPause = document.getElementById('btn-np-play-pause');
  if (btnNpPlayPause) btnNpPlayPause.addEventListener('click', togglePlayPause);
  const btnNpPrev = document.getElementById('btn-np-prev');
  if (btnNpPrev) btnNpPrev.addEventListener('click', playPrevious);
  const btnNpNext = document.getElementById('btn-np-next');
  if (btnNpNext) btnNpNext.addEventListener('click', playNext);
  const btnRepeat = document.getElementById('btn-repeat');
  if (btnRepeat) btnRepeat.addEventListener('click', () => { player.repeatOne = !player.repeatOne; Native.setRepeat(currentPlaylist(), player.repeatOne); render(); });
  const btnNpRepeat = document.getElementById('btn-np-repeat');
  if (btnNpRepeat) btnNpRepeat.addEventListener('click', () => { player.repeatOne = !player.repeatOne; Native.setRepeat(currentPlaylist(), player.repeatOne); render(); });
  const npSeekTrack = document.getElementById('np-seek-track');
  if (npSeekTrack) attachSeekHandlers(npSeekTrack);
  const btnOpenNowPlaying = document.getElementById('btn-open-now-playing');
  if (btnOpenNowPlaying) btnOpenNowPlaying.addEventListener('click', () => { state.nowPlayingOpen = true; render(); });
  const btnPlayerClose = document.getElementById('btn-player-close');
  if (btnPlayerClose) btnPlayerClose.addEventListener('click', () => {
    player.wantsPlaying = false; audioEl.pause(); player.isPlaying = false;
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    const bar = document.querySelector('.player-bar');
    if (bar) { bar.classList.add('hidden-player'); setTimeout(() => { state.playerVisible = false; render(); }, 280); }
    else { state.playerVisible = false; render(); }
  });
  const btnPlayerToggleMini = document.getElementById('btn-player-toggle-mini');
  if (btnPlayerToggleMini) btnPlayerToggleMini.addEventListener('click', () => {
    const goingMini = !state.playerMini;
    const bar = document.querySelector('.player-bar');
    if (bar) { bar.classList.toggle('mini', goingMini); setTimeout(() => { state.playerMini = goingMini; render(); }, 280); }
    else { state.playerMini = goingMini; render(); }
  });
  const btnPrev = document.getElementById('btn-prev');
  if (btnPrev) btnPrev.addEventListener('click', playPrevious);
  const btnNext = document.getElementById('btn-next');
  if (btnNext) btnNext.addEventListener('click', playNext);
  const seekTrack = document.getElementById('seek-track');
  if (seekTrack) attachSeekHandlers(seekTrack);
  CoverColor.update();
  Ambient.sync();
  relayoutLyrics();
  const npRoot = document.getElementById('now-playing');
  if (npRoot && !npRoot._swipe) {
    npRoot._swipe = true; let y0 = null;
    npRoot.addEventListener('touchstart', (e) => { y0 = (e.target.closest('.seek-track, .np-controls')) ? null : e.touches[0].clientY; }, { passive: true });
    npRoot.addEventListener('touchend', (e) => {
      if (y0 === null) return; const dy = e.changedTouches[0].clientY - y0; y0 = null;
      if (dy > 110) { const b = document.getElementById('btn-np-close'); if (b) b.click(); }
    }, { passive: true });
  }
  const btnCloseNotice = document.getElementById('btn-close-notice');
  if (btnCloseNotice) btnCloseNotice.addEventListener('click', () => {
    DataService.markNoticeSeen(state.currentUser.id, NOTICE_IDS.WELCOME_V1); state.showFirstTimeNotice = false; render();
  });
  if (state.modal === 'create' || state.modal === 'edit') attachModalHandlers();
}

async function playSongAt(playlistId, index) {
  const pl = state.playlists.find(p => p.id === playlistId);
  if (!pl || !pl.songs[index]) return;
  player.playlistId = playlistId;
  player.songIndex = index;
  const song = pl.songs[index];
  state.playerVisible = true; state.playerMini = false;
  render();
  if (Native.available && song.uri) {
    // Android: the native service plays the whole playlist (keeps going in the background, notification controls)
    audioEl.src = 'native:queue';
    player.wantsPlaying = true; player.isPlaying = true;
    Native.setQueue(pl, index, true, player.repeatOne);
    BeatEngine.startNative(song.id || song.uri);
    updateMediaSession(); render();
    return;
  }
  const blob = (prefetched.key === song.fileKey && prefetched.blob) ? prefetched.blob : await FileStore.get(song.fileKey);
  if (!blob) { showNotification('error', t('err.audioFileNotFound')); return; }
  BeatEngine.load(song.fileKey, blob);
  if (audioEl.src && audioEl.src.startsWith('blob:')) URL.revokeObjectURL(audioEl.src);
  const url = URL.createObjectURL(blob);
  audioEl.src = url;
  player.wantsPlaying = true;
  state.playerVisible = true; state.playerMini = false;
  audioEl.play().then(() => { if (player.wantsPlaying) { player.isPlaying = true; updateMediaSession(); } }).catch(() => {
    // retry only if the person has not paused in the meantime
    setTimeout(() => { if (!player.wantsPlaying) return; audioEl.play().then(() => { if (player.wantsPlaying) { player.isPlaying = true; updateMediaSession(); } }).catch(() => { player.isPlaying = false; }); }, 100);
  });
  render();
  prefetchNext(pl, index);
}

const prefetched = { key: null, blob: null };
Native.hooks.onTrack = (songId, playlistId) => {
  if (!playlistId || playlistId !== player.playlistId) return;
  const pl = currentPlaylist(); if (!pl) return;
  const idx = pl.songs.findIndex(s => s.id === songId);
  if (idx >= 0 && idx !== player.songIndex) { player.songIndex = idx; player.currentTime = 0; BeatEngine.startNative(pl.songs[idx].id || pl.songs[idx].uri); updateMediaSession(); render(); }
};
window.__restoreNativeQueue = () => {
  const pl = currentPlaylist(); if (!pl || !Native.available || player.songIndex < 0) return;
  const s = pl.songs[player.songIndex]; if (s && s.uri) Native.setQueue(pl, player.songIndex, false, player.repeatOne);
};
function prefetchNext(pl, index) {
  let ni = index + 1;
  if (ni >= pl.songs.length) ni = pl.loopPlaylist ? 0 : -1;
  const next = ni >= 0 ? pl.songs[ni] : null;
  if (!next || !next.fileKey || prefetched.key === next.fileKey) return;
  FileStore.get(next.fileKey).then(b => { if (b) { prefetched.key = next.fileKey; prefetched.blob = b; } }).catch(() => {});
}

let _lastToggleEv = null;
function togglePlayPause(ev) {
  if (player.songIndex < 0) return;
  // the same click must never toggle twice (duplicate listeners would cancel each other out)
  if (ev && ev.type) { if (ev === _lastToggleEv) return; _lastToggleEv = ev; }
  if (audioEl.paused) {
    player.wantsPlaying = true;
    state.playerVisible = true;
    audioEl.play().then(() => { if (player.wantsPlaying) { player.isPlaying = true; updateMediaSession(); render(); } else { audioEl.pause(); } }).catch(() => {});
  } else {
    player.wantsPlaying = false;
    audioEl.pause(); player.isPlaying = false; updateMediaSession(); render();
  }
}

function playNext() {
  const pl = currentPlaylist(); if (!pl) return;
  const nextIdx = player.songIndex + 1;
  if (nextIdx < pl.songs.length) { playSongAt(pl.id, nextIdx); }
  else if (pl.loopPlaylist) { playSongAt(pl.id, 0); }
  else { player.wantsPlaying = false; audioEl.pause(); player.isPlaying = false; if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused'; render(); }
}

function playPrevious() {
  const pl = currentPlaylist(); if (!pl) return;
  if (audioEl.currentTime > 3) { audioEl.currentTime = 0; return; }
  const prevIdx = player.songIndex - 1;
  if (prevIdx >= 0) playSongAt(pl.id, prevIdx); else { audioEl.currentTime = 0; }
}

audioEl.addEventListener('timeupdate', () => {
  if (player.seeking) return;
  player.currentTime = audioEl.currentTime;
  player.duration = audioEl.duration || player.duration;
  updatePlayerBarDom();
});

audioEl.addEventListener('loadedmetadata', () => {
  player.duration = audioEl.duration || player.duration;
  updatePlayerBarDom();
});

audioEl.addEventListener('ended', () => {
  if (player.repeatOne) { audioEl.currentTime = 0; audioEl.play().catch(() => {}); return; }
  playNext();
});

function tryResumeIfNeeded() {
  if (player.wantsPlaying && audioEl.paused && player.songIndex >= 0) {
    audioEl.play().then(() => { player.isPlaying = true; updateMediaSession(); updatePlayerBarDom(); }).catch(() => {});
  }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) tryResumeIfNeeded(); });
window.addEventListener('focus', tryResumeIfNeeded);
window.addEventListener('pageshow', tryResumeIfNeeded);

audioEl.addEventListener('play', () => {
  player.isPlaying = true; updatePlayerBarDom();
  if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'playing';
});

audioEl.addEventListener('pause', () => {
  player.isPlaying = false; updatePlayerBarDom();
  if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
});


/* ---- Synced lyrics UI ---- */
function lyricIdx(song) { const L = Lyrics.get(song); return L ? Lyrics.indexAt(L.lines, player.currentTime) : -1; }
function lyricInGap(L, i) { return i >= 0 && L.lines[i].e != null && player.currentTime >= L.lines[i].e; }
function lyricsEnabledForQuality() {
  return true; // Lyrics remain available at every quality level; only heavy surrounding effects are reduced
}
function miniLyricHtml(song) {
  if (!lyricsEnabledForQuality()) return '';
  const L = Lyrics.get(song); if (!L) return '';
  const i = lyricIdx(song);
  return `<div class="player-lyric" dir="auto"><span dir="auto">${i >= 0 && !lyricInGap(L, i) ? escapeHtml(L.lines[i].s) : '♪'}</span></div>`;
}
// Cinematic lyrics (smooth fading/blurring lines) are for desktop, tablet and TV only. Phones keep the classic 3-line view.
function lyricsCinematic() {
  return window.matchMedia('(min-width: 900px)').matches && document.documentElement.getAttribute('data-layout') !== 'mobile';
}
const LYR_FAR = 5;
function lineVars(k, ci, gap) {
  const d = k - ci, ad = Math.min(LYR_FAR, Math.abs(d) + (gap && k === ci ? 1 : 0));
  return `--d:${d};--ad:${ad}`;
}
function npLyricsHtml(song) {
  if (!lyricsEnabledForQuality()) return '';
  const L = Lyrics.get(song); if (!L) return '';
  const i = Math.max(0, lyricIdx(song));
  const cine = lyricsCinematic(), gap = lyricInGap(L, i);
  return `<div class="np-lyrics" dir="auto" style="--li:${i}"><div class="np-lyr-track">${L.lines.map((l, k) => `<p dir="auto" class="lyr ${k === i && !gap ? 'cur' : (k < i ? 'past' : '')}${cine && Math.abs(k - i) > LYR_FAR - 1 ? ' far' : ''}"${cine ? ` style="${lineVars(k, i, gap)}"` : ''}>${escapeHtml(l.s)}</p>`).join('')}</div></div>`;
}
// Centre the active line in the lyrics box (lines can wrap, so the offset is measured, not computed)
function layoutLyricsCinematic(box, ci, gap) {
  const lines = box.querySelectorAll('.lyr'); const el = lines[ci]; if (!el) return;
  lines.forEach((p, k) => {
    p.style.cssText = lineVars(k, ci, gap);
    p.classList.toggle('far', Math.abs(k - ci) > LYR_FAR - 1);
  });
  box.style.setProperty('--ty', Math.round(box.clientHeight / 2 - (el.offsetTop + el.offsetHeight / 2)) + 'px');
}
function relayoutLyrics() {
  const box = document.querySelector('.np-lyrics'); if (!box || !lyricsCinematic()) return;
  const song = currentSong(); if (!song) return;
  const L = Lyrics.get(song); if (!L) return;
  const i = Math.max(0, lyricIdx(song));
  layoutLyricsCinematic(box, i, lyricInGap(L, i));
}
window.addEventListener('resize', () => requestAnimationFrame(relayoutLyrics));
let _lyrLast = { key: null, i: -2 };
function updateLyricsDom() {
  const song = currentSong(); if (!song) return;
  const L = Lyrics.get(song); if (!L) return;
  const i = lyricIdx(song); const gap = lyricInGap(L, i);
  const key = (song.id || song.fileKey) + ':' + (song.lyrics || '').length;
  const sig = i + (gap ? 'g' : '');
  if (_lyrLast.key === key && _lyrLast.i === sig) return;
  _lyrLast = { key, i: sig };
  const mini = document.querySelector('.player-lyric span');
  if (mini) {
    const txt = i >= 0 && !gap ? L.lines[i].s : '♪';
    if (mini.textContent !== txt) { mini.textContent = txt; mini.classList.remove('swap'); void mini.offsetWidth; mini.classList.add('swap'); }
  }
  const box = document.querySelector('.np-lyrics');
  if (box) {
    const ci = Math.max(0, i);
    box.style.setProperty('--li', ci);
    box.querySelectorAll('.lyr').forEach((el, k) => {
      el.classList.toggle('cur', k === ci && !gap); el.classList.toggle('past', k < ci || (k === ci && gap));
    });
    if (lyricsCinematic()) layoutLyricsCinematic(box, ci, gap);
  }
}

function updatePlayerBarDom() {
  updateLyricsDom();
  const pct = player.duration ? (player.currentTime / player.duration) * 100 : 0;
  const bar = document.querySelector('.player-bar');
  if (bar) {
    const fill = bar.querySelector('.seek-fill');
    const thumb = bar.querySelector('.seek-thumb');
    const times = bar.querySelectorAll('.player-time');
    if (fill) fill.style.width = pct + '%';
    if (thumb) thumb.style.left = pct + '%';
    if (times[0]) times[0].textContent = formatDuration(player.currentTime);
    if (times[1]) times[1].textContent = formatDuration(player.duration);
  }
  const playPauseBtn = document.getElementById('btn-play-pause');
  if (playPauseBtn) { const st = player.isPlaying ? 'pause' : 'play'; if (playPauseBtn._st !== st) { playPauseBtn._st = st; playPauseBtn.innerHTML = icon(st, 18); } }
  const npEl = document.getElementById('now-playing');
  if (npEl) {
    const npFill = npEl.querySelector('.seek-fill');
    const npThumb = npEl.querySelector('.seek-thumb');
    const npCurrent = npEl.querySelector('.np-time-current');
    const npEnd = npEl.querySelector('.np-time-end');
    if (npFill) npFill.style.width = pct + '%';
    if (npThumb) npThumb.style.left = pct + '%';
    if (npCurrent) npCurrent.textContent = formatDuration(player.currentTime);
    if (npEnd) npEnd.textContent = formatDuration(player.duration);
    const npPlayPauseBtn = document.getElementById('btn-np-play-pause');
    if (npPlayPauseBtn) npPlayPauseBtn.innerHTML = icon(player.isPlaying ? 'pause' : 'play', 26);
  }
  document.querySelectorAll('.play-fab').forEach(btn => {
    const id = btn.getAttribute('data-id');
    const isThis = id === player.playlistId && player.songIndex >= 0;
    btn.innerHTML = icon(isThis && player.isPlaying ? 'pause' : 'play', 19);
  });
  document.querySelectorAll('.song-row').forEach(row => {
    const plId = row.getAttribute('data-playlist-id');
    const idx = parseInt(row.getAttribute('data-index'), 10);
    const isThis = plId === player.playlistId && idx === player.songIndex;
    row.classList.toggle('playing', isThis);
    const indexEl = row.querySelector('.song-index');
    if (indexEl) indexEl.innerHTML = isThis && player.isPlaying ? icon('pause', 13) : String(idx + 1);
  });
}

function attachSeekHandlers(track) {
  function seekTo(clientX) {
    const rect = track.getBoundingClientRect();
    let ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    const dur = player.duration || audioEl.duration || 0;
    player.currentTime = ratio * dur;
    const fill = track.querySelector('.seek-fill');
    const thumb = track.querySelector('.seek-thumb');
    if (fill) fill.style.width = (ratio * 100) + '%';
    if (thumb) thumb.style.left = (ratio * 100) + '%';
    const bar = document.querySelector('.player-bar');
    const times = bar ? bar.querySelectorAll('.player-time') : [];
    if (times[0]) times[0].textContent = formatDuration(player.currentTime);
  }
  track.addEventListener('pointerdown', (e) => {
    player.seeking = true; seekTo(e.clientX);
    const onMove = (ev) => seekTo(ev.clientX);
    const onUp = (ev) => {
      seekTo(ev.clientX); audioEl.currentTime = player.currentTime; player.seeking = false;
      document.removeEventListener('pointermove', onMove); document.removeEventListener('pointerup', onUp);
    };
    document.addEventListener('pointermove', onMove); document.addEventListener('pointerup', onUp);
  });
}

function attachModalHandlers() {
  const backdrop = document.getElementById('modal-backdrop');
  document.getElementById('btn-close-modal').addEventListener('click', closeModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeModal(); });
  const nameInput = document.getElementById('playlist-name');
  if (nameInput) nameInput.addEventListener('input', () => { state.draftName = nameInput.value; });
  const coverSquare = document.getElementById('cover-square');
  const coverInput = document.getElementById('cover-input');
  coverSquare.addEventListener('click', () => coverInput.click());
  coverInput.addEventListener('change', async () => {
    const file = coverInput.files[0]; if (!file) return;
    if (!file.type.startsWith('image/')) { showNotification('error', t('err.selectValidImage')); return; }
    const cropped = await openImageCropper(file, { shape: 'square', outputSize: 480 });
    coverInput.value = '';
    if (!cropped) return;
    const key = await FileStore.put(cropped);
    if (nameInput) state.draftName = nameInput.value;
    state.draftCoverKey = key; state.draftCoverPreviewUrl = URL.createObjectURL(cropped); render();
  });
  const songsInput = document.getElementById('songs-input');
  document.getElementById('btn-add-songs').addEventListener('click', async () => {
    if (Native.available) {
      // Android: show every song on the phone / TV so they can be ticked
      if (nameInput) state.draftName = nameInput.value;
      const picked = await DevicePicker.open(state.draftSongs.map(s => s.uri).filter(Boolean));
      if (picked && picked.length) state.draftSongs.push(...picked);
      render(); return;
    }
    songsInput.click();
  });
  songsInput.addEventListener('change', async () => {
    const files = Array.from(songsInput.files || []);
    for (const file of files) {
      if (!isAudioFormatSupported(file)) { showNotification('error', t('err.audioFormatUnsupported')); continue; }
      const duration = await readAudioDuration(file);
      const tags = await readAudioTags(file);
      const fileKey = await FileStore.put(file);
      let coverKey = null;
      if (tags.coverBlob) coverKey = await FileStore.put(tags.coverBlob);
      state.draftSongs.push({
        id: 's_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
        name: file.name.replace(/\.[^/.]+$/, ''), title: tags.title, artist: tags.artist,
        album: tags.album, duration, fileKey, coverKey,
      });
    }
    if (nameInput) state.draftName = nameInput.value;
    songsInput.value = ''; render();
  });
  document.querySelectorAll('[data-action="remove-draft-song"]').forEach(btn => {
    btn.addEventListener('click', () => { state.draftSongs.splice(parseInt(btn.getAttribute('data-idx'), 10), 1); render(); });
  });
  document.querySelectorAll('[data-action="song-lyrics"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      const song = state.draftSongs[idx]; if (!song) return;
      if (nameInput) state.draftName = nameInput.value;
      const result = await openLyricsEditor(song);
      if (result === null) return;
      if (result === '') { delete song.lyrics; showNotification('success', t('lyrics.ed.cleared')); }
      else { song.lyrics = result; showNotification('success', t('lyrics.ed.saved')); }
      render();
    });
  });
  attachDragReorder();
  const deleteBtn = document.getElementById('btn-delete-playlist');
  if (deleteBtn) deleteBtn.addEventListener('click', () => {
    const id = state.editingPlaylistId;
    state.playlists = state.playlists.filter(p => p.id !== id);
    DataService.savePlaylists(state.currentUser.id, state.playlists);
    if (player.playlistId === id) { audioEl.pause(); player.playlistId = null; player.songIndex = -1; player.isPlaying = false; }
    closeModal(); showNotification('success', t('success.playlistDeleted'));
  });
  document.getElementById('playlist-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = document.getElementById('playlist-name'); const name = nameInput.value.trim();
    if (!name) { showNotification('error', t('err.enterPlaylistName')); nameInput.classList.add('input-error'); return; }
    if (state.draftSongs.length === 0) { showNotification('error', t('err.addAtLeastOneSong')); return; }
    if (state.modal === 'create') {
      state.playlists.push({ id: 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8), name, coverImageKey: state.draftCoverKey, songs: state.draftSongs, createdAt: Date.now() });
      showNotification('success', t('success.playlistCreated'));
    } else {
      const pl = state.playlists.find(p => p.id === state.editingPlaylistId);
      pl.name = name; pl.coverImageKey = state.draftCoverKey; pl.songs = state.draftSongs;
      showNotification('success', t('success.playlistUpdated'));
    }
    DataService.savePlaylists(state.currentUser.id, state.playlists); closeModal();
  });
}

function attachDragReorder() {
  const list = document.getElementById('editable-song-list'); if (!list) return;
  let dragIdx = null;
  list.querySelectorAll('.editable-song-row').forEach(row => {
    row.addEventListener('dragstart', () => { dragIdx = parseInt(row.getAttribute('data-idx'), 10); row.classList.add('dragging'); });
    row.addEventListener('dragend', () => { row.classList.remove('dragging'); dragIdx = null; });
    row.addEventListener('dragover', (e) => e.preventDefault());
    row.addEventListener('drop', () => {
      const dropIdx = parseInt(row.getAttribute('data-idx'), 10);
      if (dragIdx === null || dragIdx === dropIdx) return;
      const [moved] = state.draftSongs.splice(dragIdx, 1);
      state.draftSongs.splice(dropIdx, 0, moved); dragIdx = null; render();
    });
  });
}

function playNavIconAnim(sectionId) {
  const iconAnimMap = {
    settings: 'icon-anim-settings', explore: 'icon-anim-compass',
    subscription: 'icon-anim-gem', messages: 'icon-anim-message', playlist: 'icon-anim-music',
  };
  const animClass = iconAnimMap[sectionId]; if (!animClass) return;
  const freshBtn = document.querySelector(`[data-nav="${sectionId}"]`);
  const svg = freshBtn && freshBtn.querySelector('svg');
  if (!svg) return;
  svg.classList.add(animClass);
  svg.addEventListener('animationend', function onEnd() {
    svg.classList.remove(animClass); svg.removeEventListener('animationend', onEnd);
  }, { once: true });
}

function detectTextDir(text) {
  const rtlChar = /[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/;
  const ltrChar = /[A-Za-z]/;
  const str = String(text || '');
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (rtlChar.test(ch)) return 'rtl';
    if (ltrChar.test(ch)) return 'ltr';
  }
  return 'ltr';
}

function triggerMarquee(el) {
  if (el.classList.contains('marquee-animate')) return;
  const inner = el.querySelector('.marquee-inner'); if (!inner) return;
  const overflow = inner.scrollWidth - el.clientWidth;
  if (overflow <= 2) return;
  const isRTL = (el.getAttribute('dir') || document.documentElement.getAttribute('dir')) === 'rtl';
  const shift = (isRTL ? 1 : -1) * (overflow + 4);
  el.style.setProperty('--marquee-shift', shift + 'px');
  el.classList.add('marquee-animate');
  inner.addEventListener('animationend', function onEnd() {
    el.classList.remove('marquee-animate');
    inner.removeEventListener('animationend', onEnd);
  });
}

function triggerAllMarquees() {
  document.querySelectorAll('.marquee').forEach(triggerMarquee);
}

setInterval(triggerAllMarquees, 20000);
appRoot.addEventListener('click', (e) => {
  const el = e.target.closest('.marquee');
  if (el) triggerMarquee(el);
});

function init() {
  const user = DataService.getCurrentUser();
  if (user) { state.currentUser = user; state.playlists = DataService.getPlaylists(user.id); state.view = 'dashboard'; }
  else { state.view = 'landing'; }
  render();
}

init();
