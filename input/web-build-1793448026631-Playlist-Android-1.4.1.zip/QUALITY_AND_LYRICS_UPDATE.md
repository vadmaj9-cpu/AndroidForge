# Playlist 1.4

- Interactive first-run spotlight tour (create playlist, player bar, navigation) with Next/Back/Skip
- Player bar: tap anywhere except control buttons / seek to open full Now Playing
- Stronger iOS-inspired Liquid Glass across all quality tiers (blur/surfaces scale with quality)
- TV: larger focus rings, player bar focusable via remote, improved hit targets
- Quality button labels fixed (Very low / Very high) for FA + EN
- Package: com.mamadjavad.playlist — versionName 1.4 (versionCode 5)
