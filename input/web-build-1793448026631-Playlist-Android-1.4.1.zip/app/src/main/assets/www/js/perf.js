/* Adaptive visual quality. First launch is auto-detected from native Android
   RAM/CPU information (with browser fallbacks); a manual Settings choice persists. */
const PerfSettings = (() => {
  const KEY = 'playlist_app_perf_v1';
  const root = document.documentElement;
  let cfg = {};
  try { cfg = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { cfg = {}; }

  function readHardwareProfile() {
    try {
      const bridge = window.AuroraNative;
      if (bridge && typeof bridge.getDeviceProfile === 'function') {
        const raw = bridge.getDeviceProfile();
        if (raw) return JSON.parse(raw);
      }
    } catch (e) {}
    return {};
  }

  function autoQuality() {
    const hw = readHardwareProfile();
    const cores = Number(hw.cpuCores) || Number(navigator.hardwareConcurrency) || 4;
    const ramMb = Number(hw.totalRamMb) || ((Number(navigator.deviceMemory) || 0) * 1024);
    const lowRam = hw.lowRamDevice === true;
    // Four tiers (Very High removed). Map strong devices to High.
    if (lowRam || (ramMb > 0 && ramMb < 3600) || cores <= 4) return 'very-low';
    if ((ramMb > 0 && ramMb < 5200) || cores <= 5) return 'low';
    if (ramMb >= 8500 && cores >= 8) return 'high';
    if (ramMb >= 6200 && cores >= 6) return 'medium';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 8 && cores >= 8) return 'high';
    if (ramMb === 0 && cores >= 6) return 'medium';
    return 'low';
  }

  const QUALITY_LEVELS = ['very-low', 'low', 'medium', 'high'];
  // Migrate old "very-high" saves to "high"
  if (cfg.quality === 'very-high') cfg.quality = 'high';
  if (!QUALITY_LEVELS.includes(cfg.quality)) {
    cfg.quality = autoQuality();
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {}
  }

  function get() {
    let q = QUALITY_LEVELS.includes(cfg.quality) ? cfg.quality : 'low';
    if (q === 'very-high') q = 'high';
    return { quality: q, anim: cfg.anim !== false, beat: cfg.beat !== false };
  }
  function apply() {
    const g = get();
    root.setAttribute('data-quality', g.quality);
    root.setAttribute('data-anim', g.anim ? 'on' : 'off');
    // Bass animation only meaningful off-phone; force off on mobile layout
    const isMobile = root.getAttribute('data-layout') === 'mobile';
    root.setAttribute('data-beat', (!isMobile && g.beat) ? 'on' : 'off');
    if (g.quality === 'high') root.removeAttribute('data-lite'); else root.setAttribute('data-lite', '1');
  }
  function set(patch) {
    Object.assign(cfg, patch);
    if (cfg.quality === 'very-high') cfg.quality = 'high';
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {}
    apply();
    window.dispatchEvent(new Event('perfchange'));
  }
  apply();
  return { get, set, apply, autoQuality };
})();
