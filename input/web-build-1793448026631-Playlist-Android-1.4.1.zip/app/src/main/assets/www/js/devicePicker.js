/* Lists every song on the device (Android MediaStore) and lets the person tick the ones to add.
   DevicePicker.open(existingUris) -> Promise<song[] | null> */
const DevicePicker = (() => {
  let busy = false;
  const PAGE = 80;

  const fmt = (sec) => { sec = Math.max(0, Math.round(sec || 0)); return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); };
  const norm = (s) => String(s || '').toLowerCase().replace(/[يى]/g, 'ی').replace(/ك/g, 'ک');

  async function open(existingUris) {
    if (busy || !Native.available) return null; busy = true;
    const existing = new Set(existingUris || []);
    let all = [], view = [], shown = 0, allFiles = false, query = '';
    const picked = new Map(); // id -> track

    const root = document.createElement('div');
    root.className = 'dp-backdrop';
    root.innerHTML = `
      <div class="dp-panel" role="dialog" aria-modal="true">
        <div class="dp-head">
          <div class="dp-head-text"><h2>${t('picker.title')}</h2><p data-dp="count" class="dp-sub"></p></div>
          <button type="button" class="icon-btn" data-dp="close" aria-label="${t('picker.cancel')}">${icon('x', 18)}</button>
        </div>
        <div class="dp-body" data-dp="body"></div>
        <div class="dp-foot" data-dp="foot">
          <button type="button" class="btn btn-primary" data-dp="confirm" disabled>${icon('check', 16)} <span data-dp="confirm-label">${t('picker.add', { count: 0 })}</span></button>
          <button type="button" class="btn btn-ghost" data-dp="cancel">${t('picker.cancel')}</button>
        </div>
      </div>`;
    document.body.appendChild(root);
    const $ = (k) => root.querySelector(`[data-dp="${k}"]`);
    const body = $('body'), countEl = $('count'), confirmBtn = $('confirm'), confirmLabel = $('confirm-label');

    let resolveFn; const done = new Promise(r => { resolveFn = r; });
    let closed = false;
    function finish(result) {
      if (closed) return; closed = true;
      stopPreview();
      document.removeEventListener('keydown', onKey);
      root.remove(); busy = false; resolveFn(result);
    }
    function onKey(e) { if (e.key === 'Escape' && !e.defaultPrevented) { e.preventDefault(); finish(null); } }
    document.addEventListener('keydown', onKey);

    function updateFoot() {
      const n = picked.size;
      confirmBtn.disabled = n === 0;
      confirmLabel.textContent = t('picker.add', { count: n });
      countEl.textContent = all.length ? t('picker.found', { count: all.length }) : '';
    }

    function rowHtml(tr) {
      const isAdded = existing.has(tr.uri), on = picked.has(tr.id);
      return `<div class="dp-row ${on ? 'on' : ''} ${isAdded ? 'added' : ''}" data-id="${tr.id}" ${isAdded ? 'data-added="1"' : ''}>
        <button type="button" class="dp-check-btn" data-dp="toggle" ${isAdded ? 'disabled' : ''}><span class="dp-check">${on ? icon('check', 14) : ''}</span></button>
        <div class="dp-cover" data-uri="${escapeHtml(tr.uri)}"><span class="dp-cover-ph">${icon('music', 18)}</span></div>
        <span class="dp-info"><b dir="auto">${escapeHtml(tr.title || tr.name || '')}</b><small dir="auto">${escapeHtml([tr.artist || '', tr.album || ''].filter(Boolean).join(' · ') || '—')}</small></span>
        <span class="dp-dur" dir="ltr">${isAdded ? t('picker.already') : fmt(tr.duration)}</span>
        ${isAdded ? '' : `<button type="button" class="dp-preview icon-btn" data-dp="preview" data-uri="${escapeHtml(tr.uri)}" data-id="${tr.id}" aria-label="preview">${icon('play', 14)}</button>`}
      </div>`;
    }

    function applyFilter() {
      const q = norm(query);
      view = q ? all.filter(x => norm(x.title).includes(q) || norm(x.artist).includes(q) || norm(x.album).includes(q) || norm(x.name).includes(q)) : all;
      shown = 0; const list = body.querySelector('.dp-list'); if (!list) return;
      list.innerHTML = ''; more();
      body.querySelector('.dp-empty').classList.toggle('hidden', view.length > 0);
    }
    function more() {
      const list = body.querySelector('.dp-list'); if (!list || shown >= view.length) return;
      const next = view.slice(shown, shown + PAGE); shown += next.length;
      list.insertAdjacentHTML('beforeend', next.map(rowHtml).join(''));
      loadCovers(list);
    }

    function renderList() {
      body.innerHTML = `
        <div class="dp-tools">
          <input class="input dp-search" data-dp="search" type="search" dir="auto" placeholder="${t('picker.search')}" autocomplete="off">
          <div class="dp-tools-row">
            <button type="button" class="dp-chip ${allFiles ? '' : 'on'}" data-dp="only-music">${t('picker.onlyMusic')}</button>
            <button type="button" class="dp-chip ${allFiles ? 'on' : ''}" data-dp="all-files">${t('picker.allFiles')}</button>
            <button type="button" class="dp-chip dp-chip-wide" data-dp="select-all">${t('picker.selectAll')}</button>
          </div>
        </div>
        <div class="dp-scroll" data-dp="scroll"><div class="dp-list"></div><p class="dp-empty hidden">${t('picker.none')}</p></div>`;
      const search = $('search');
      search.value = query;
      search.addEventListener('input', () => { query = search.value; applyFilter(); });
      $('scroll').addEventListener('scroll', (e) => { const el = e.target; if (el.scrollTop + el.clientHeight > el.scrollHeight - 300) more(); });
      applyFilter(); updateFoot();
    }
    function renderState(msg, withButton) {
      body.innerHTML = `<div class="dp-state"><p>${msg}</p>${withButton ? `<button type="button" class="btn btn-primary" data-dp="grant">${t('picker.grant')}</button>` : ''}</div>`;
      updateFoot();
    }
    async function load() {
      renderState(t('picker.loading'), false);
      const ok = await Native.ensurePermission();
      if (closed) return;
      if (!ok) { renderState(t('picker.noPermission'), true); return; }
      await new Promise(r => setTimeout(r, 30));
      all = Native.listAudio(allFiles);
      if (closed) return;
      if (!all.length) { renderState(t('picker.none'), false); const b = body.querySelector('.dp-state'); if (b) b.insertAdjacentHTML('beforeend', `<button type="button" class="btn btn-ghost" data-dp="all-files">${t('picker.allFiles')}</button>`); return; }
      renderList();
    }

    let previewId = null, previewTimer = null, savedQueue = null;
    function stopPreview() {
      if (previewTimer) { clearTimeout(previewTimer); previewTimer = null; }
      if (!previewId) return;
      previewId = null;
      try { if (Native.available && window.AuroraNative) window.AuroraNative.stop(); } catch (e) {}
      try { if (typeof window.__restoreNativeQueue === 'function') window.__restoreNativeQueue(); } catch (e) {}
      root.querySelectorAll('.dp-preview.playing').forEach(btn => {
        btn.classList.remove('playing');
        btn.innerHTML = icon('play', 14);
      });
    }
    function startPreview(uri, id, btn) {
      stopPreview();
      previewId = id;
      btn.classList.add('playing');
      btn.innerHTML = icon('pause', 14);
      try {
        // Temporary single-track queue for preview; main queue restored on stop
        if (Native.available && window.AuroraNative) {
          window.AuroraNative.setQueue(JSON.stringify({ playlistId: '__preview', index: 0, repeat: 'off', items: [{ id: id, uri: uri, title: '', artist: '', album: '', duration: 0 }] }), true);
        }
      } catch (e) {}
      previewTimer = setTimeout(() => stopPreview(), 18000);
    }
    function loadCovers(listEl) {
      if (!listEl) return;
      listEl.querySelectorAll('.dp-cover[data-uri]:not([data-loaded])').forEach(async (el) => {
        el.setAttribute('data-loaded', '1');
        const uri = el.getAttribute('data-uri');
        try {
          const blob = await Native.getArtBlob(uri);
          if (blob) {
            const url = URL.createObjectURL(blob);
            el.innerHTML = `<img src="${url}" alt="" loading="lazy">`;
          }
        } catch (e) {}
      });
    }
    root.addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-dp], .dp-row, .dp-check-btn, .dp-preview'); if (!b || !root.contains(b)) { if (e.target === root) { stopPreview(); finish(null); } return; }
      const k = b.getAttribute('data-dp');
      if (k === 'preview') {
        e.stopPropagation();
        const uri = b.getAttribute('data-uri'), id = b.getAttribute('data-id');
        if (previewId === id) stopPreview();
        else startPreview(uri, id, b);
        return;
      }
      if (k === 'toggle' || b.classList.contains('dp-row') || b.classList.contains('dp-check-btn')) {
        const row = b.closest('.dp-row') || b;
        if (row.getAttribute('data-added') === '1') return;
        const id = row.getAttribute('data-id'); const tr = all.find(x => x.id === id); if (!tr) return;
        if (picked.has(tr.id)) picked.delete(tr.id); else picked.set(tr.id, tr);
        const on = picked.has(tr.id); row.classList.toggle('on', on);
        const chk = row.querySelector('.dp-check'); if (chk) chk.innerHTML = on ? icon('check', 14) : '';
        updateFoot(); return;
      }
      if (k === 'close' || k === 'cancel') { stopPreview(); finish(null); }
      else if (k === 'grant') load();
      else if (k === 'only-music' || k === 'all-files') { const want = k === 'all-files'; if (want !== allFiles || k === 'all-files') { allFiles = want; picked.clear(); stopPreview(); load(); } }
      else if (k === 'select-all') {
        const free = view.filter(x => !existing.has(x.uri));
        const everyOn = free.length && free.every(x => picked.has(x.id));
        free.forEach(x => { if (everyOn) picked.delete(x.id); else picked.set(x.id, x); });
        body.querySelectorAll('.dp-row').forEach(r => { if (r.getAttribute('data-added') === '1') return; const on = picked.has(r.getAttribute('data-id')); r.classList.toggle('on', on); const c = r.querySelector('.dp-check'); if (c) c.innerHTML = on ? icon('check', 14) : ''; });
        updateFoot();
      }
      else if (k === 'confirm') {
        if (!picked.size) return;
        stopPreview();
        confirmBtn.disabled = true; confirmLabel.textContent = t('picker.preparing');
        const chosen = all.filter(x => picked.has(x.id));
        const songs = [];
        for (const tr of chosen) {
          let coverKey = null;
          try { const blob = await Native.getArtBlob(tr.uri); if (blob) coverKey = await FileStore.put(blob); } catch (err) {}
          songs.push({
            id: 'song_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
            name: tr.name || tr.title, title: tr.title || tr.name || '', artist: tr.artist || '', album: tr.album || '',
            duration: tr.duration || 0, fileKey: null, uri: tr.uri, coverKey, native: true
          });
        }
        finish(songs);
      }
    });

    load();
    return done;
  }
  return { open };
})();
