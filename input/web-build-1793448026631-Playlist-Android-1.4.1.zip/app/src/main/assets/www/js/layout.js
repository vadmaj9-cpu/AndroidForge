/* Device layout: picks mobile / desktop / tv automatically (or by the user's choice in Settings)
   and gives TVs remote-control (D-pad) navigation. */
const Layout = (() => {
  const KEY = 'playlist_app_layout_v1';
  const root = document.documentElement;
  const TV_UA = /SMART-TV|SmartTV|Tizen|Web0S|WebOS|NetCast|HbbTV|VIDAA|Viera|BRAVIA|AFTM|AndroidTV|Android TV|GoogleTV|Google TV|CrKey|Roku|AppleTV|PlayStation|Xbox|Hisense|MiTV|FireTV|Fire TV/i;
  const MODES = ['auto', 'mobile', 'desktop', 'tv'];

  function pref() { try { const v = localStorage.getItem(KEY); return MODES.includes(v) ? v : 'auto'; } catch (e) { return 'auto'; } }
  function detect() {
    try { if (window.AuroraNative && window.AuroraNative.isTv && window.AuroraNative.isTv()) return 'tv'; } catch (e) {}
    if (TV_UA.test(navigator.userAgent || '')) return 'tv';
    return window.innerWidth < 900 ? 'mobile' : 'desktop';
  }
  function mode() { const p = pref(); return p === 'auto' ? detect() : p; }

  function apply() {
    const m = mode();
    root.setAttribute('data-layout', m);
    root.setAttribute('data-shell', m === 'mobile' ? 'narrow' : 'wide');
    // A TV is viewed from far away: render at ~1280 CSS px wide and scale up to the real screen
    let z = 1;
    if (m === 'tv') z = Math.min(2, Math.max(1, window.innerWidth / 1280));
    root.style.setProperty('--tv-zoom', String(z));
    root.style.zoom = z > 1 ? String(z) : '';
    try { if (typeof PerfSettings !== 'undefined') PerfSettings.apply(); } catch (e) {}
  }
  function set(p) {
    try { localStorage.setItem(KEY, MODES.includes(p) ? p : 'auto'); } catch (e) {}
    apply();
  }

  apply();
  let rt = 0;
  window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(apply, 120); });
  window.addEventListener('orientationchange', () => setTimeout(apply, 200));

  /* ---------- TV remote navigation ---------- */
  const FOCUSABLE = 'button:not([disabled]),a[href],input:not([disabled]):not([type=hidden]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';
  const OVERLAYS = ['.dp-backdrop', '.le-backdrop', '.cropper-backdrop', '.modal-backdrop', '.now-playing'];
  const BACK_KEYS = ['Escape', 'BrowserBack', 'GoBack', 'XF86Back'];
  const BACK_CODES = [27, 10009, 461, 4];

  function topOverlay() {
    for (const sel of OVERLAYS) { const els = document.querySelectorAll(sel); if (els.length) return els[els.length - 1]; }
    return null;
  }
  function usable(el) {
    if (el.closest('.playlist-songs:not(.open), .lang-dropdown:not(.open), .hidden, [aria-hidden="true"]')) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  }
  function candidates(scope) { return Array.from(scope.querySelectorAll(FOCUSABLE)).filter(usable); }
  function isTyping(el) {
    if (!el) return false; const tag = el.tagName;
    if (tag === 'TEXTAREA' || tag === 'SELECT') return true;
    if (tag === 'INPUT') return !/^(button|checkbox|radio|submit|range|file)$/i.test(el.type);
    return false;
  }
  function focusEl(el) { if (!el) return; try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); } el.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }

  function move(dir) {
    const scope = topOverlay() || document.getElementById('app') || document.body;
    const list = candidates(scope); if (!list.length) return false;
    const cur = document.activeElement;
    if (!cur || cur === document.body || !scope.contains(cur) || !list.includes(cur)) {
      focusEl(list.find(el => el.classList.contains('active')) || list[0]); return true;
    }
    const cr = cur.getBoundingClientRect(), cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
    let best = null, bs = Infinity;
    list.forEach(el => {
      if (el === cur) return;
      const r = el.getBoundingClientRect(), dx = r.left + r.width / 2 - cx, dy = r.top + r.height / 2 - cy;
      let main, cross;
      if (dir === 'left') { main = -dx; cross = Math.abs(dy); if (r.right > cr.left + 6 && main <= 0) return; }
      else if (dir === 'right') { main = dx; cross = Math.abs(dy); if (r.left < cr.right - 6 && main <= 0) return; }
      else if (dir === 'up') { main = -dy; cross = Math.abs(dx); if (r.bottom > cr.top + 6 && main <= 0) return; }
      else { main = dy; cross = Math.abs(dx); if (r.top < cr.bottom - 6 && main <= 0) return; }
      if (main <= 2) return;
      const score = main + cross * 2.6;
      if (score < bs) { bs = score; best = el; }
    });
    if (best) { focusEl(best); return true; }
    return false;
  }

  // Elements that are clickable <div>s become focusable so the remote can reach them
  function makeFocusable() {
    document.querySelectorAll('.song-row[data-action], #player-bar-root, .nav-item, .nav-item-center, .playlist-card, .play-fab, .dp-row').forEach(el => {
      if (!el.hasAttribute('tabindex') && el.tagName !== 'BUTTON') { el.setAttribute('tabindex', '0'); if (!el.getAttribute('role')) el.setAttribute('role', 'button'); }
    });
  }
  // when a dialog / now-playing screen opens, move the remote focus into it
  let lastOverlay = null;
  function focusNewOverlay() {
    if (root.getAttribute('data-layout') !== 'tv') { lastOverlay = null; return; }
    const ov = topOverlay();
    if (!ov) { lastOverlay = null; return; }
    if (ov === lastOverlay) return;
    lastOverlay = ov;
    const list = candidates(ov); if (!list.length) return;
    focusEl(ov.querySelector('.btn-primary, .np-play-pause') && list.includes(ov.querySelector('.btn-primary, .np-play-pause')) ? ov.querySelector('.btn-primary, .np-play-pause') : list[0]);
  }
  let mo = null, raf = 0;
  function watch() {
    if (mo) return;
    const host = document.getElementById('app'); if (!host) return;
    mo = new MutationObserver(() => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; makeFocusable(); focusNewOverlay(); }); });
    mo.observe(host, { childList: true, subtree: true });
    makeFocusable();
  }
  document.addEventListener('DOMContentLoaded', watch);
  if (document.readyState !== 'loading') watch();

  function goBack() {
    const ov = topOverlay(); if (!ov) return false;
    const closer = ov.querySelector('#btn-np-close, #btn-close-modal, [data-le="close"], [data-dp="close"], #btn-close-notice, .cropper-actions .btn-ghost, .cropper-actions [data-action="cancel"]');
    if (closer) { closer.click(); return true; }
    return false;
  }
  function mediaKey(e) {
    const k = e.key, c = e.keyCode;
    const pp = k === 'MediaPlayPause' || k === 'MediaPlay' || k === 'MediaPause' || c === 179 || c === 415 || c === 19;
    const nx = k === 'MediaTrackNext' || k === 'MediaFastForward' || c === 176 || c === 417;
    const pv = k === 'MediaTrackPrevious' || k === 'MediaRewind' || c === 177 || c === 412;
    if (!pp && !nx && !pv) return false;
    const q = (a) => document.querySelector(a);
    const btn = pp ? (q('#btn-np-play-pause') || q('.player-controls .play-pause'))
      : nx ? (q('#btn-np-next') || q('.player-controls [data-action="next"]'))
      : (q('#btn-np-prev') || q('.player-controls [data-action="prev"]'));
    if (btn) { btn.click(); return true; }
    return false;
  }

  document.addEventListener('keydown', (e) => {
    if (root.getAttribute('data-layout') !== 'tv') return;
    if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
    if (mediaKey(e)) { e.preventDefault(); return; }
    if (BACK_KEYS.includes(e.key) || BACK_CODES.includes(e.keyCode)) { if (goBack()) e.preventDefault(); return; }
    if (e.key === 'Backspace' && !isTyping(e.target)) { if (goBack()) e.preventDefault(); return; }
    const dir = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[e.key]
      || ({ 37: 'left', 39: 'right', 38: 'up', 40: 'down' })[e.keyCode];
    if (dir) {
      const el = e.target;
      if (isTyping(el)) { if (dir === 'left' || dir === 'right') return; }
      if (el && el.tagName === 'INPUT' && el.type === 'range') return;
      if (move(dir)) e.preventDefault();
      return;
    }
    if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.getAttribute && e.target.getAttribute('role') === 'button' && e.target.tagName !== 'BUTTON') {
      e.preventDefault(); e.target.click();
    }
  }, true);

  return { pref, mode, set, apply, goBack, MODES };
})();
