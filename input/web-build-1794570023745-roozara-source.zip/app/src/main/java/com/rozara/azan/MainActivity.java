package com.rozara.azan;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    static volatile boolean visible = false;
    private static final int REQ_LOC = 77;
    private static final int REQ_NOTIF = 78;

    private WebView wv;
    private int permStep = 0;
    private boolean awaiting = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.immersive(this);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#FDF6E3"));
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        wv.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage m) { return true; }
        });
        wv.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        wv.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(wv);
        wv.loadUrl("file:///android_asset/www/index.html");

        new Thread(() -> {
            Scheduler.scheduleAll(getApplicationContext());
            DateNotifier.update(getApplicationContext());
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        Ui.immersive(this);
        if (wv != null) {
            wv.onResume();
            wv.evaluateJavascript("window.onNativeResume&&window.onNativeResume()", null);
        }
        new Thread(() -> {
            Scheduler.scheduleAll(getApplicationContext());
            DateNotifier.update(getApplicationContext());
        }).start();
        if (awaiting) nextPerm();
    }

    @Override
    protected void onPause() {
        visible = false;
        if (wv != null) wv.onPause();
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (wv != null) { wv.destroy(); wv = null; }
        super.onDestroy();
    }

    // ---------- مکان‌یابی ----------
    void startLocation() {
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        LocationHelper.fetch(this, new LocationHelper.Callback() {
            @Override public void ok(double lat, double lon, String place) {
                js("window.onNativeLocation&&window.onNativeLocation(" + lat + "," + lon + "," + JSONObject.quote(place == null ? "" : place) + ")");
            }
            @Override public void error(String code) {
                js("window.onNativeLocationError&&window.onNativeLocationError(" + JSONObject.quote(code) + ")");
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_LOC) {
            boolean ok = false;
            for (int r : res) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
            if (ok) startLocation();
            else js("window.onNativeLocationError&&window.onNativeLocationError('denied')");
        }
    }

    private void js(final String code) {
        runOnUiThread(() -> { if (wv != null) wv.evaluateJavascript(code, null); });
    }

    // ---------- مجوزها (اعلان، آلارم دقیق، صفحهٔ اذان روی قفل، باتری) ----------
    void startPermissionFlow() {
        permStep = 0;
        nextPerm();
    }

    private void nextPerm() {
        awaiting = false;
        while (true) {
            switch (permStep++) {
                case 0:
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        awaiting = true;
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                        return;
                    }
                    break;
                case 1:
                    if (Build.VERSION.SDK_INT >= 31) {
                        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                        if (!am.canScheduleExactAlarms()) {
                            if (launch(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())))) return;
                        }
                    }
                    break;
                case 2:
                    if (Build.VERSION.SDK_INT >= 34) {
                        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        if (!nm.canUseFullScreenIntent()) {
                            if (launch(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName())))) return;
                        }
                    }
                    break;
                case 3: {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                        if (launch(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())))) return;
                    }
                    break;
                }
                case 4:
                    if (!Settings.canDrawOverlays(this)) {
                        Toast.makeText(this, "برای نمایش صفحهٔ اذان روی صفحهٔ اصلی گوشی، «نمایش روی سایر برنامه‌ها» را روشن کن", Toast.LENGTH_LONG).show();
                        if (launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))) return;
                    }
                    break;
                case 5:
                    if (!Foreground.hasUsageAccess(this)) {
                        Toast.makeText(this, "برای اینکه وسط کار با برنامه‌های دیگر فقط نوتیف بیاید، «دسترسی به مصرف برنامه‌ها» را برای روزآرا روشن کن", Toast.LENGTH_LONG).show();
                        if (launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + getPackageName())))) return;
                        if (launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))) return;
                    }
                    break;
                default:
                    permStep = 0;
                    donePerms();
                    return;
            }
        }
    }

    private boolean launch(Intent i) {
        try {
            awaiting = true;
            startActivity(i);
            return true;
        } catch (Throwable t) {
            awaiting = false;
            return false;
        }
    }

    private void donePerms() {
        StringBuilder miss = new StringBuilder();
        if (!Notifs.canPost(this)) miss.append("اعلان‌ها، ");
        if (Build.VERSION.SDK_INT >= 31 && !((AlarmManager) getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms()) miss.append("آلارم دقیق، ");
        if (Build.VERSION.SDK_INT >= 34 && !((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent()) miss.append("نمایش اذان روی قفل‌صفحه، ");
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) miss.append("بدون محدودیت باتری، ");
        if (!Settings.canDrawOverlays(this)) miss.append("نمایش روی سایر برنامه‌ها، ");
        if (!Foreground.hasUsageAccess(this)) miss.append("دسترسی به مصرف برنامه‌ها، ");
        String msg = miss.length() == 0 ? "همه مجوزهای اذان فعال است ✓"
                : "برای کار کردن اذان وقتی برنامه بسته است این‌ها را فعال کن: " + miss.substring(0, miss.length() - 2);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        new Thread(() -> {
            Scheduler.scheduleAll(getApplicationContext());
            DateNotifier.update(getApplicationContext());
        }).start();
    }
}
