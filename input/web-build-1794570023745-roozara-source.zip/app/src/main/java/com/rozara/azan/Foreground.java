package com.rozara.azan;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** تشخیص اینکه الان کدام برنامه روی صفحه است (نیازمند «دسترسی به مصرف برنامه‌ها»). */
final class Foreground {
    private Foreground() {}

    static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int m = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            return m == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** بسته‌ی برنامهٔ روی صفحه یا null اگر نامشخص باشد */
    @SuppressWarnings("deprecation")
    static String topPackage(Context c) {
        try {
            if (!hasUsageAccess(c)) return null;
            UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(now - 3L * 3600_000L, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String pkg = null;
            long t = 0;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND && e.getTimeStamp() >= t) {
                    t = e.getTimeStamp();
                    pkg = e.getPackageName();
                }
            }
            return pkg;
        } catch (Throwable ignored) {
            return null;
        }
    }

    static boolean isLauncher(Context c, String pkg) {
        if (pkg == null) return false;
        if (pkg.equals("com.android.systemui")) return true; // صفحهٔ «برنامه‌های اخیر»
        try {
            Set<String> homes = new HashSet<>();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> l = c.getPackageManager().queryIntentActivities(i, PackageManager.MATCH_ALL);
            for (ResolveInfo r : l) if (r.activityInfo != null) homes.add(r.activityInfo.packageName);
            return homes.contains(pkg);
        } catch (Throwable t) {
            return false;
        }
    }
}
