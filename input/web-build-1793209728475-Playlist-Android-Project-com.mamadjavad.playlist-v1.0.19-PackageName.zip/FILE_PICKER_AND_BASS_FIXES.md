# Playlist Android fixes

This revision includes:

- WebView file selection support for image/audio inputs, including content URI access and a safer document-picker fallback.
- File inputs are visually hidden without `display:none`, so programmatic activation from the profile and playlist-cover controls remains available in Android WebView.
- Android's native Media3 playback now drives the in-app bass-style pulse animation from the native playback clock. The Web Audio offline bass analysis remains in place for browser playback.

The Android native pulse is rhythm-synchronized visual feedback, not a live frequency-spectrum measurement of the song. A full audio-reactive spectrum would require a separate native audio-analysis pipeline.

Build the APK again from this project ZIP. The APK itself is not included.
