Playlist update notes

- First-run visual quality is selected from Android native total RAM, CPU core count and low-RAM-device status; browser-only fallback uses available device memory / hardware concurrency. The selected quality is persisted, and manual Settings choices continue to override it.
- Low quality skips animated ambient blob layers while retaining the static cover-aware colour gradient and album artwork.
- Auth screens are constrained to the viewport, horizontal panning/overscroll is blocked, and vertical scrolling is available only when content exceeds the available height.
- Avatar cropper waits for image decoding before enabling Confirm, handles WebView load timing, and rejects empty canvas output. Registration preview lifecycle and Settings image fallback were hardened.
- Version bumped to 1.1 (versionCode 2) for the next install/update. Updating over an existing install still requires the same applicationId and same signing key.

Validation performed: JavaScript syntax checks and ZIP integrity. Android Gradle build/device behavior must still be verified by AndroidForge and on-device testing.
