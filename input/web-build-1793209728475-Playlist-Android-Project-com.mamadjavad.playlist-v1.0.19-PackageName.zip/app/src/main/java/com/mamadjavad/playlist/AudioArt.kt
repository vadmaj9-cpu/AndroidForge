package com.mamadjavad.playlist

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import java.io.ByteArrayOutputStream

/** Cover art of a song stored on the device. */
object AudioArt {
    fun load(ctx: Context, uri: Uri, size: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
            } catch (_: Exception) {
            }
        }
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(ctx, uri)
            val bytes = r.embeddedPicture
            r.release()
            if (bytes != null) BitmapFactory.decodeByteArray(bytes, 0, bytes.size) else null
        } catch (_: Exception) {
            null
        }
    }

    fun jpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }
}
