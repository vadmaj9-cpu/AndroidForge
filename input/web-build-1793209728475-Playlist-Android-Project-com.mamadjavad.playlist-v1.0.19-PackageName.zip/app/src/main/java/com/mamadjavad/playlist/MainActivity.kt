package com.mamadjavad.playlist

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.ActivityResult
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

/** Hosts the Aurora web app (assets/www) in a WebView and connects it to the native player. */
class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private var pendingFileCallback: android.webkit.ValueCallback<Array<Uri>>? = null

    // WebView file chooser: supports images and audio selected by HTML input[type=file].
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val callback = pendingFileCallback
            pendingFileCallback = null
            if (callback == null) return@registerForActivityResult

            // Store the nullable public API property in a local val so Kotlin can
            // safely smart-cast it across the following expressions.
            val resultData = result.data
            val uris = if (result.resultCode == RESULT_OK && resultData != null) {
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, resultData)
                ?: resultData.clipData?.let { clip -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri } }
                ?: resultData.data?.let { arrayOf(it) }
            } else null
            callback.onReceiveValue(uris)
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (::bridge.isInitialized) bridge.onPermissionResult()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Use the full display for the player. System bars can still be revealed
        // temporarily with an edge swipe when the user needs system controls.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        web = WebView(this)
        web.setBackgroundColor(0xFF070B1F.toInt())
        setContentView(web)

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (_: Exception) {
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Cancel any previous request so the WebView never waits on a stale callback.
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                if (filePathCallback == null) return false

                return try {
                    val chooserIntent = try { fileChooserParams?.createIntent() } catch (_: Exception) { null }
                    val accept = fileChooserParams?.acceptTypes
                        ?.flatMap { it.split(',') }
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?.distinct()
                        ?: emptyList()
                    val mime = when {
                        accept.any { it.startsWith("image/") } -> "image/*"
                        accept.any { it.startsWith("audio/") } -> "audio/*"
                        accept.size == 1 -> accept.first()
                        else -> "*/*"
                    }
                    val intent = chooserIntent ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        }
                    }
                    fileChooserLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    pendingFileCallback = null
                    filePathCallback.onReceiveValue(null)
                    false
                }
            }
        }

        bridge = NativeBridge(this, web)
        web.addJavascriptInterface(bridge, "AuroraNative")
        bridge.connect()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // let the web app close dialogs first; otherwise just send the app to the background (music keeps playing)
                web.evaluateJavascript(
                    "(function(){try{return window.__auroraBack?!!window.__auroraBack():false}catch(e){return false}})()"
                ) { handled -> if (handled != "true") moveTaskToBack(true) }
            }
        })

        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        web.requestFocus()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }
    }

    /** Asks for access to the song library (and notifications on Android 13+). */
    fun requestAudioPermissions() {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.READ_MEDIA_AUDIO)
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permLauncher.launch(list.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        bridge.setVisible(true)
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onPause() {
        bridge.setVisible(false)
        super.onPause()
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        bridge.release()
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
