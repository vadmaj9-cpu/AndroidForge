/* Adaptive visual quality. First launch is auto-detected from native Android
   RAM/CPU information (with browser fallbacks); a manual Settings choice persists. */
const PerfSettings = (() => {
  const KEY = 'playlist_app_perf_v1';
  const root = document.documentElement;
  let cfg = {};
  try { cfg = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { cfg = {}; }

  function readHardwareProfile() {
    try {
      const bridge = window.AuroraNative;
      if (bridge && typeof bridge.getDeviceProfile === 'function') {
        const raw = bridge.getDeviceProfile();
        if (raw) return JSON.parse(raw);
      }
    } catch (e) {}
    return {};
  }

  function autoQuality() {
    const hw = readHardwareProfile();
    const cores = Number(hw.cpuCores) || Number(navigator.hardwareConcurrency) || 4;
    const ramMb = Number(hw.totalRamMb) || ((Number(navigator.deviceMemory) || 0) * 1024);
    const lowRam = hw.lowRamDevice === true;
    // Five tiers. Prefer smooth frame pacing on weak devices; reserve the
    // most expensive glass treatment for devices with generous memory/CPU.
    if (lowRam || (ramMb > 0 && ramMb < 3600) || cores <= 4) return 'very-low';
    if ((ramMb > 0 && ramMb < 5200) || cores <= 5) return 'low';
    if (ramMb >= 12500 && cores >= 8) return 'very-high';
    if (ramMb >= 8500 && cores >= 8) return 'high';
    if (ramMb >= 6200 && cores >= 6) return 'medium';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 12 && cores >= 8) return 'very-high';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 8 && cores >= 8) return 'high';
    if (ramMb === 0 && cores >= 6) return 'medium';
    return 'low';
  }

  const QUALITY_LEVELS = ['very-low', 'low', 'medium', 'high', 'very-high'];
  if (!QUALITY_LEVELS.includes(cfg.quality)) {
    cfg.quality = autoQuality();
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {}
  }

  function get() {
    const q = QUALITY_LEVELS.includes(cfg.quality) ? cfg.quality : 'low';
    return { quality: q, anim: cfg.anim !== false, beat: cfg.beat !== false };
  }
  function apply() {
    const g = get();
    root.setAttribute('data-quality', g.quality);
    root.setAttribute('data-anim', g.anim ? 'on' : 'off');
    root.setAttribute('data-beat', g.beat ? 'on' : 'off');
    if (g.quality === 'high' || g.quality === 'very-high') root.removeAttribute('data-lite'); else root.setAttribute('data-lite', '1');
  }
  function set(patch) {
    Object.assign(cfg, patch);
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {}
    apply();
    window.dispatchEvent(new Event('perfchange'));
  }
  apply();
  return { get, set, apply, autoQuality };
})();
