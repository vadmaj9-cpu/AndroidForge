/* Bass-reactive visuals.
   The track is decoded once at a tiny sample rate (offline, does NOT touch the <audio> element, so
   background playback is unaffected), a bass-energy envelope is built, and while playing the cover art
   and player bar pulse with the kicks. Tied to the "Animations" switch in Settings. */
const BeatEngine = (() => {
  const RATE = 8000, HOP = 320, FPS = RATE / HOP; // 25 envelope frames per second
  const cache = new Map();            // fileKey -> Float32Array
  let curKey = null, curBlob = null, env = null, pending = null, beat = 0, raf = 0, lastWritten = -1, nativeMode = false, nativeSeed = 0;
  const audio = () => (typeof Native !== 'undefined' && Native.available ? Native.audio : document.getElementById('audio-el'));
  const animOn = () => { try { return PerfSettings.get().beat; } catch (e) { return true; } };  // bass animation switch (separate from UI animations)

  async function analyze(blob) {
    if (!blob || blob.size > 45 * 1024 * 1024) return null;
    const Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!Ctx) return null;
    const buf = await blob.arrayBuffer();
    const ctx = new Ctx(1, 1, RATE);
    const decoded = await new Promise((res, rej) => { const p = ctx.decodeAudioData(buf, res, rej); if (p && p.then) p.then(res, rej); });
    const ch0 = decoded.getChannelData(0), ch1 = decoded.numberOfChannels > 1 ? decoded.getChannelData(1) : null;
    const n = Math.floor(decoded.length / HOP);
    const e = new Float32Array(n);
    const a = 1 - Math.exp(-2 * Math.PI * 150 / decoded.sampleRate); // ~150Hz low-pass (bass)
    let y1 = 0, y2 = 0, k = 0;
    for (let i = 0; i < n; i++) {
      let sum = 0;
      for (let j = 0; j < HOP; j++, k++) {
        const x = ch1 ? (ch0[k] + ch1[k]) * 0.5 : ch0[k];
        y1 += a * (x - y1); y2 += a * (y1 - y2);
        sum += y2 * y2;
      }
      e[i] = sum / HOP;
    }
    // local-contrast: kicks stand out against the surrounding ~1s average
    const pre = new Float64Array(n + 1); for (let i = 0; i < n; i++) pre[i + 1] = pre[i] + e[i];
    const W = Math.round(FPS * 0.6), out = new Float32Array(n);
    let peak = 1e-12; for (let i = 0; i < n; i++) if (e[i] > peak) peak = e[i];
    for (let i = 0; i < n; i++) {
      const lo = Math.max(0, i - W), hi = Math.min(n, i + W + 1);
      const avg = (pre[hi] - pre[lo]) / (hi - lo) + peak * 0.01;
      const r = e[i] / avg - 1;               // >0 when louder than surroundings
      const loud = Math.min(1, Math.sqrt(e[i] / peak) * 1.4); // quiet parts stay calm
      out[i] = Math.max(0, Math.min(1, r / 1.1)) * loud;
    }
    return out;
  }

  function load(key, blob) {
    nativeMode = false;
    curKey = key; curBlob = blob; env = cache.get(key) || null; beat = 0;
    if (env || !animOn()) { kick(); return; }
    const mine = key;
    pending = analyze(blob).then(r => {
      if (r) { cache.set(mine, r); if (cache.size > 4) cache.delete(cache.keys().next().value); }
      if (curKey === mine) { env = r; kick(); }
    }).catch(() => {});
  }

  function targets() {
    return [document.getElementById('now-playing'), document.querySelector('.player-bar:not(.hidden-player)')];
  }
  function write(v) {
    const val = v.toFixed(3);
    if (val === lastWritten) return; lastWritten = val;
    targets().forEach(el => { if (el) el.style.setProperty('--beat', val); });
  }
  function frame() {
    raf = 0;
    const a = audio();
    if (!animOn() || (!env && !nativeMode) || !a || a.paused || document.hidden) { beat = 0; lastWritten = -1; write(0); return; }
    let v = 0;
    if (nativeMode) {
      // Android uses Media3 for background playback, so its audio is not routed through the WebView.
      // Drive the visual pulse from the native playback clock with a stable, track-specific rhythm.
      const t = Math.max(0, a.currentTime);
      const period = 0.39 + (nativeSeed % 17) * 0.009;
      const phase = (t % period) / period;
      const primary = phase < 0.19 ? Math.pow(1 - phase / 0.19, 1.7) : 0;
      const halfPhase = ((t + period * 0.48) % period) / period;
      const secondary = halfPhase < 0.11 ? Math.pow(1 - halfPhase / 0.11, 2) * 0.28 : 0;
      v = Math.min(1, primary * 0.82 + secondary);
    } else {
      const i = Math.min(env.length - 1, Math.max(0, Math.floor((a.currentTime + 0.04) * FPS)));
      v = env[i];
    }
    beat = v > beat ? beat + (v - beat) * 0.85 : beat * 0.84; // fast attack, smooth release
    write(beat < 0.01 ? 0 : beat);
    raf = requestAnimationFrame(frame);
  }
  function startNative(key) {
    nativeMode = true; env = null; curKey = key || 'native'; curBlob = null; beat = 0;
    nativeSeed = Array.from(String(curKey)).reduce((n, c) => (n * 31 + c.charCodeAt(0)) >>> 0, 7);
    kick();
  }
  function kick() { if (!raf) raf = requestAnimationFrame(frame); }

  const a0 = audio();
  if (a0) ['play', 'playing', 'seeked', 'pause', 'ended'].forEach(ev => a0.addEventListener(ev, kick));
  document.addEventListener('visibilitychange', kick);
  window.addEventListener('perfchange', () => {
    if (!animOn()) { beat = 0; lastWritten = -1; write(0); }
    else if (!env && curKey && curBlob) load(curKey, curBlob);   // turned on mid-song: analyse the current track now
    kick();
  });
  return { load, startNative, kick };
})();
