/* Picks a dominant colour from the current cover art and exposes it as --cover-rgb (used for glows/tints). */
const CoverColor = (() => {
  const cache = new Map(), root = document.documentElement;
  const set = (rgb) => root.style.setProperty('--cover-rgb', rgb.join(','));
  function compute(img) {
    try {
      const c = document.createElement('canvas'); c.width = c.height = 16;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, 16, 16);
      const d = x.getImageData(0, 0, 16, 16).data;
      let r = 0, g = 0, b = 0, w = 0;
      for (let i = 0; i < d.length; i += 4) {
        const R = d[i], G = d[i + 1], B = d[i + 2], mx = Math.max(R, G, B), mn = Math.min(R, G, B);
        const sat = (mx - mn) / (mx || 1), lum = (R + G + B) / 765;
        const wt = 0.1 + sat * 2.2 + (lum > 0.15 && lum < 0.9 ? 0.6 : 0);
        r += R * wt; g += G * wt; b += B * wt; w += wt;
      }
      let rgb = [r / w, g / w, b / w]; const m = Math.max.apply(null, rgb);
      if (m < 150) { const k = 150 / Math.max(m, 1); rgb = rgb.map(v => Math.min(255, v * k)); }
      return rgb.map(Math.round);
    } catch (e) { return null; }
  }
  function update() {
    const img = document.querySelector('.np-cover') || document.querySelector('.player-cover');
    if (!img) return; const src = img.getAttribute('src'); if (!src || img._cc === src) return;
    if (cache.has(src)) { img._cc = src; set(cache.get(src)); return; }
    const run = () => { const rgb = compute(img); if (rgb) { img._cc = src; cache.set(src, rgb); set(rgb); } };
    if (img.complete && img.naturalWidth) run(); else img.addEventListener('load', run, { once: true });
  }
  document.addEventListener('load', (e) => { const el = e.target; if (el && el.matches && el.matches('.np-cover,.player-cover')) update(); }, true);
  return { update };
})();
