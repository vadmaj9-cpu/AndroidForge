/* Timed lyrics editor: write lines with start/end seconds while the song plays.
   openLyricsEditor(song) -> Promise<string|null>  (LRC text, '' when cleared, null when cancelled) */
const LyricsEditor = (() => {
  let busy = false;

  function fmt(sec) {
    if (sec == null || !isFinite(sec)) return '';
    sec = Math.max(0, sec);
    const m = Math.floor(sec / 60), r = sec - m * 60;
    return m + ':' + r.toFixed(2).padStart(5, '0');
  }
  function parseTime(str) {
    str = String(str == null ? '' : str).trim().replace(/[٫,]/g, '.')
      .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    if (str === '') return { ok: true, v: null };
    if (!/^\d+(:\d{1,2})?(\.\d+)?$|^\d+:\d{1,2}:\d{1,2}(\.\d+)?$/.test(str)) return { ok: false, v: null };
    const parts = str.split(':').map(Number);
    let v = 0; parts.forEach(p => { v = v * 60 + p; });
    return isFinite(v) ? { ok: true, v } : { ok: false, v: null };
  }

  async function open(song) {
    if (busy) return null; busy = true;
    const url = song.uri ? 'native' : await fileKeyToUrl(song.fileKey, null);
    if (!url) { showNotification('error', t('lyrics.ed.noAudio')); busy = false; return null; }

    // pause the main player so the two don't play at once
    try { if (typeof audioEl !== 'undefined' && !audioEl.paused) { audioEl.pause(); if (typeof player !== 'undefined') { player.wantsPlaying = false; player.isPlaying = false; } if (typeof updatePlayerBarDom === 'function') updatePlayerBarDom(); } } catch (e) {}

    let rows = []; let uid = 0;
    const mk = (start, end, text) => ({ id: ++uid, start, end, text: text || '', bad: {} });
    if (song.lyrics) {
      const parsed = Lyrics.parse(song.lyrics, song.duration);
      if (parsed.synced) rows = parsed.lines.map(l => mk(l.t, l.e == null ? null : l.e, l.s));
      else rows = parsed.lines.map(l => mk(null, null, l.s));
    }
    let dirty = false, rangeEnd = null, activeId = null, raf = 0, dur = song.duration || 0;

    const au = (song.uri && typeof Native !== 'undefined' && Native.available) ? Native.openEditorAudio(song) : new Audio();
    if (!song.uri) { au.preload = 'auto'; au.src = url; }

    const root = document.createElement('div');
    root.className = 'le-backdrop'; root.dir = 'auto';
    root.innerHTML = `
      <div class="le-panel" role="dialog" aria-modal="true">
        <div class="le-head">
          <div class="le-head-text"><h2>${t('lyrics.ed.title')}</h2><p class="le-song" dir="auto">${escapeHtml(song.title || song.name || '')}</p></div>
          <button type="button" class="icon-btn" data-le="close" aria-label="${t('lyrics.ed.cancel')}">${icon('x', 18)}</button>
        </div>
        <div class="le-player">
          <div class="le-transport">
            <button type="button" class="le-skip" data-le="back">${t('lyrics.ed.back')}</button>
            <button type="button" class="play-fab" data-le="toggle" aria-label="play">${icon('play', 19)}</button>
            <button type="button" class="le-skip" data-le="fwd">${t('lyrics.ed.fwd')}</button>
          </div>
          <div class="le-seek-row" dir="ltr">
            <span class="le-time" data-le="cur">0:00.00</span>
            <input type="range" class="le-seek" min="0" max="1000" value="0" step="1" data-le="seek">
            <span class="le-time" data-le="dur">${fmt(dur)}</span>
          </div>
          <div class="le-speed" role="group" aria-label="${t('lyrics.ed.speed')}">
            <span class="le-speed-label">${t('lyrics.ed.speed')}</span>
            ${[0.5, 0.75, 1].map(v => `<button type="button" class="le-chip ${v === 1 ? 'on' : ''}" data-le="speed" data-v="${v}" dir="ltr">${v}x</button>`).join('')}
          </div>
        </div>
        <div class="le-tools">
          <button type="button" class="btn btn-primary" data-le="add-now">${icon('plus', 16)} ${t('lyrics.ed.addAtNow')}</button>
          <button type="button" class="btn btn-ghost" data-le="add">${t('lyrics.ed.addLine')}</button>
          <button type="button" class="btn btn-ghost" data-le="copy">${icon('copy', 16)} ${t('lyrics.ed.copy')}</button>
          <button type="button" class="btn btn-ghost" data-le="paste">${icon('clipboard', 16)} ${t('lyrics.ed.paste')}</button>
          <button type="button" class="btn btn-ghost" data-le="import">${icon('upload', 16)} ${t('lyrics.ed.import')}</button>
          <button type="button" class="btn btn-ghost le-danger-text" data-le="clear">${t('lyrics.ed.clear')}</button>
          <input type="file" class="hidden" accept=".lrc,.txt,text/plain" data-le="file">
        </div>
        <div class="le-scroll">
          <p class="le-hint">${t('lyrics.ed.hint')}</p>
          <div class="le-list" data-le="list"></div>
        </div>
        <div class="le-paste hidden" data-le="paste-box">
          <h3>${t('lyrics.ed.pasteTitle')}</h3>
          <p class="le-hint">${t('lyrics.ed.pasteHint')}</p>
          <textarea class="input le-paste-text" data-le="paste-text" dir="auto" rows="9" placeholder="${t('lyrics.ed.pastePh')}"></textarea>
          <div class="le-paste-actions">
            <button type="button" class="btn btn-primary" data-le="paste-apply">${icon('check', 16)} ${t('lyrics.ed.pasteApply')}</button>
            <button type="button" class="btn btn-ghost" data-le="paste-cancel">${t('lyrics.ed.cancel')}</button>
          </div>
        </div>
        <div class="le-foot">
          <button type="button" class="btn btn-primary" data-le="save">${icon('check', 16)} ${t('lyrics.ed.save')}</button>
          <button type="button" class="btn btn-ghost" data-le="cancel">${t('lyrics.ed.cancel')}</button>
        </div>
      </div>`;
    document.body.appendChild(root);
    const $ = (k) => root.querySelector(`[data-le="${k}"]`);
    const listEl = $('list'), seekEl = $('seek'), curEl = $('cur'), durEl = $('dur'), toggleEl = $('toggle');

    function rowHtml(r) {
      return `<div class="le-row ${r.bad.overlap ? 'warn' : ''}" data-id="${r.id}">
        <div class="le-times" dir="ltr">
          <div class="le-time-field"><label>${t('lyrics.ed.start')}</label>
            <div class="le-time-ctl"><input class="input le-in ${r.bad.start ? 'input-error' : ''}" data-f="start" inputmode="decimal" autocomplete="off" value="${fmt(r.start)}" placeholder="0:00.00">
            <button type="button" class="le-mini le-mini-now" data-a="set-start" title="${t('lyrics.ed.setStart')}">${icon('clock', 13)} ${t('lyrics.ed.setStart')}</button></div></div>
          <div class="le-time-field"><label>${t('lyrics.ed.end')}</label>
            <div class="le-time-ctl"><input class="input le-in ${r.bad.end ? 'input-error' : ''}" data-f="end" inputmode="decimal" autocomplete="off" value="${fmt(r.end)}" placeholder="0:00.00">
            <button type="button" class="le-mini le-mini-now" data-a="set-end" title="${t('lyrics.ed.setEnd')}">${icon('clock', 13)} ${t('lyrics.ed.setEnd')}</button></div></div>
        </div>
        <textarea class="input le-text" data-f="text" rows="2" dir="auto" placeholder="${t('lyrics.ed.textPh')}">${escapeHtml(r.text)}</textarea>
        <div class="le-row-actions">
          <button type="button" class="le-mini le-mini-play" data-a="play-range" aria-label="${t('lyrics.ed.playRange')}">${icon('play', 13)} ${t('lyrics.ed.playRange')}</button>
          <button type="button" class="icon-btn" data-a="remove" aria-label="${t('lyrics.ed.remove')}" title="${t('lyrics.ed.remove')}">${icon('trash', 16)}</button>
        </div>
        ${r.bad.overlap ? `<p class="le-warn-msg">${t('lyrics.ed.overlap')}</p>` : ''}${r.bad.order ? `<p class="le-warn-msg">${t('lyrics.ed.endBefore')}</p>` : ''}
      </div>`;
    }
    function renderList() {
      markOverlaps();
      listEl.innerHTML = rows.length ? rows.map(rowHtml).join('') : `<p class="le-empty">${t('lyrics.ed.empty')}</p>`;
      paintActive(true);
    }
    function markOverlaps() {
      rows.forEach(r => { r.bad.overlap = false; r.bad.order = r.end != null && r.start != null && r.end <= r.start; });
      const timed = rows.filter(r => r.start != null).sort((a, b) => a.start - b.start);
      for (let i = 0; i < timed.length - 1; i++) {
        const a = timed[i], b = timed[i + 1];
        if (a.end != null && a.end > b.start + 0.001) { a.bad.overlap = true; b.bad.overlap = true; }
      }
    }
    const rowOf = (el) => rows.find(r => r.id === Number(el.closest('.le-row').dataset.id));

    function paintActive(force) {
      const ct = au.currentTime; let id = null;
      for (const r of rows) {
        if (r.start == null || !r.text.trim()) continue;
        if (ct + 0.05 >= r.start && (r.end != null ? ct < r.end : true)) id = r.id; // last matching wins
      }
      if (!force && id === activeId) return;
      activeId = id;
      listEl.querySelectorAll('.le-row').forEach(el => el.classList.toggle('active', Number(el.dataset.id) === id));
    }
    function setPlayIcon() { toggleEl.innerHTML = icon(au.paused ? 'play' : 'pause', 19); }

    function tick() {
      raf = requestAnimationFrame(tick);
      const ct = au.currentTime;
      if (rangeEnd != null && ct >= rangeEnd) { au.pause(); rangeEnd = null; }
      curEl.textContent = fmt(ct);
      const d = au.duration && isFinite(au.duration) ? au.duration : dur;
      if (d && durEl.textContent !== fmt(d)) durEl.textContent = fmt(d);
      if (d && !seekEl.matches(':active') && document.activeElement !== seekEl) seekEl.value = String(Math.round((ct / d) * 1000));
      paintActive(false);
    }
    raf = requestAnimationFrame(tick);
    au.addEventListener('play', setPlayIcon); au.addEventListener('pause', setPlayIcon); au.addEventListener('ended', setPlayIcon);
    au.addEventListener('loadedmetadata', () => { if (isFinite(au.duration)) dur = au.duration; });

    function playFrom(sec, end) {
      au.currentTime = Math.max(0, sec || 0); rangeEnd = end == null ? null : end;
      au.play().catch(() => {});
    }
    const now = () => Math.round(au.currentTime * 100) / 100;

    // ---- events ----
    seekEl.addEventListener('input', () => {
      const d = au.duration && isFinite(au.duration) ? au.duration : dur;
      if (d) { au.currentTime = (Number(seekEl.value) / 1000) * d; rangeEnd = null; }
    });
    root.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-le],[data-a]'); if (!b || !root.contains(b)) return;
      const le = b.getAttribute('data-le'), a = b.getAttribute('data-a');
      if (le === 'toggle') { rangeEnd = null; au.paused ? au.play().catch(() => {}) : au.pause(); }
      else if (le === 'back') { au.currentTime = Math.max(0, au.currentTime - 2); rangeEnd = null; }
      else if (le === 'fwd') { au.currentTime = Math.min(au.duration || 1e9, au.currentTime + 2); rangeEnd = null; }
      else if (le === 'speed') { au.playbackRate = Number(b.dataset.v); root.querySelectorAll('[data-le="speed"]').forEach(x => x.classList.toggle('on', x === b)); }
      else if (le === 'add-now') {
        const last = rows.filter(r => r.start != null).sort((x, y) => y.start - x.start)[0];
        const s = now();
        // close the previous open-ended line right where the new one starts
        if (last && last.end == null && last.start < s) last.end = s;
        rows.push(mk(s, null, '')); dirty = true; renderList();
        const ta = listEl.querySelector('.le-row:last-child .le-text'); if (ta) { ta.focus(); ta.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
      }
      else if (le === 'add') { rows.push(mk(null, null, '')); dirty = true; renderList(); const ta = listEl.querySelector('.le-row:last-child .le-text'); if (ta) ta.focus(); }
      else if (le === 'import') $('file').click();
      else if (le === 'copy') {
        const text = Lyrics.serialize(rows);
        if (!text) { showNotification('error', t('lyrics.ed.copyNothing')); return; }
        if (await copyText(text)) showNotification('success', t('lyrics.ed.copied'));
      }
      else if (le === 'paste') {
        // try the clipboard directly; if the browser refuses, show a box to paste into
        let txt = '';
        try { txt = (await navigator.clipboard.readText() || '').trim(); } catch (err) { txt = ''; }
        if (txt && /\[\d{1,3}:\d{2}/.test(txt)) applyPasted(txt);
        else { $('paste-text').value = txt; $('paste-box').classList.remove('hidden'); $('paste-text').focus(); }
      }
      else if (le === 'paste-cancel') $('paste-box').classList.add('hidden');
      else if (le === 'paste-apply') {
        const txt = $('paste-text').value.trim();
        if (!txt) { showNotification('error', t('lyrics.ed.pasteEmpty')); return; }
        if (applyPasted(txt)) { $('paste-box').classList.add('hidden'); $('paste-text').value = ''; }
      }
      else if (le === 'clear') { if (rows.length) { rows = []; dirty = true; renderList(); } }
      else if (le === 'close' || le === 'cancel') await finish(null);
      else if (le === 'save') {
        rows.forEach(r => { r.bad = {}; });
        const usable = rows.filter(r => r.text.trim() && r.start != null);
        const skipped = rows.length - usable.length;
        if (!rows.length) { await finish(''); return; }
        if (!usable.length) { showNotification('error', t('lyrics.ed.nothing')); return; }
        if (skipped) showNotification('warning', t('lyrics.ed.skipped', { count: skipped }));
        await finish(Lyrics.serialize(rows));
      }
      else if (a) {
        const r = rowOf(b); if (!r) return;
        const rowEl = b.closest('.le-row');
        if (a === 'set-start') { r.start = now(); rowEl.querySelector('[data-f="start"]').value = fmt(r.start); flash(rowEl, 'start'); r.bad.start = false; dirty = true; markOverlaps(); refreshWarn(rowEl, r); }
        else if (a === 'set-end') { r.end = now(); rowEl.querySelector('[data-f="end"]').value = fmt(r.end); flash(rowEl, 'end'); r.bad.end = false; dirty = true; markOverlaps(); refreshWarn(rowEl, r); }
        else if (a === 'play-range') { if (r.start == null) { showNotification('error', t('lyrics.ed.badTime')); return; } playFrom(Math.max(0, r.start - 0.05), r.end); }
        else if (a === 'remove') { rows = rows.filter(x => x !== r); dirty = true; renderList(); }
      }
    });
    async function copyText(text) {
      try { await navigator.clipboard.writeText(text); return true; } catch (err) {}
      try {
        const ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0'; root.appendChild(ta); ta.select();
        const ok = document.execCommand('copy'); ta.remove(); return ok;
      } catch (err) { return false; }
    }
    // Puts every pasted line (with its start/end time) into the list
    function applyPasted(txt) {
      const parsed = Lyrics.parse(txt, song.duration);
      if (!parsed.lines.length) { showNotification('error', t('lyrics.ed.pasteEmpty')); return false; }
      if (rows.length && !window.confirm(t('lyrics.ed.pasteReplace'))) return false;
      rows = parsed.synced ? parsed.lines.map(l => mk(l.t, l.e == null ? null : l.e, l.s)) : parsed.lines.map(l => mk(null, null, l.s));
      dirty = true; renderList();
      showNotification(parsed.synced ? 'success' : 'info', t(parsed.synced ? 'lyrics.ed.pasted' : 'lyrics.ed.pastedPlain', { count: rows.length }));
      return true;
    }
    function flash(rowEl, f) {
      const id = rowEl.dataset.id;
      // the list is redrawn right after, so look the field up again on the next frame
      requestAnimationFrame(() => { const el = listEl.querySelector('.le-row[data-id="' + id + '"] [data-f="' + f + '"]'); if (!el) return; el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 700); });
    }
    function refreshWarn(rowEl, r) {
      // overlaps may now involve other rows too, so redraw while keeping what the person typed
      const keep = document.activeElement; renderListKeep(); if (keep && keep.focus) try { keep.focus(); } catch (e) {}
    }
    function renderListKeep() { renderList(); }

    listEl.addEventListener('input', (e) => {
      const f = e.target.getAttribute('data-f'); if (!f) return;
      const r = rowOf(e.target); if (!r) return; dirty = true;
      if (f === 'text') { r.text = e.target.value; return; }
    });
    listEl.addEventListener('change', (e) => {
      const f = e.target.getAttribute('data-f'); if (f !== 'start' && f !== 'end') return;
      const r = rowOf(e.target); if (!r) return;
      const p = parseTime(e.target.value);
      if (!p.ok) { r.bad[f] = true; e.target.classList.add('input-error'); showNotification('error', t('lyrics.ed.badTime')); return; }
      r.bad[f] = false; r[f] = p.v; dirty = true; renderList();
    });
    $('file').addEventListener('change', async (e) => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      const text = (await f.text()).trim(); e.target.value = '';
      if (!text) { showNotification('error', t('lyrics.empty')); return; }
      const parsed = Lyrics.parse(text, song.duration);
      rows = parsed.synced ? parsed.lines.map(l => mk(l.t, l.e == null ? null : l.e, l.s)) : parsed.lines.map(l => mk(null, null, l.s));
      dirty = true; renderList();
      showNotification(parsed.synced ? 'success' : 'info', t(parsed.synced ? 'lyrics.ed.imported' : 'lyrics.ed.unsyncedImported'));
    });
    root.addEventListener('mousedown', (e) => { if (e.target === root) root._downOnBackdrop = true; else root._downOnBackdrop = false; });
    root.addEventListener('click', async (e) => { if (e.target === root && root._downOnBackdrop) await finish(null); });
    function onKey(e) { if (e.key === 'Escape' && !e.defaultPrevented) { e.preventDefault(); finish(null); } }
    document.addEventListener('keydown', onKey);

    let resolveFn;
    const done = new Promise(res => { resolveFn = res; });
    async function finish(result) {
      if (result === null && dirty && !window.confirm(t('lyrics.ed.confirmClose'))) return;
      cancelAnimationFrame(raf); document.removeEventListener('keydown', onKey);
      au.pause(); au.removeAttribute('src'); au.load();
      if (song.uri && typeof Native !== 'undefined' && Native.available) Native.closeEditorAudio();
      root.remove(); busy = false; resolveFn(result);
    }

    renderList(); setPlayIcon();
    return done;
  }
  return { open };
})();

function openLyricsEditor(song) { return LyricsEditor.open(song); }
