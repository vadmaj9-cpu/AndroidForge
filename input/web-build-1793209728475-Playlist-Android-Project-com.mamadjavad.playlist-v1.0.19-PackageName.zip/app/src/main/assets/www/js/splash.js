/* Fake loading splash shown every time the app opens (purely visual). */
(function () {
  var el = document.getElementById('splash');
  if (!el) return;
  var fill = document.getElementById('splash-fill');
  var pct = document.getElementById('splash-pct');
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var animOff = document.documentElement.getAttribute('data-anim') === 'off';
  var DURATION = (reduce || animOff) ? 900 : 3600; // ms – intentionally not instant
  var start = Date.now();
  document.body.classList.add('locked-scroll');
  function ease(x) { return 1 - Math.pow(1 - x, 2.2); }
  function tick() {
    var x = Math.min(1, (Date.now() - start) / DURATION);
    // slow-down plateaus make it feel like real loading
    var v = ease(x) * 100;
    if (x < 0.9) v = Math.min(v, 12 + x * 88 * 0.98);
    v = Math.round(v);
    if (fill) fill.style.width = v + '%';
    if (pct) pct.textContent = v + '%';
    if (x < 1) { requestAnimationFrame(tick); return; }
    setTimeout(function () {
      el.classList.add('done');
      document.body.classList.remove('locked-scroll');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 650);
    }, 250);
  }
  requestAnimationFrame(tick);
})();
document.addEventListener('visibilitychange', function () {
  document.documentElement.classList.toggle('is-hidden', document.hidden);
});
