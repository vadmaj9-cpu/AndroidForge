const LS_KEYS = {
  USERS: 'playlist_app_users_v1',
  SESSION: 'playlist_app_session_v1',
  NOTICES: 'playlist_app_seen_notices_v1',
  playlists: (userId) => `playlist_app_playlists_v1_${userId}`,
  subscription: (userId) => `playlist_app_subscription_v1_${userId}`,
};

const SUBSCRIPTION_STATUS = { FREE: 'FREE', PREMIUM: 'PREMIUM' };
const FREE_PUBLISH_LIMIT = 10;

async function hashPassword(password, saltHex) {
  const salt = saltHex || Array.from(crypto.getRandomValues(new Uint8Array(16)))
    .map(b => b.toString(16).padStart(2, '0')).join('');
  if (window.crypto && window.crypto.subtle && window.isSecureContext) {
    const enc = new TextEncoder();
    const data = enc.encode(salt + ':' + password);
    const digest = await crypto.subtle.digest('SHA-256', data);
    const hashHex = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
    return { hash: hashHex, salt };
  }
  // Fallback for non-secure contexts (e.g. opening this file directly for local testing,
  // where the browser disables the Web Crypto subtle API). Not cryptographically strong,
  // but only used in this local-testing scenario — real deployments (https/localhost) use SHA-256 above.
  const hash = btoa(unescape(encodeURIComponent(salt + ':' + password)));
  return { hash, salt };
}

const DataService = {
  getUsers() { try { return JSON.parse(localStorage.getItem(LS_KEYS.USERS)) || []; } catch (e) { return []; } },
  saveUsers(users) { localStorage.setItem(LS_KEYS.USERS, JSON.stringify(users)); },
  async registerUser({ username, password, profileImageBlob }) {
    const users = this.getUsers();
    if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) throw new Error('DUPLICATE_USERNAME');
    const { hash, salt } = await hashPassword(password);
    let profileImageKey = null;
    if (profileImageBlob) profileImageKey = await FileStore.put(profileImageBlob);
    const user = { id: 'u_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8), username, passwordHash: hash, passwordSalt: salt, profileImageKey, createdAt: Date.now() };
    users.push(user); this.saveUsers(users); this.createSession(user.id); return user;
  },
  async loginUser({ username, password }) {
    const users = this.getUsers();
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (!user) throw new Error('INVALID_CREDENTIALS');
    const { hash } = await hashPassword(password, user.passwordSalt);
    if (hash !== user.passwordHash) throw new Error('INVALID_CREDENTIALS');
    this.createSession(user.id); return user;
  },
  createSession(userId) {
    const token = Array.from(crypto.getRandomValues(new Uint8Array(24))).map(b => b.toString(16).padStart(2, '0')).join('');
    localStorage.setItem(LS_KEYS.SESSION, JSON.stringify({ userId, token, createdAt: Date.now() }));
  },
  getSession() { try { return JSON.parse(localStorage.getItem(LS_KEYS.SESSION)); } catch (e) { return null; } },
  getCurrentUser() {
    const session = this.getSession(); if (!session) return null;
    return this.getUsers().find(u => u.id === session.userId) || null;
  },
  logout() { localStorage.removeItem(LS_KEYS.SESSION); },
  async updateUsername(userId, newUsername) {
    const users = this.getUsers();
    if (users.some(u => u.id !== userId && u.username.toLowerCase() === newUsername.toLowerCase())) throw new Error('DUPLICATE_USERNAME');
    const user = users.find(u => u.id === userId); if (!user) throw new Error('NOT_FOUND');
    user.username = newUsername; this.saveUsers(users); return user;
  },
  async updatePassword(userId, oldPassword, newPassword) {
    const users = this.getUsers();
    const user = users.find(u => u.id === userId); if (!user) throw new Error('NOT_FOUND');
    const { hash: oldHash } = await hashPassword(oldPassword, user.passwordSalt);
    if (oldHash !== user.passwordHash) throw new Error('WRONG_PASSWORD');
    const { hash, salt } = await hashPassword(newPassword);
    user.passwordHash = hash; user.passwordSalt = salt; this.saveUsers(users); return user;
  },
  getPlaylists(userId) { try { return JSON.parse(localStorage.getItem(LS_KEYS.playlists(userId))) || []; } catch (e) { return []; } },
  savePlaylists(userId, playlists) { localStorage.setItem(LS_KEYS.playlists(userId), JSON.stringify(playlists)); },
  getSeenNotices(userId) {
    try { const all = JSON.parse(localStorage.getItem(LS_KEYS.NOTICES)) || {}; return all[userId] || []; } catch (e) { return []; }
  },
  markNoticeSeen(userId, noticeId) {
    let all = {}; try { all = JSON.parse(localStorage.getItem(LS_KEYS.NOTICES)) || {}; } catch (e) {}
    all[userId] = Array.from(new Set([...(all[userId] || []), noticeId]));
    localStorage.setItem(LS_KEYS.NOTICES, JSON.stringify(all));
  },
  getSubscriptionInfo(userId) {
    try {
      const raw = JSON.parse(localStorage.getItem(LS_KEYS.subscription(userId)));
      if (raw) return raw;
    } catch (e) {}
    return {
      subscriptionStatus: SUBSCRIPTION_STATUS.FREE,
      subscriptionPrice: null,
      subscriptionStartDate: null,
      subscriptionEndDate: null,
      freePublishUsed: 0,
      freePublishLimit: FREE_PUBLISH_LIMIT,
    };
  },
  saveSubscriptionInfo(userId, info) {
    localStorage.setItem(LS_KEYS.subscription(userId), JSON.stringify(info));
  },
  getNotifications(userId) {
    // No backend yet — returns an empty list. Shape is ready for real notifications later:
    // { id, type, titleKey, bodyKey, createdAt, read }
    return [];
  },
  getConversations(userId) {
    // No backend yet — returns an empty list. Shape is ready for real conversations later:
    // { id, username, avatarKey, lastMessage, lastMessageAt, unreadCount }
    return [];
  },
};

const NOTICE_IDS = { WELCOME_V1: 'welcome_v1' };