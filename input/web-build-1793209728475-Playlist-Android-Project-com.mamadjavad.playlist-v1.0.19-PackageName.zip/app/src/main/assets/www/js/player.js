const CANDIDATE_AUDIO_TYPES = [
  { ext: 'mp3', mime: 'audio/mpeg' }, { ext: 'wav', mime: 'audio/wav' },
  { ext: 'ogg', mime: 'audio/ogg' }, { ext: 'oga', mime: 'audio/ogg' },
  { ext: 'm4a', mime: 'audio/mp4' }, { ext: 'aac', mime: 'audio/aac' },
  { ext: 'flac', mime: 'audio/flac' }, { ext: 'webm', mime: 'audio/webm' },
];
const probeAudioEl = new Audio();

function isAudioFormatSupported(file) {
  if (file.type && file.type.startsWith('audio/')) {
    const can = probeAudioEl.canPlayType(file.type);
    if (can === 'probably' || can === 'maybe') return true;
  }
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const candidate = CANDIDATE_AUDIO_TYPES.find(c => c.ext === ext);
  if (candidate) { const can = probeAudioEl.canPlayType(candidate.mime); return can === 'probably' || can === 'maybe'; }
  return false;
}

function formatDuration(sec) {
  if (!isFinite(sec) || sec < 0) return '00:00';
  return `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
}

function readAudioDuration(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const a = new Audio(); a.preload = 'metadata';
    let resolved = false;
    const cleanup = () => { if (!resolved) { resolved = true; URL.revokeObjectURL(url); } };
    a.onloadedmetadata = () => { cleanup(); resolve(isFinite(a.duration) ? a.duration : 0); };
    a.onerror = () => { cleanup(); resolve(0); };
    a.src = url;
  });
}

function readAudioTags(file) {
  return new Promise((resolve) => {
    if (window.__jsmediatagsFailed || typeof window.jsmediatags === 'undefined') {
      resolve({ title: null, artist: null, album: null, coverBlob: null }); return;
    }
    try {
      window.jsmediatags.read(file, {
        onSuccess: (tag) => {
          const t = tag.tags || {}; let coverBlob = null;
          if (t.picture) { const { data, format } = t.picture; coverBlob = new Blob([new Uint8Array(data)], { type: format }); }
          resolve({ title: t.title || null, artist: t.artist || null, album: t.album || null, coverBlob });
        },
        onError: () => resolve({ title: null, artist: null, album: null, coverBlob: null }),
      });
    } catch (e) { resolve({ title: null, artist: null, album: null, coverBlob: null }); }
  });
}