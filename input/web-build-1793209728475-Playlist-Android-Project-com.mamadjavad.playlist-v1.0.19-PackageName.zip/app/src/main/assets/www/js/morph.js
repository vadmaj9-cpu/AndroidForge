/* Morph: updates the existing DOM in place instead of rebuilding it with innerHTML.
   Result: no flicker, images don't reload, scroll position and CSS transitions survive. */
const Morph = (() => {
  const KEEP_CLASSES = ['marquee-animate', 'closing', 'dragging', 'leaving'];
  const KEY_ATTRS = ['data-playlist-id', 'data-id', 'data-convo-id', 'data-nav', 'data-action'];
  let dedupeRoot = null;

  // While afterRender() runs, a listener re-added on a kept node replaces the old one (no duplicates).
  const nativeAdd = Element.prototype.addEventListener;
  Element.prototype.addEventListener = function (type, fn, opts) {
    if (dedupeRoot && typeof fn === 'function' && dedupeRoot.contains(this)) {
      const map = this.__ml || (this.__ml = new Map());
      const key = type + '|' + fn.toString();
      const prev = map.get(key);
      if (prev) this.removeEventListener(type, prev.fn, prev.opts);
      map.set(key, { fn, opts });
    }
    return nativeAdd.call(this, type, fn, opts);
  };

  const firstClass = (el) => (el.getAttribute('class') || '').trim().split(/\s+/)[0] || '';
  function sameKind(a, b) {
    if (a.nodeType !== b.nodeType) return false;
    if (a.nodeType !== 1) return true;
    if (a.nodeName !== b.nodeName || a.id !== b.id || firstClass(a) !== firstClass(b)) return false;
    for (const k of KEY_ATTRS) if (a.getAttribute(k) !== b.getAttribute(k)) return false;
    return true;
  }

  function syncAttrs(o, n) {
    const isCover = o.nodeName === 'IMG' && (o.hasAttribute('data-cover-key') || o.id === 'settings-avatar');
    const isMarquee = o.classList && o.classList.contains('marquee');
    for (const a of Array.from(o.attributes)) {
      if (n.hasAttribute(a.name)) continue;
      if (a.name === 'src' && isCover) continue;
      if (a.name === 'style' && isMarquee) continue;
      if (a.name === 'class') {
        const keep = KEEP_CLASSES.filter(c => o.classList.contains(c));
        if (keep.length) { o.setAttribute('class', keep.join(' ')); continue; }
      }
      o.removeAttribute(a.name);
    }
    for (const a of Array.from(n.attributes)) {
      if (a.name === 'src' && isCover) continue;
      if (a.name === 'style' && isMarquee) continue;
      let val = a.value;
      if (a.name === 'class') {
        const extra = KEEP_CLASSES.filter(c => o.classList.contains(c) && !n.classList.contains(c));
        if (extra.length) val = (val + ' ' + extra.join(' ')).trim();
      }
      if (o.getAttribute(a.name) !== val) o.setAttribute(a.name, val);
    }
  }

  function removeNode(o) {
    if (o.nodeType === 1 && o.classList.contains('modal-backdrop')) {
      o.classList.add('leaving');
      setTimeout(() => { if (o.parentNode) o.parentNode.removeChild(o); }, 260);
    } else if (o.parentNode) o.parentNode.removeChild(o);
  }

  function morphNode(o, n) {
    if (o.nodeType !== 1) { if (o.nodeValue !== n.nodeValue) o.nodeValue = n.nodeValue; return; }
    syncAttrs(o, n);
    const tag = o.nodeName;
    if (tag === 'INPUT') {
      if (o.type !== 'file' && document.activeElement !== o && o.value !== n.value) o.value = n.value;
      if (o.type === 'checkbox' || o.type === 'radio') o.checked = n.checked;
      return;
    }
    if (tag === 'TEXTAREA') {
      if (document.activeElement !== o && o.value !== n.value) o.value = n.value;
      return;
    }
    morphChildren(o, n);
  }

  function morphChildren(op, np) {
    const olds = Array.from(op.childNodes).filter(x => !(x.nodeType === 1 && x.classList.contains('leaving')));
    const news = Array.from(np.childNodes);
    for (let i = 0; i < news.length; i++) {
      const n = news[i], o = olds[i];
      if (!o) { op.appendChild(n); continue; }
      if (sameKind(o, n)) morphNode(o, n);
      else { op.insertBefore(n, o); removeNode(o); }
    }
    for (let i = news.length; i < olds.length; i++) removeNode(olds[i]);
  }

  function patch(root, html, after) {
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    morphChildren(root, tpl.content);
    dedupeRoot = root;
    try { after(); } finally { dedupeRoot = null; }
  }
  return { patch };
})();
