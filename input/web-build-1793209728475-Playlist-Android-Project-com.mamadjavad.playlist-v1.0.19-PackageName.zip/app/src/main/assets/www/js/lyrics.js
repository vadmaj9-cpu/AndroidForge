/* Synced lyrics: parses LRC (or plain text) and finds the active line. */
const Lyrics = (() => {
  const cache = new Map();
  function parse(text, duration) {
    const out = []; let offset = 0, synced = false; const plain = [];
    String(text || '').replace(/^﻿/, '').split(/\r?\n/).forEach(raw => {
      const line = raw.trim(); if (!line) return;
      const off = line.match(/^\[offset:\s*(-?\d+)\s*\]/i); if (off) { offset = parseInt(off[1], 10) / 1000; return; }
      if (/^\[(ar|ti|al|by|au|length|re|ve):/i.test(line)) return;
      const stamps = [...line.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
      const body = line.replace(/\[[^\]]*\]/g, '').replace(/<[^>]*>/g, '').trim();
      if (stamps.length) {
        synced = true;
        stamps.forEach(m => { const f = m[3] ? parseInt(m[3], 10) / Math.pow(10, m[3].length) : 0; out.push({ t: parseInt(m[1], 10) * 60 + parseInt(m[2], 10) + f, s: body }); });
      } else plain.push(line);
    });
    if (synced) {
      out.forEach(l => { l.t = Math.max(0, l.t - offset); });
      out.sort((a, b) => a.t - b.t);
      // an empty stamped line right after a text line marks that line's end time
      for (let i = 0; i < out.length - 1; i++) { if (out[i].s && !out[i + 1].s) out[i].e = out[i + 1].t; }
      return { lines: out.filter(l => l.s), synced: true };
    }
    const d = duration || 0, n = plain.length;
    return { lines: plain.map((s, i) => ({ t: d ? (i / n) * d : i * 4, s })), synced: false };
  }
  function get(song) {
    if (!song || !song.lyrics) return null;
    const key = (song.id || song.fileKey) + ':' + song.lyrics;
    let r = cache.get(key);
    if (!r) { r = parse(song.lyrics, song.duration); cache.set(key, r); }
    return r.lines.length ? r : null;
  }
  function indexAt(lines, time) {
    let lo = 0, hi = lines.length - 1, ans = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (lines[m].t <= time + 0.15) { ans = m; lo = m + 1; } else hi = m - 1; }
    return ans;
  }
  function stamp(sec) {
    sec = Math.max(0, sec); let m = Math.floor(sec / 60), r = sec - m * 60, w = Math.floor(r), c = Math.round((r - w) * 100);
    if (c >= 100) { c = 0; w += 1; if (w >= 60) { w = 0; m += 1; } }
    return '[' + String(m).padStart(2, '0') + ':' + String(w).padStart(2, '0') + '.' + String(c).padStart(2, '0') + ']';
  }
  // rows: [{ start, end, text }] -> LRC text (end time is written as an empty stamped line)
  function serialize(rows) {
    const items = rows.filter(r => r.text && r.text.trim() && r.start != null && isFinite(r.start)).slice().sort((a, b) => a.start - b.start);
    const out = [];
    items.forEach(r => {
      out.push(stamp(r.start) + r.text.trim().replace(/\s*\r?\n\s*/g, ' '));
      if (r.end != null && isFinite(r.end) && r.end > r.start) out.push(stamp(r.end));
    });
    return out.join('\n');
  }
  return { get, indexAt, parse, serialize };
})();
