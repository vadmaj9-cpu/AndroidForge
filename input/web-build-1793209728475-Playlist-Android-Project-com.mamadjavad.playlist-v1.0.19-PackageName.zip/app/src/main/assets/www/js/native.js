/* Android bridge. Only active inside the Aurora Android app (window.AuroraNative is injected by the WebView).
   In a normal browser `Native.available` is false and nothing here runs.

   Playback lives in a native Media3 service (so it continues in the background, shows the media notification and
   advances through the queue on its own). `Native.audio` looks like an HTMLAudioElement so the rest of the app is unchanged. */
const Native = (() => {
  const bridge = (typeof window !== 'undefined' && window.AuroraNative) ? window.AuroraNative : null;
  const available = !!bridge;
  let permResolve = null;
  let pendingSync = null;
  let queuedAt = 0;
  let editorAudio = null;
  const hooks = { onTrack: null };

  function makeAudio() {
    const ev = {};
    let cur = 0, dur = 0, playing = false, rate = 1, hasSrc = false, t0 = 0;
    const fire = (n) => (ev[n] || []).slice().forEach(f => { try { f({ type: n }); } catch (e) {} });
    const nowSec = () => (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
    return {
      addEventListener(n, f) { (ev[n] = ev[n] || []).push(f); },
      removeEventListener(n, f) { ev[n] = (ev[n] || []).filter(x => x !== f); },
      get paused() { return !playing; },
      get currentTime() { return playing ? Math.min(dur || 1e9, cur + (nowSec() - t0) * rate) : cur; },
      set currentTime(v) { cur = Math.max(0, Number(v) || 0); t0 = nowSec(); try { bridge.seekTo(Math.round(cur * 1000)); } catch (e) {} },
      get duration() { return dur || NaN; },
      get src() { return hasSrc ? 'native:queue' : ''; },
      set src(v) { hasSrc = !!v; },
      get playbackRate() { return rate; },
      set playbackRate(v) { rate = Number(v) || 1; try { bridge.setSpeed(rate); } catch (e) {} },
      play() { try { bridge.play(); } catch (e) { return Promise.reject(e); } if (!playing) { playing = true; t0 = nowSec(); fire('play'); } return Promise.resolve(); },
      pause() { try { bridge.pause(); } catch (e) {} if (playing) { cur = this.currentTime; playing = false; fire('pause'); } },
      load() {},
      removeAttribute() { hasSrc = false; const was = playing; playing = false; cur = 0; dur = 0; try { bridge.stop(); } catch (e) {} if (was) fire('pause'); },
      _apply(s) {
        const was = playing;
        playing = !!(s.wantsPlay && s.state !== 4 && s.state !== 1);
        cur = (s.positionMs || 0) / 1000; t0 = nowSec();
        const d = (s.durationMs || 0) / 1000;
        if (d && d !== dur) { dur = d; fire('loadedmetadata'); }
        if (playing && !was) fire('play');
        if (!playing && was) fire('pause');
        fire('timeupdate');
        if (s.state === 4 && s.ended) fire('ended');
      },
      _ended() { const was = playing; playing = false; if (was) fire('pause'); fire('ended'); },
    };
  }
  const audio = available ? makeAudio() : null;

  function songMeta(s) { return { id: s.id, uri: s.uri, title: s.title || s.name || '', artist: s.artist || '', album: s.album || '', duration: s.duration || 0 }; }

  // Hand the whole playlist to the native player so it can keep going on its own when the app is in the background
  function setQueue(pl, songIndex, play, repeatOne) {
    if (!available) return;
    const items = pl.songs.filter(s => s.uri);
    const target = pl.songs[songIndex];
    let idx = items.findIndex(s => s.id === (target && target.id)); if (idx < 0) idx = 0;
    const repeat = repeatOne ? 'one' : (pl.loopPlaylist ? 'all' : 'off');
    queuedAt = Date.now();
    bridge.setQueue(JSON.stringify({ playlistId: pl.id, index: idx, repeat, items: items.map(songMeta) }), !!play);
  }
  function setRepeat(pl, repeatOne) { if (available) bridge.setRepeat(repeatOne ? 'one' : (pl && pl.loopPlaylist ? 'all' : 'off')); }

  function ensurePermission() {
    if (!available) return Promise.resolve(false);
    try { if (bridge.hasAudioPermission()) return Promise.resolve(true); } catch (e) { return Promise.resolve(false); }
    return new Promise(res => { permResolve = res; try { bridge.requestAudioPermission(); } catch (e) { res(false); } });
  }
  function listAudio(allFiles) {
    try { return JSON.parse(bridge.listAudio(!!allFiles) || '[]'); } catch (e) { return []; }
  }
  async function getArtBlob(uri) {
    try {
      const b64 = bridge.getArt(uri);
      if (!b64) return null;
      const bin = atob(b64), u = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
      return new Blob([u], { type: 'image/jpeg' });
    } catch (e) { return null; }
  }
  // The lyrics editor gets its own audio object so its events never reach the main player
  function openEditorAudio(song) {
    editorAudio = makeAudio(); editorAudio.src = 'native:editor';
    setQueue({ id: '__editor', loopPlaylist: false, songs: [song] }, 0, false, false);
    return editorAudio;
  }
  function closeEditorAudio() {
    editorAudio = null;
    try { bridge.stop(); } catch (e) {}
    if (typeof window.__restoreNativeQueue === 'function') window.__restoreNativeQueue();
  }
  function isTv() { try { return !!(available && bridge.isTv && bridge.isTv()); } catch (e) { return false; } }

  // Called by the native side
  function dispatch(type, data) {
    if (!audio) return;
    if (type === 'perm') { if (permResolve) { const r = permResolve; permResolve = null; r(!!(data && data.granted)); } return; }
    if (type === 'state') {
      (editorAudio || audio)._apply(data);
      // ignore the previous song's last state right after a new queue was sent
      if (!editorAudio && hooks.onTrack && data.songId && Date.now() - queuedAt > 800) hooks.onTrack(data.songId, data.playlistId);
    } else if (type === 'ended') { (editorAudio || audio)._ended(); }
    else if (type === 'sync') { pendingSync = data; trySync(); }
    else if (type === 'error') { if (typeof showNotification === 'function') showNotification('error', (data && data.message) || 'Playback error'); }
  }
  // When the app is re-opened while the service is still playing, pick the player UI back up
  function trySync(tries) {
    const s = pendingSync; if (!s || !s.songId || !s.playlistId) { pendingSync = null; return; }
    tries = tries || 0;
    if (typeof state === 'undefined' || !state.currentUser || !state.playlists || !state.playlists.length) { if (tries < 25) setTimeout(() => trySync(tries + 1), 300); return; }
    pendingSync = null;
    const pl = state.playlists.find(p => p.id === s.playlistId); if (!pl) return;
    const idx = pl.songs.findIndex(x => x.id === s.songId); if (idx < 0) return;
    if (typeof BeatEngine !== 'undefined') BeatEngine.startNative(pl.songs[idx].id || pl.songs[idx].uri);
    player.playlistId = pl.id; player.songIndex = idx; state.playerVisible = true;
    audio._apply(s);
    player.isPlaying = !audio.paused; player.wantsPlaying = player.isPlaying; player.currentTime = audio.currentTime; player.duration = audio.duration || 0;
    render();
  }

  if (available) {
    window.__auroraEvent = (type, data) => { try { dispatch(type, data); } catch (e) {} };
    try { if (bridge.requestSync) bridge.requestSync(); } catch (e) {}
    window.__auroraBack = () => { try { return (typeof Layout !== 'undefined' && Layout.goBack) ? !!Layout.goBack() : false; } catch (e) { return false; } };
  }

  return { available, audio, hooks, openEditorAudio, closeEditorAudio, setQueue, setRepeat, ensurePermission, listAudio, getArtBlob, isTv };
})();
