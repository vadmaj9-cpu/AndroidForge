const FileStore = (() => {
  let dbPromise = null;
  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open('playlist_app_files', 1);
      req.onupgradeneeded = () => { req.result.createObjectStore('files'); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }
  async function put(blob) {
    const db = await open();
    const key = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readwrite');
      tx.objectStore('files').put(blob, key);
      tx.oncomplete = () => resolve(key);
      tx.onerror = () => reject(tx.error);
    });
  }
  async function get(key) {
    if (!key) return null;
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readonly');
      const req = tx.objectStore('files').get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }
  async function remove(key) {
    if (!key) return;
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('files', 'readwrite');
      tx.objectStore('files').delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  return { put, get, remove };
})();

const urlCache = new Map();
async function fileKeyToUrl(key, fallback) {
  if (!key) return fallback || null;
  if (urlCache.has(key)) return urlCache.get(key);
  try {
    const blob = await FileStore.get(key);
    if (!blob) return fallback || null;
    const url = URL.createObjectURL(blob);
    urlCache.set(key, url);
    return url;
  } catch (e) { return fallback || null; }
}