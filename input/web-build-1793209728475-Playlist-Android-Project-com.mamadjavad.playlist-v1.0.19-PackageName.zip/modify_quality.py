from pathlib import Path
import re
root=Path('/mnt/data/playlist_inspect/app/src/main/assets/www')

# perf.js: five tiers, hardware-based initial selection, preserve manual override
p=root/'js/perf.js'
s=p.read_text()
s=s.replace("""    // Be conservative: quality is based on RAM and CPU core count, not model name alone.
    if (lowRam || (ramMb > 0 && ramMb < 4600) || cores < 4) return 'low';
    if (ramMb >= 11500 && cores >= 8) return 'high';
    if (ramMb >= 5600 && cores >= 6) return 'medium';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 8 && cores >= 8) return 'high';
    if (ramMb === 0 && cores >= 6) return 'medium';
    return 'low';
  }

  if (!['high', 'medium', 'low'].includes(cfg.quality)) {
""", """    // Five tiers. Prefer smooth frame pacing on weak devices; reserve the
    // most expensive glass treatment for devices with generous memory/CPU.
    if (lowRam || (ramMb > 0 && ramMb < 3600) || cores <= 4) return 'very-low';
    if ((ramMb > 0 && ramMb < 5200) || cores <= 5) return 'low';
    if (ramMb >= 12500 && cores >= 8) return 'very-high';
    if (ramMb >= 8500 && cores >= 8) return 'high';
    if (ramMb >= 6200 && cores >= 6) return 'medium';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 12 && cores >= 8) return 'very-high';
    if (ramMb === 0 && Number(navigator.deviceMemory) >= 8 && cores >= 8) return 'high';
    if (ramMb === 0 && cores >= 6) return 'medium';
    return 'low';
  }

  const QUALITY_LEVELS = ['very-low', 'low', 'medium', 'high', 'very-high'];
  if (!QUALITY_LEVELS.includes(cfg.quality)) {
""")
s=s.replace("const q = ['high', 'medium', 'low'].includes(cfg.quality) ? cfg.quality : 'low';", "const q = QUALITY_LEVELS.includes(cfg.quality) ? cfg.quality : 'low';")
s=s.replace("if (g.quality === 'high') root.removeAttribute('data-lite'); else root.setAttribute('data-lite', '1');", "if (g.quality === 'high' || g.quality === 'very-high') root.removeAttribute('data-lite'); else root.setAttribute('data-lite', '1');")
p.write_text(s)

# app.js: five selector options, skip expensive canvas on low tiers, lyrics only medium+
p=root/'js/app.js'; s=p.read_text()
s=s.replace("if (document.documentElement.dataset.quality === 'low') return;", "if (['very-low', 'low'].includes(document.documentElement.dataset.quality)) return;")
s=s.replace("const animateCanvas = !prefersReduced && document.documentElement.dataset.quality !== 'low';", "const animateCanvas = !prefersReduced && !['very-low', 'low'].includes(document.documentElement.dataset.quality);")
s=s.replace("${['high', 'medium', 'low'].map(q =>", "${['very-low', 'low', 'medium', 'high', 'very-high'].map(q =>")
p.write_text(s)

# i18n labels/descriptions in Persian and English
p=root/'js/i18n.js'; s=p.read_text()
s=s.replace('''    "settings.qualityHigh": "بالا",
    "settings.qualityMedium": "متوسط",
    "settings.qualityLow": "پایین",
    "settings.qualityDescHigh": "کیفیت خیلی بالا: شیشه‌ای کامل با تاری پشت کارت‌ها و سایه‌ها. مناسب گوشی‌های قوی.",
    "settings.qualityDescMedium": "متعادل: ظاهر شیشه‌ای بدون تاری پشت‌زمینه. پیشنهادی برای بیشتر گوشی‌ها.",
    "settings.qualityDescLow": "سریع‌ترین حالت: ظاهر ساده و تخت بدون افکت. مناسب گوشی‌های ضعیف.",
''','''    "settings.qualityVeryLow": "خیلی پایین",
    "settings.qualityLow": "پایین",
    "settings.qualityMedium": "متوسط",
    "settings.qualityHigh": "بالا",
    "settings.qualityVeryHigh": "خیلی بالا",
    "settings.qualityDescVeryLow": "بیشترین اولویت با روانی و FPS؛ افکت‌ها، انیمیشن‌های تزئینی و پس‌زمینه متحرک خاموش می‌شوند. مناسب گوشی‌های ضعیف.",
    "settings.qualityDescLow": "حالت سبک با ظاهر ساده، سایه‌های کم و بدون پس‌زمینه متحرک.",
    "settings.qualityDescMedium": "متعادل؛ ظاهر شیشه‌ای سبک، متن آهنگ و افکت‌های محدود.",
    "settings.qualityDescHigh": "کیفیت بالا با شیشه مات، عمق بصری و متن آهنگ در پلیر.",
    "settings.qualityDescVeryHigh": "بالاترین جلوه بصری Playlist؛ شیشه چندلایه، بازتاب نور ظریف، عمق بیشتر و متن آهنگ سینمایی. مناسب گوشی‌های پرچمدار.",
''')
s=s.replace('''    "settings.qualityHigh": "High",
    "settings.qualityMedium": "Medium",
    "settings.qualityLow": "Low",
    "settings.qualityDescHigh": "Very high quality: full glass look with background blur and shadows. Best for powerful phones.",
    "settings.qualityDescMedium": "Balanced: glass look without background blur. Recommended for most phones.",
    "settings.qualityDescLow": "Fastest: flat, simple look with no effects. Best for slower phones.",
''','''    "settings.qualityVeryLow": "Very low",
    "settings.qualityLow": "Low",
    "settings.qualityMedium": "Medium",
    "settings.qualityHigh": "High",
    "settings.qualityVeryHigh": "Very high",
    "settings.qualityDescVeryLow": "FPS first: decorative effects, animations and moving backgrounds are disabled. Best for entry-level phones.",
    "settings.qualityDescLow": "Lightweight look with simple surfaces, reduced shadows and no moving player background.",
    "settings.qualityDescMedium": "Balanced glass styling, synced lyrics and restrained effects.",
    "settings.qualityDescHigh": "Frosted glass, visual depth and synced lyrics.",
    "settings.qualityDescVeryHigh": "Playlist's richest visual treatment: layered glass, subtle light reflections, deeper surfaces and cinematic lyrics. Best for flagship phones.",
''')
# Add label for lyric panel
s=s.replace('''    "lyrics.add": "ویرایش متن آهنگ",
''','''    "lyrics.add": "ویرایش متن آهنگ",
    "lyrics.panelTitle": "متن آهنگ",
''')
s=s.replace('''    "lyrics.add": "Edit lyrics",
''','''    "lyrics.add": "Edit lyrics",
    "lyrics.panelTitle": "LYRICS",
''')
p.write_text(s)

# app.js lyric UI: hide full/mini lyrics on very-low/low and add separated title label
p=root/'js/app.js'; s=p.read_text()
s=s.replace("""function miniLyricHtml(song) {
  const L = Lyrics.get(song); if (!L) return '';
""", """function lyricsEnabledForQuality() {
  return !['very-low', 'low'].includes(document.documentElement.dataset.quality);
}
function miniLyricHtml(song) {
  if (!lyricsEnabledForQuality()) return '';
  const L = Lyrics.get(song); if (!L) return '';
""")
s=s.replace("""function npLyricsHtml(song) {
  const L = Lyrics.get(song); if (!L) return '';
""", """function npLyricsHtml(song) {
  if (!lyricsEnabledForQuality()) return '';
  const L = Lyrics.get(song); if (!L) return '';
""")
s=s.replace('return `<div class="np-lyrics" dir="auto" style="--li:${i}"><div class="np-lyr-track">', 'return `<div class="np-lyrics" dir="auto" data-label="${escapeHtml(t(\'lyrics.panelTitle\'))}" style="--li:${i}"><div class="np-lyr-track">')
p.write_text(s)

# ambient.js: both lowest tiers avoid animated blobs
p=root/'js/ambient.js'; s=p.read_text()
s=s.replace("if (document.documentElement.dataset.quality === 'low') {", "if (['very-low', 'low'].includes(document.documentElement.dataset.quality)) {")
p.write_text(s)

# CSS: quality selector, dedicated lyrics panel, very-low/very-high profiles
p=root/'css/style.css'; s=p.read_text()
s=s.replace('.perf-seg{ display:flex; gap:6px; padding:4px; border-radius:var(--radius-round); background:rgba(255,255,255,0.07); border:1px solid var(--color-border); }', '.perf-seg{ display:flex; gap:6px; padding:4px; border-radius:var(--radius-round); background:rgba(255,255,255,0.07); border:1px solid var(--color-border); }\n#perf-quality-seg{ display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:4px; }\n#perf-quality-seg button{ min-width:0; padding:5px 2px; white-space:normal; line-height:1.25; font-size:11px; }')
s=s.replace('.np-lyrics{ --lh:36px; height:calc(var(--lh) * 3); overflow:hidden; margin:0 0 var(--space-3); position:relative; text-align:center;\n  -webkit-mask-image:linear-gradient(transparent,#000 28%,#000 72%,transparent); mask-image:linear-gradient(transparent,#000 28%,#000 72%,transparent); }\n.np-lyr-track{ transform:translateY(calc((1 - var(--li)) * var(--lh))); transition:transform .5s cubic-bezier(.2,.8,.2,1); will-change:transform; }\n.np-lyrics .lyr{ margin:0; height:var(--lh); line-height:var(--lh); font-size:15px; padding:0 12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:rgba(255,255,255,.38); transform:scale(.9); transition:color .4s, transform .4s; }', '.np-lyrics{ --lh:28px; height:108px; flex-shrink:0; overflow:hidden; margin:0 0 var(--space-3); padding:20px 8px 0; position:relative; text-align:center; border-radius:18px; border:1px solid rgba(255,255,255,.13); background:linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.025)),rgba(18,22,58,.38); box-shadow:inset 0 1px 0 rgba(255,255,255,.12),0 8px 22px rgba(0,0,0,.12);\n  -webkit-mask-image:linear-gradient(transparent,#000 16%,#000 88%,transparent); mask-image:linear-gradient(transparent,#000 16%,#000 88%,transparent); }\n.np-lyrics::before{ content:attr(data-label); position:absolute; top:7px; inset-inline-start:12px; z-index:2; color:rgba(255,255,255,.48); font-size:9px; font-weight:800; letter-spacing:1.4px; line-height:12px; pointer-events:none; }\n.np-lyr-track{ transform:translateY(calc(20px + (1 - var(--li)) * var(--lh))); transition:transform .5s cubic-bezier(.2,.8,.4,1); will-change:transform; }\n.np-lyrics .lyr{ margin:0; height:var(--lh); line-height:var(--lh); font-size:13px; padding:0 12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:rgba(255,255,255,.38); transform:scale(.94); transition:color .4s, transform .4s; }')
s=s.replace('.np-lyrics .lyr.cur{ color:#fff; font-weight:800; font-size:17px; transform:scale(1); text-shadow:0 0 18px rgba(255,107,214,.65); }', '.np-lyrics .lyr.cur{ color:#fff; font-weight:800; font-size:15px; transform:scale(1); text-shadow:0 0 18px rgba(255,107,214,.48); }')
s=s.replace('.np-lyrics{ --lh:64px; grid-column:2; grid-row:1 / span 5; align-self:center; height:calc(var(--lh) * 7); margin:0; }', '.np-lyrics{ --lh:64px; grid-column:2; grid-row:1 / span 5; align-self:center; height:min(calc(74vh / var(--tv-zoom,1)),660px); padding:26px 8px 0; margin:0; }')
# Add very-high/very-low CSS at end, after all prior overrides
s += r'''

/* ===== FIVE-LEVEL QUALITY PROFILES ===== */
/* Very low: protect frame rate on entry-level devices. Keep album art and static cover tint. */
html[data-quality="very-low"] *,
html[data-quality="very-low"] *::before,
html[data-quality="very-low"] *::after{
  animation:none !important;
  transition:none !important;
  -webkit-backdrop-filter:none !important;
  backdrop-filter:none !important;
  filter:none !important;
  text-shadow:none !important;
  scroll-behavior:auto !important;
}
html[data-quality="very-low"] .ambient,
html[data-quality="very-low"] .landing-canvas,
html[data-quality="very-low"] .reg-intro-canvas,
html[data-quality="very-low"] .splash-glow,
html[data-quality="very-low"] .splash-ring,
html[data-quality="very-low"] .np-glow,
html[data-quality="very-low"] .beat-ring,
html[data-quality="very-low"] .np-eq,
html[data-quality="very-low"] .np-lyrics,
html[data-quality="very-low"] .player-lyric{ display:none !important; }
html[data-quality="very-low"] .playlist-card,
html[data-quality="very-low"] .settings-row,
html[data-quality="very-low"] .profile-row,
html[data-quality="very-low"] .lang-dropdown,
html[data-quality="very-low"] .auth-card,
html[data-quality="very-low"] .notif,
html[data-quality="very-low"] .bottom-nav,
html[data-quality="very-low"] .player-bar,
html[data-quality="very-low"] .song-add-btn,
html[data-quality="very-low"] .editable-song-row,
html[data-quality="very-low"] .modal,
html[data-quality="very-low"] .icon-btn,
html[data-quality="very-low"] .btn-primary,
html[data-quality="very-low"] .np-cover,
html[data-quality="very-low"] .playlist-cover,
html[data-quality="very-low"] .cover-square{
  box-shadow:none !important;
  background-image:none !important;
}
html[data-quality="very-low"] .now-playing{ background:linear-gradient(180deg,#111638,#080d22) !important; }
html[data-quality="very-low"] .np-cover-wrap{ contain:layout paint; }

/* Low: static player atmosphere, reduced shadows and no expensive blur. */
html[data-quality="low"] .ambient{ display:none !important; }
html[data-quality="low"] .np-lyrics,
html[data-quality="low"] .player-lyric{ display:none !important; }
html[data-quality="low"] .playlist-card,
html[data-quality="low"] .settings-row,
html[data-quality="low"] .profile-row,
html[data-quality="low"] .lang-dropdown,
html[data-quality="low"] .auth-card,
html[data-quality="low"] .notif,
html[data-quality="low"] .bottom-nav,
html[data-quality="low"] .player-bar,
html[data-quality="low"] .song-add-btn,
html[data-quality="low"] .editable-song-row{ box-shadow:0 3px 10px rgba(0,0,0,.20) !important; }

/* Very high: premium Liquid-Glass-inspired treatment without animated full-screen filters. */
html[data-quality="very-high"] .playlist-card,
html[data-quality="very-high"] .settings-row,
html[data-quality="very-high"] .profile-row,
html[data-quality="very-high"] .lang-dropdown,
html[data-quality="very-high"] .auth-card,
html[data-quality="very-high"] .notif,
html[data-quality="very-high"] .bottom-nav,
html[data-quality="very-high"] .player-bar,
html[data-quality="very-high"] .song-add-btn,
html[data-quality="very-high"] .editable-song-row{
  -webkit-backdrop-filter:blur(20px) saturate(1.85) brightness(1.12) !important;
  backdrop-filter:blur(20px) saturate(1.85) brightness(1.12) !important;
  background:linear-gradient(145deg,rgba(255,255,255,.20),rgba(255,255,255,.055) 42%,rgba(160,140,255,.09)),rgba(30,34,88,.30) !important;
  border-color:rgba(255,255,255,.22) !important;
  box-shadow:inset 0 1.2px 0 rgba(255,255,255,.38),inset 0 -1px 0 rgba(255,255,255,.06),0 16px 38px rgba(1,4,22,.48),0 2px 8px rgba(125,100,255,.12) !important;
}
html[data-quality="very-high"] .modal{
  -webkit-backdrop-filter:blur(30px) saturate(1.95) brightness(1.12) !important;
  backdrop-filter:blur(30px) saturate(1.95) brightness(1.12) !important;
  background:linear-gradient(145deg,rgba(255,255,255,.19),rgba(255,255,255,.045) 48%,rgba(155,130,255,.12)),rgba(24,28,78,.52) !important;
  border-color:rgba(255,255,255,.25) !important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.42),0 30px 80px rgba(0,0,0,.56),0 0 34px rgba(130,100,255,.13) !important;
}
html[data-quality="very-high"] .bottom-nav,
html[data-quality="very-high"] .player-bar{
  -webkit-backdrop-filter:blur(24px) saturate(2) brightness(1.14) !important;
  backdrop-filter:blur(24px) saturate(2) brightness(1.14) !important;
}
html[data-quality="very-high"] .np-lyrics{
  border-color:rgba(255,255,255,.24);
  background:linear-gradient(145deg,rgba(255,255,255,.15),rgba(255,255,255,.035) 52%,rgba(var(--cover-rgb),.12)),rgba(15,19,54,.42);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.22),0 14px 32px rgba(0,0,0,.20),0 0 28px rgba(var(--cover-rgb),.10);
}
html[data-quality="very-high"] .np-lyrics .lyr.cur{ text-shadow:0 0 24px rgba(var(--cover-rgb),.60),0 2px 18px rgba(255,255,255,.22); }
@media (prefers-reduced-motion:reduce){
  html[data-quality="very-high"] *,html[data-quality="very-high"] *::before,html[data-quality="very-high"] *::after{ animation:none !important; transition:none !important; }
}
'''
p.write_text(s)

# version bump
p=Path('/mnt/data/playlist_inspect/app/build.gradle.kts'); s=p.read_text().replace('versionCode = 2','versionCode = 3').replace('versionName = "1.1"','versionName = "1.2"'); p.write_text(s)

# documentation
Path('/mnt/data/playlist_inspect/QUALITY_AND_LYRICS_UPDATE.md').write_text('''# Playlist 1.2: five quality levels and lyrics layout\n\n- Added five visual quality levels: Very low, Low, Medium, High, Very high.\n- First-run auto selection uses Android-reported total RAM, low-RAM status and CPU core count; manual choice remains saved.\n- Very low disables decorative animations, blur, shadows, ambient blobs, canvas effects and lyrics to prioritize smoothness.\n- Low disables moving ambient player background and lyrics while keeping cover artwork and static cover-derived colors.\n- Medium and above show synced lyrics in a dedicated reserved panel, separated from metadata, seek bar and controls.\n- Very high adds a richer Liquid-Glass-inspired visual treatment using layered translucent surfaces and restrained highlights.\n- Version bumped to 1.2 (versionCode 3).\n\nNote: Android's public APIs do not expose a dependable general-purpose GPU performance score to this WebView app. Auto selection therefore uses RAM/CPU/low-RAM signals and is a conservative estimate, not a guaranteed FPS benchmark. Users can override it in Settings.\n''')
