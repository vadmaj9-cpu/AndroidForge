# Playlist — Android music player

این پروژه اپ اندرویدی Playlist است. رابط کاربری وب درون برنامه اندروید اجرا می‌شود و بخش پخش موسیقی با Kotlin و AndroidX Media3 پیاده‌سازی شده است.

## ساخت APK با GitHub Actions
1. در GitHub یک مخزن خالی بسازید (ترجیحاً Private).
2. محتویات این پوشه را مستقیماً در ریشه مخزن قرار دهید؛ پوشه مخفی `.github` را هم حتماً نگه دارید.
3. فایل‌ها را روی شاخه `main` ارسال کنید. با Push، فرایند ساخت به‌صورت خودکار اجرا می‌شود.
4. در مخزن وارد تب **Actions** شوید و اجرای **Build Playlist APK** را باز کنید.
5. پس از موفقیت اجرا، از بخش **Artifacts** فایل `playlist-apk` را دانلود کنید. فایل `app-debug.apk` داخل آن قرار دارد.

برای اجرای دستی نیز در Actions، workflow با نام **Build Playlist APK** را انتخاب کنید و **Run workflow** را بزنید.

## ساخت با Android Studio
پروژه را در Android Studio باز کنید و اجازه دهید Gradle Sync کامل شود. سپس از منوی Build گزینه Build APK(s) را انتخاب کنید.

## مشخصات
- نام نمایشی برنامه: Playlist
- شناسه فنی فعلی: `com.mamadjavad.playlist`
- حداقل نسخه اندروید: 7.0 (API 24)
- خروجی workflow: نسخه Debug برای آزمایش
