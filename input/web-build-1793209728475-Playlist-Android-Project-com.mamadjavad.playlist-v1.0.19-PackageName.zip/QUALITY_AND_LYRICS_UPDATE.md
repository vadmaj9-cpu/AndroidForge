# Playlist 1.2: five quality levels and lyrics layout

- Added five visual quality levels: Very low, Low, Medium, High, Very high.
- First-run auto selection uses Android-reported total RAM, low-RAM status and CPU core count; manual choice remains saved.
- Very low disables decorative animations, blur, shadows, ambient blobs, canvas effects and lyrics to prioritize smoothness.
- Low disables moving ambient player background and lyrics while keeping cover artwork and static cover-derived colors.
- Medium and above show synced lyrics in a dedicated reserved panel, separated from metadata, seek bar and controls.
- Very high adds a richer Liquid-Glass-inspired visual treatment using layered translucent surfaces and restrained highlights.
- Version bumped to 1.2 (versionCode 3).

Note: Android's public APIs do not expose a dependable general-purpose GPU performance score to this WebView app. Auto selection therefore uses RAM/CPU/low-RAM signals and is a conservative estimate, not a guaranteed FPS benchmark. Users can override it in Settings.
